# Compliance skeleton

- ISO 14971 Risk Management plan
- IEC 62304 Software lifecycle
- Clinical Evaluation Plan (draft)
