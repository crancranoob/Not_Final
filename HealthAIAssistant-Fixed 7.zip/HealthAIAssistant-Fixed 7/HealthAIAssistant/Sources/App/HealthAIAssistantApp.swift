import SwiftUI
import HealthKit

@main
@available(iOS 16.0, *)
struct HealthAIAssistantApp: App {
    @StateObject private var healthKitManager = HealthKitManager()
    @StateObject private var modelCoordinator = AIModelCoordinator()
    
        @Environment(\.scenePhase) private var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onAppear {
                    KnowledgeUpdater.shared.registerBackgroundTask()
                    KnowledgeUpdater.shared.scheduleNextUpdate()
                    BackgroundHealthObserver.shared.setUp()
                    NightTrainingScheduler.shared.register()
                    NightTrainingScheduler.shared.schedule()
                    ModelRegistry.shared.load()
                    NotificationManager.shared.requestAuthorization()
                    NotificationManager.shared.scheduleDailySummary(hour: 8, minute: 0)
                    healthKitManager.requestAuthorization()
                }
                .environmentObject(healthKitManager)
                .environmentObject(modelCoordinator)
        }
    }
}
