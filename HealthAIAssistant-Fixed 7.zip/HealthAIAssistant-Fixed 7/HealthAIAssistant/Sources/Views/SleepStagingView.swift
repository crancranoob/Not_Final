import SwiftUI

struct SleepStagingView: View {
    @State private var summary: SleepStageSummary? = nil
    var body: some View {
        List {
            if let s = summary {
                Section(header: Text("Hypnogram")) {
                    Hypnogram(stages: s.stages)
                        .frame(height: 160)
                }
                Section(header: Text("Summary")) {
                    HStack { Text("Efficiency"); Spacer(); Text(String(format: "%.0f%%", s.efficiency*100)) }
                    HStack { Text("REM"); Spacer(); Text("\(s.stageDurations[4, default:0]/60) min") }
                    HStack { Text("N3"); Spacer(); Text("\(s.stageDurations[3, default:0]/60) min") }
                }
            } else {
                Text("No data yet. Run a night to analyze sleep staging.")
            }
        }
        .navigationTitle("Sleep Staging")
        .onAppear(perform: run)
    }
    func run() {
        let recs = CSVDataManager.shared.records
        guard let epochs = SleepStagePipeline.shared.buildEpochsForLastNight(records: recs) else { return }
        let stages = SleepStageNetCoordinator.shared.predictStages(epochs: epochs) ?? SleepStageNetCore().predict(epochs: epochs)
        let sum = SleepStagePipeline.shared.summarize(stages: stages, date: Date())
        summary = sum
    }
}

struct Hypnogram: View {
    let stages: [Int]
    var body: some View {
        GeometryReader { geo in
            let W = geo.size.width
            let H = geo.size.height
            let n = max(1, stages.count)
            let step = W / CGFloat(n)
            let y: (Int)->CGFloat = { s in
                switch s { case 4: return H*0.2 // REM
                           case 3: return H*0.8 // N3 deep
                           case 2: return H*0.6 // N2
                           case 1: return H*0.4 // N1
                           default: return H*0.1 // Wake
                }
            }
            Path { p in
                p.move(to: CGPoint(x: 0, y: y(stages[0])))
                var x: CGFloat = 0
                for i in 1..<n {
                    x += step
                    p.addLine(to: CGPoint(x: x, y: y(stages[i])))
                }
            }
            .stroke(Color.blue, lineWidth: 2)
        }
    }
}
