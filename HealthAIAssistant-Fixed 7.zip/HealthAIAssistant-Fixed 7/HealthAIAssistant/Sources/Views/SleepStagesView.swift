import SwiftUI
import Charts

struct HypnogramSample: Identifiable {
    let id = UUID()
    let t: Date
    let stage: String
}

struct SleepStagesView: View {
    @State private var metrics = SleepStageMetrics()
    @State private var samples: [HypnogramSample] = []

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if samples.isEmpty {
                Text("載入中…").padding()
            } else {
                Chart(samples) {
                    LineMark(x: .value("Time", $0.t), y: .value("Stage", stageToLevel($0.stage)))
                }.frame(height: 220)
                Text(String(format: "深眠：%.0f 分鐘（%.0f%%） · REM：%.0f 分鐘（%.0f%%） · 效率：%.0f%% · 覺醒次數：%d",
                            metrics.deep/60, metrics.deepPct*100, metrics.rem/60, metrics.remPct*100, metrics.efficiency*100, metrics.awakenings))
                .font(.footnote)
                .foregroundColor(.secondary)
            }
        }
        .padding()
        .navigationTitle("睡眠階段")
        .onAppear { load() }
    }

    private func stageToLevel(_ s: String) -> Int {
        switch s {
        case "Awake": return 3
        case "REM": return 2
        case "Core": return 1
        case "Deep": return 0
        default: return 1
        }
    }

    private func load() {
        SleepStagesManager.shared.fetchLastNight { m in
            metrics = m
            // In absence of per-epoch samples, we synthesize a simple line (placeholder)
            // If you later store per-epoch, render them here.
            samples = [
                HypnogramSample(t: Date().addingTimeInterval(-8*3600), stage: "Deep"),
                HypnogramSample(t: Date().addingTimeInterval(-6*3600), stage: "Core"),
                HypnogramSample(t: Date().addingTimeInterval(-4*3600), stage: "REM"),
                HypnogramSample(t: Date().addingTimeInterval(-2*3600), stage: "Core"),
                HypnogramSample(t: Date().addingTimeInterval(-1*3600), stage: "Awake")
            ]
        }
    }
}
