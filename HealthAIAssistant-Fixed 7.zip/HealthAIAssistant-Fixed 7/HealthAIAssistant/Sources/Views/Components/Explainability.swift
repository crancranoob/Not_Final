import SwiftUI

struct DataQualityBadge: View {
    let score: Double
    var body: some View {
        let color: Color = score >= 80 ? .green : (score >= 60 ? .yellow : .orange)
        return Text("品質 \(Int(score))")
            .font(.caption).padding(6).background(color.opacity(0.2))
            .foregroundColor(color).clipShape(RoundedRectangle(cornerRadius: 6))
    }
}

struct CausalInsightCard: View {
    let title: String
    let explanation: String
    let confidence: Double
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title).font(.headline)
            Text(explanation).font(.subheadline)
            HStack {
                Text(String(format:"信心 %.0f%%", confidence*100)).font(.caption)
                Spacer()
                Button("這條洞見有幫助") { /* send feedback to teacher */ }
            }
        }.padding().background(Color(UIColor.secondarySystemBackground)).clipShape(RoundedRectangle(cornerRadius: 12))
    }
}
