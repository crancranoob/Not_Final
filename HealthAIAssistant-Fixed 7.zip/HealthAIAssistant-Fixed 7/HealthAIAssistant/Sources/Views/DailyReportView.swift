import SwiftUI

struct DailyReportView: View {
    @EnvironmentObject var modelCoordinator: AIModelCoordinator
    @State private var report: String = "載入中…"

    var body: some View {
        ScrollView {
            Text(report)
                .textSelection(.enabled)
                .padding()
        }
        .navigationTitle("每日報告")
        .onAppear {
            let d = HealthKitManager.shared.healthData
            report = DailyReportEngine.shared.buildReport(for: d, coordinator: modelCoordinator)
        }
    }
}
