import SwiftUI

struct SafetyControlPanelView: View {
    @StateObject private var s = SettingsStore.shared

    var body: some View {
        Form {
            Section(header: Text("訓練驗收門檻")) {
                Slider(value: $s.deltaMAE, in: 0.0...0.2, step: 0.005) {
                    Text("ΔMAE 最小改善")
                }
                Text(String(format: "至少改善：%.3f", s.deltaMAE)).font(.footnote)
            }
            Section(header: Text("異常偵測")) {
                Slider(value: $s.zThreshold, in: 2.0...4.0, step: 0.1) { Text("Z-score 閾值") }
                Text(String(format: "Z > %.1f 會進入隔離", s.zThreshold)).font(.footnote)
                Slider(value: $s.discrepancyThreshold, in: 0.5...3.0, step: 0.1) { Text("雙模差距閾值") }
                Text(String(format: "學習 vs 規則 差距 > %.1f → 回退規則", s.discrepancyThreshold)).font(.footnote)
            }
            Section(header: Text("風險閾值 / Baseline")) {
                Slider(value: $s.ewmaAlpha, in: 0.05...0.4, step: 0.01) { Text("EWMA α") }
                HStack {
                    VStack(alignment: .leading) {
                        Slider(value: $s.hrHighZ, in: 1.0...3.5, step: 0.1) { Text("HR 高 Z 閾值") }
                        Text(String(format: "HR z > %.1f", s.hrHighZ)).font(.footnote)
                    }
                    VStack(alignment: .leading) {
                        Slider(value: $s.hrvLowZ, in: -4.0...-0.5, step: 0.1) { Text("HRV 低 Z 閾值") }
                        Text(String(format: "HRV z < %.1f", s.hrvLowZ)).font(.footnote)
                    }
                }
                HStack {
                    VStack(alignment: .leading) {
                        Slider(value: $s.tempHighZ, in: 1.0...3.5, step: 0.1) { Text("Temp 高 Z") }
                        Text(String(format: "Temp z > %.1f", s.tempHighZ)).font(.footnote)
                    }
                    VStack(alignment: .leading) {
                        Slider(value: $s.respHighZ, in: 1.0...3.5, step: 0.1) { Text("RR 高 Z") }
                        Text(String(format: "RR z > %.1f", s.respHighZ)).font(.footnote)
                    }
                }
                HStack {
                    Slider(value: $s.spo2Low, in: 0.88...0.97, step: 0.01) { Text("SpO₂ 低於") }
                    Text(String(format: "%.2f", s.spo2Low)).font(.footnote)
                }
            }
            Section(header: Text("備份提醒")) {
                Stepper("備份最長間隔：\(s.backupMaxDays) 天", value: $s.backupMaxDays, in: 3...30)
            }
            Section(header: Text("目標設定（簡要）")) {
                Stepper("每日步數：\(s.goalSteps)", value: $s.goalSteps, in: 1000...20000, step: 500)
                Stepper("活動能量：\(Int(s.goalActiveEnergy)) kcal", value: $s.goalActiveEnergy, in: 100...2000, step: 50)
                Stepper("睡眠：\(String(format: "%.1f", s.goalSleepHours)) 小時", value: $s.goalSleepHours, in: 4.0...10.0, step: 0.5)
            }
        }
        .onDisappear { s.save() }
        .navigationTitle("安全控管與目標")
    }
}
