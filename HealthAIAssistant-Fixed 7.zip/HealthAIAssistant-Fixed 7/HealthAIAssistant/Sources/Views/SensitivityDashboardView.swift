import SwiftUI

struct SensitivityDashboardView: View {
    @State private var summary: SensitivitySummary? = nil
    @State private var error: String? = nil

    var body: some View {
        List {
            if let s = summary {
                Section(header: Text("整體等級")) {
                    HStack {
                        Label("咖啡因", systemImage: "cup.and.saucer")
                        Spacer(); Text(s.grades["caffeine"] ?? "-")
                    }
                    HStack {
                        Label("晚間咖啡因", systemImage: "moon.stars")
                        Spacer(); Text(s.grades["late_caffeine"] ?? "-")
                    }
                    HStack {
                        Label("水分", systemImage: "drop")
                        Spacer(); Text(s.grades["hydration"] ?? "-")
                    }
                }
                ForEach(["caffeine","late_caffeine","hydration"], id: \.self) { f in
                    let pts = s.points.filter { $0.factor == f }
                    if !pts.isEmpty {
                        Section(header: Text(title(for: f))) {
                            ForEach(pts) { p in
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(p.bucket).font(.headline)
                                        Text(effectLine(p)).font(.caption).foregroundColor(.secondary)
                                    }
                                    Spacer()
                                    Text("n=\(p.n)").foregroundColor(.secondary)
                                }
                            }
                        }
                    }
                }
            } else if let e = error {
                Text(e).foregroundColor(.red)
            } else {
                ProgressView("讀取中…")
            }
        }
        .navigationTitle("我的敏感度")
        .onAppear(perform: load)
    }

    func title(for factor: String) -> String {
        switch factor {
        case "caffeine": return "咖啡因（總量）"
        case "late_caffeine": return "晚間咖啡因（14:00 後）"
        case "hydration": return "水分攝取（每日）"
        default: return factor
        }
    }
    func effectLine(_ p: SensitivityPoint) -> String {
        String(format: "對綜合分數影響: %.2f (95%% CI %.2f..%.2f)", p.effect, p.lcl, p.ucl)
    }

    func load() {
        // Try reading persisted summary
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let url = doc.appendingPathComponent("sensitivity_summary.json")
        if let d = try? Data(contentsOf: url), let s = try? JSONDecoder().decode(SensitivitySummary.self, from: d) {
            summary = s
        } else {
            // If none yet, run a quick analysis on current memory (if any records loaded)
            let recs = CSVDataManager.shared.records
            if recs.count >= 10 {
                summary = SensitivityEngine.shared.analyze(records: recs)
            } else {
                error = "資料不足（至少 10 天）"
            }
        }
    }
}
