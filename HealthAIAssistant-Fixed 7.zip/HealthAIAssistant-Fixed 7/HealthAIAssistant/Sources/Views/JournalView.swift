import SwiftUI

struct JournalView: View {
    @StateObject private var store = JournalStore.shared
    @State private var newEntry = JournalEntry()
    @State private var symptomText: String = ""
    @State private var medText: String = ""

    var body: some View {
        VStack {
            Form {
                Section(header: Text("新增紀錄")) {
                    TextField("症狀（以逗號分隔）", text: $symptomText)
                    TextField("藥物（以逗號分隔）", text: $medText)
                    TextField("備註", text: $newEntry.notes)
                    Button("加入") {
                        var entry = JournalEntry(date: Date(), symptoms: symptomText.split(separator: ",").map{ $0.trimmingCharacters(in: .whitespaces) }, medications: medText.split(separator: ",").map{ $0.trimmingCharacters(in: .whitespaces) }, notes: newEntry.notes)
                        store.add(entry)
                        symptomText = ""; medText = ""; newEntry = JournalEntry()
                    }
                }
            }
            List {
                ForEach(store.items) { e in
                    VStack(alignment: .leading) {
                        Text(e.date.formatted()).font(.caption).foregroundColor(.secondary)
                        if !e.symptoms.isEmpty { Text("症狀：\(e.symptoms.joined(separator: ", "))") }
                        if !e.medications.isEmpty { Text("用藥：\(e.medications.joined(separator: ", "))") }
                        if !e.notes.isEmpty { Text(e.notes) }
                    }
                }
            }
        }
        .navigationTitle("健康日誌")
    }
}
