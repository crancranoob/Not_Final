import SwiftUI

struct SafetySettingsView: View {
    @EnvironmentObject var modelCoordinator: AIModelCoordinator
    @StateObject private var csv = CSVDataManager.shared
    @State private var holdoutMAE: Double?
    @State private var message: String = ""

    var body: some View {
        Form {
            Section(header: Text("資料自我檢查")) {
                Button {
                    let issues = DataGuard.shared.validate(HealthKitManager.shared.healthData)
                    if issues.isEmpty { message = "目前資料看起來合理。" }
                    else {
                        message = issues.map { "\($0.field): \($0.message)" }.joined(separator: " | ")
                    }
                } label: { Label("檢查當前資料合理性", systemImage: "stethoscope") }
                if !message.isEmpty { Text(message).font(.footnote).foregroundColor(.secondary) }
            }
            Section(header: Text("模型驗證與回滾")) {
                Button {
                    // 取最後 20% 當 holdout
                    let trainer = Trainer.shared
                    let dataset = trainer.sequences(from: csv.records)
                    let n = dataset.count
                    guard n > 4 else { holdoutMAE = 0; return }
                    let holdout = Array(dataset.suffix(max(1, n/5)))
                    holdoutMAE = ModelMonitor.shared.mae(on: holdout, coordinator: modelCoordinator)
                } label: { Label("計算 Holdout MAE（最後20%）", systemImage: "chart.line.uptrend.xyaxis") }
                if let m = holdoutMAE {
                    Text(String(format: "Holdout MAE: %.3f", m))
                        .font(.footnote).foregroundColor(.secondary)
                }
                Button {
                    BackupManager.shared.backupAll()
                } label: { Label("立即備份資料與權重", systemImage: "externaldrive.badge.checkmark") }
                NavigationLink(destination: BackupListView()) {
                    Label("還原備份…", systemImage: "clock.arrow.circlepath")
                }
            }
        }
        .navigationTitle("資料與安全")
    }
}

struct BackupListView: View {
    @State private var backups: [URL] = BackupManager.shared.listBackups()
    var body: some View {
        List {
            ForEach(backups, id: \.self) { u in
                HStack {
                    Text(u.lastPathComponent).font(.caption)
                    Spacer()
                    Button("還原") { BackupManager.shared.restore(from: u) }
                }
            }
        }.onAppear { backups = BackupManager.shared.listBackups() }
    }
}


struct QuarantineListView: View {
    @StateObject private var q = QuarantineStore.shared
    var body: some View {
        List {
            ForEach(q.items) { item in
                HStack {
                    VStack(alignment: .leading) {
                        Text(item.id).font(.caption)
                        Text(item.reason).font(.footnote).foregroundColor(.secondary)
                    }
                    Spacer()
                    Button("解除隔離") { q.remove(id: item.id) }
                }
            }
        }
        .navigationTitle("隔離資料")
    }
}
