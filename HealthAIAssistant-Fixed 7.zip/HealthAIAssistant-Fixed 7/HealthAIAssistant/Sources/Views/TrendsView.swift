import SwiftUI
import Charts

struct TrendPoint: Identifiable {
    let id = UUID()
    let date: Date
    let value: Double
    let label: String
    let isOutlier: Bool
}

final class TrendViewModel: ObservableObject {
    @Published var scoreSeries: [TrendPoint] = []
    @Published var sleepSeries: [TrendPoint] = []
    @Published var hrSeries: [TrendPoint] = []

    func reload(records: [DailyRecord], coordinator: AIModelCoordinator) {
        var scores: [(Date, Double)] = []
        var sleeps: [(Date, Double)] = []
        var hrs: [(Date, Double)] = []
        for r in records {
            let d = r.date
            let hd = HealthData(heartRate: r.heartRate, steps: r.steps, activeEnergy: r.activeEnergy, sleepHours: r.sleepHours, oxygenSaturation: r.oxygenSaturation, bodyTemperature: r.bodyTemperature, walkingStability: r.walkingStability, hrvSDNN: r.hrvSDNN ?? 0, respiratoryRate: r.respiratoryRate ?? 0)
            let s = coordinator.personalizedScore(from: hd)
            scores.append((d, s))
            sleeps.append((d, r.sleepHours))
            hrs.append((d, r.heartRate))
        }
        scoreSeries = makeSeries(scores, label: "Score")
        sleepSeries = makeSeries(sleeps, label: "Sleep")
        hrSeries = makeSeries(hrs, label: "HR")
    }

    private func makeSeries(_ arr: [(Date, Double)], label: String) -> [TrendPoint] {
        guard !arr.isEmpty else { return [] }
        let values = arr.map { $0.1 }
        let mean = values.reduce(0,+) / Double(values.count)
        let variance = values.map { pow($0 - mean, 2) }.reduce(0,+) / Double(values.count)
        let std = sqrt(max(variance, 1e-8))
        let z: (Double) -> Bool = { std > 0 ? abs(($0 - mean) / std) > 2.5 : false }
        return arr.map { TrendPoint(date: $0.0, value: $0.1, label: label, isOutlier: z($0.1)) }
    }
}

struct TrendsView: View {
    @StateObject private var vm = TrendViewModel()
    @StateObject private var csv = CSVDataManager.shared
    @EnvironmentObject var modelCoordinator: AIModelCoordinator

    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Group {
                    Text("個人化分數趨勢").font(.headline)
                    Chart(vm.scoreSeries) { p in
                        LineMark(x: .value("Date", p.date), y: .value("Score", p.value))
                        PointMark(x: .value("Date", p.date), y: .value("Score", p.value))
                            .foregroundStyle(p.isOutlier ? .red : .primary)
                    }
                    .frame(height: 220)
                }
                Group {
                    Text("睡眠時數（h）").font(.headline)
                    Chart(vm.sleepSeries) { p in
                        BarMark(x: .value("Date", p.date), y: .value("Hours", p.value))
                            .foregroundStyle(p.isOutlier ? .red : .blue)
                    }
                    .frame(height: 220)
                }
                Group {
                    Text("心率（bpm）").font(.headline)
                    Chart(vm.hrSeries) { p in
                        LineMark(x: .value("Date", p.date), y: .value("HR", p.value))
                        PointMark(x: .value("Date", p.date), y: .value("HR", p.value))
                            .foregroundStyle(p.isOutlier ? .red : .primary)
                    }
                    .frame(height: 220)
                }
            }
            .padding()
        }
        .onAppear { vm.reload(records: csv.records, coordinator: modelCoordinator) }
        .onChange(of: csv.records) { _, newValue in
            vm.reload(records: newValue, coordinator: modelCoordinator)
        }
        .navigationTitle("指標趨勢")
    }
}
