import SwiftUI
import Charts

struct DashboardView: View {
    @EnvironmentObject var healthKitManager: HealthKitManager
    @EnvironmentObject var modelCoordinator: AIModelCoordinator
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                HealthSummaryCard(healthData: healthKitManager.healthData)
                
                if let analysis = modelCoordinator.currentAnalysis {
                    AlertsView(analysis: analysis)
                    RecommendationsView(analysis: analysis)
                } else {
                    ProgressView("正在分析健康數據...")
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                }
            }
            .padding()
        }
        .background(Color.black)
        .onAppear {
            Task {
                // 確保 HealthKit 數據可用後再進行分析
                guard healthKitManager.isAuthorized else { return }
                await modelCoordinator.analyzeHealthData(healthKitManager.healthData)
            }
        }
    }
}

struct HealthSummaryCard: View {
    let healthData: HealthData
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("健康概覽")
                .font(.title)
                .foregroundColor(.white)
            
            MetricsGrid(healthData: healthData)
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

struct MetricsGrid: View {
    let healthData: HealthData
    
    var body: some View {
        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())]) {
            MetricCard(title: "心率", value: String(format: "%.0f", healthData.heartRate), unit: "BPM")
            MetricCard(title: "血氧", value: String(format: "%.1f", healthData.oxygenSaturation), unit: "%")
            MetricCard(title: "步數", value: "\(healthData.steps)", unit: "步")
            MetricCard(title: "睡眠", value: String(format: "%.1f", healthData.sleepHours), unit: "小時")
        }
    }
}

struct MetricCard: View {
    let title: String
    let value: String
    let unit: String
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .foregroundColor(.gray)
            HStack(alignment: .bottom) {
                Text(value)
                    .font(.system(size: 24, weight: .bold))
                Text(unit)
                    .font(.caption)
            }
            .foregroundColor(.white)
        }
        .padding()
        .background(Color(.systemGray5))
        .cornerRadius(8)
    }
}

struct AlertsView: View {
    let analysis: HealthAnalysis

    var body: some View {
        VStack(alignment: .leading) {
            Text("健康警示")
                .font(.headline).foregroundColor(.white)
            if analysis.insights.isEmpty {
                Text("一切正常").foregroundColor(.gray)
            } else {
                ForEach(analysis.insights, id: \.self) { insight in
                    HStack {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.yellow)
                        Text(insight)
                            .foregroundColor(.white)
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}

struct RecommendationsView: View {
    let analysis: HealthAnalysis

    var body: some View {
        VStack(alignment: .leading) {
            Text("健康建議")
                .font(.headline).foregroundColor(.white)
            if analysis.recommendations.isEmpty {
                Text("暫無特別建議").foregroundColor(.gray)
            } else {
                ForEach(analysis.recommendations, id: \.self) { recommendation in
                    HStack {
                        Image(systemName: "checkmark.circle.fill")
                            .foregroundColor(.green)
                        Text(recommendation)
                            .foregroundColor(.white)
                    }
                }
            }
        }
        .padding()
        .background(Color(.systemGray6))
        .cornerRadius(12)
    }
}
