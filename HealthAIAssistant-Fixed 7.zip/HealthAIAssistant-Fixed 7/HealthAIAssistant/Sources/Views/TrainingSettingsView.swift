import SwiftUI

struct TrainingSettingsView: View {
    @EnvironmentObject var modelCoordinator: AIModelCoordinator
    @StateObject private var csv = CSVDataManager.shared
    @State private var isTraining = false
    @State private var status: String = "尚未開始"
    @State private var epochs: Int = 20
    @State private var batchSize: Int = 32

    var body: some View {
        Form {
            Section(header: Text("裝置扮演角色")) {
                Text("建議在 iPad 上進行較重訓練，完成後把模型權重匯出，並在 iPhone 匯入使用。")
                    .font(.footnote).foregroundColor(.secondary)
            }
            Section(header: Text("重訓參數（僅 iPad 建議）")) {
                Stepper("Epochs: \(epochs)", value: $epochs, in: 5...200, step: 5)
                Stepper("Batch Size: \(batchSize)", value: $batchSize, in: 8...256, step: 8)
                Button {
                    isTraining = true
                    status = "訓練中…"
                    DispatchQueue.global(qos: .userInitiated).async {
                        Trainer.shared.trainHeavy(records: csv.records, coordinator: modelCoordinator, epochs: epochs, batchSize: batchSize)
                        DispatchQueue.main.async {
                            isTraining = false
                            status = "完成"
                        }
                    }
                } label: {
                    Label("開始重訓", systemImage: "bolt.fill")
                }.disabled(isTraining || csv.records.isEmpty)
                Text("狀態：\(status)")
            }
            Section(header: Text("模型權重同步")) {
                WeightsSyncView()
            }
        }
        .navigationTitle("訓練與同步")
    }
}

struct WeightsSyncView: View {
    @EnvironmentObject var modelCoordinator: AIModelCoordinator
    @State private var showExporter = false
    @State private var showImporter = false
    @State private var dataOut = Data()

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Button {
                // 打包目前的 regressor + attentive 權重
                let reg = modelCoordinator.loadOnlineModel(featureCount: 7 + modelCoordinator.loadAttentive(dIn:7).dModel)
                let attn = modelCoordinator.loadAttentive(dIn: 7)
                ModelWeightsManager.shared.save(reg: reg, attn: attn)
                dataOut = ModelWeightsManager.shared.exportData()
                showExporter = true
            } label: {
                Label("匯出模型權重", systemImage: "square.and.arrow.up")
            }
            Button {
                showImporter = true
            } label: {
                Label("匯入模型權重", systemImage: "square.and.arrow.down")
            }
        }
        .fileExporter(isPresented: $showExporter, document: ExportDataDocument(data: dataOut), contentType: .modelWeights, defaultFilename: "model_weights.json") { _ in }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.json, .modelWeights]) { result in
            if case let .success(url) = result, let data = try? Data(contentsOf: url) {
                ModelWeightsManager.shared.importData(data)
            }
        }
    }
}
