import SwiftUI

struct ChatView: View {
    @EnvironmentObject var modelCoordinator: AIModelCoordinator
    @State private var messageText = ""
    @State private var messages: [(String, String)] = []
    
    var body: some View {
        VStack {
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack {
                        ForEach(messages.indices, id: \.self) { index in
                            ChatMessageView(message: messages[index])
                        }
                    }
                }
            }
            
            HStack {
                TextField("輸入問題...", text: $messageText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                
                Button(action: sendMessage) {
                    Image(systemName: "arrow.up.circle.fill")
                }
            }
            .padding()
        }
        .navigationTitle("健康諮詢")
    }
    
    private func sendMessage() {
        guard !messageText.isEmpty else { return }
        let query = messageText
        messageText = ""
        
        Task {
            let response = await modelCoordinator.processMedicalQuery(
                query,
                withContext: nil
            )
            messages.append((query, response))
        }
    }
}
