import SwiftUI

struct HistoryView: View {
    var body: some View {
        VStack {
            Text("歷史記錄")
                .font(.title)
                .foregroundColor(.white)
            Text("（此處可擴展為顯示過去分析結果、趨勢圖等）")
                .foregroundColor(.gray)
        }
        .padding()
        .background(Color.black)
    }
}
