import SwiftUI

struct HistoryImportView: View {
    @State private var days = 180
    @State private var isImporting = false
    var body: some View {
        Form {
            Section(header: Text("個人化起步")) {
                Picker("匯入天數", selection: $days) {
                    Text("30 天").tag(30)
                    Text("60 天").tag(60)
                    Text("90 天").tag(90)
                    Text("180 天").tag(180)
                }
                .pickerStyle(.segmented)
                Button {
                    isImporting = true
                    BootstrapTrainer.shared.startBootstrap(lookbackDays: days)
                    DispatchQueue.main.asyncAfter(deadline: .now()+1.0) { isImporting = false }
                } label: {
                    HStack {
                        if isImporting { ProgressView() }
                        Text("匯入歷史並立即個人化")
                    }
                }
            }
            Section(footer: Text("若目前未充電或不在 00:00–07:00，系統會自動安排下一次夜間充電時執行。")) {
                Button("只安排夜間訓練（不立即匯入）") {
                    BootstrapTrainer.shared.runTrainingNowIfAllowed(orSchedule: true)
                }
            }
        }
        .navigationTitle("歷史匯入與個人化")
    }
}
