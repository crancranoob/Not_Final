import SwiftUI
import UniformTypeIdentifiers

struct SettingsView: View {
    @State private var showExporter = false
    @State private var showImporter = false
    @State private var exportData: Data = Data()
    
    private func makeExportData() {
        // TODO: Replace this with real CSV generation from your data source
        let csvString = "id,date,value\n"
        self.exportData = Data(csvString.utf8)
        self.showExporter = true
    }

    private func importCSV(_ data: Data) {
        // TODO: Parse CSV and update your data model accordingly
        // This is a placeholder to keep compilation working.
    }
    
    var body: some View {
        VStack {
            Text("設定")
                .font(.title)
                .foregroundColor(.white)
            NavigationLink(destination: ResearchSettingsView()) {
                Label("研究模式與白名單", systemImage: "graduationcap")
            }
            Button {
                makeExportData()
            } label: {
                Label("匯出 CSV", systemImage: "square.and.arrow.up")
            }
            Button {
                showImporter = true
            } label: {
                Label("匯入 CSV", systemImage: "square.and.arrow.down")
            }

            Text("（此處可擴展為用戶授權、數據同步、隱私設定等）")
                .foregroundColor(.gray)
        }
        .padding()
        .background(Color.black)
        .fileExporter(
            isPresented: $showExporter,
            document: ExportDataDocument(data: exportData),
            contentType: .commaSeparatedText,
            defaultFilename: "health_records.csv"
        ) { _ in }
        .fileImporter(
            isPresented: $showImporter,
            allowedContentTypes: [.commaSeparatedText]
        ) { result in
            if case let .success(url) = result, let data = try? Data(contentsOf: url) {
                importCSV(data)
            }
        }
    }
}

struct ExportDataDocument: FileDocument {
    static var readableContentTypes: [UTType] { [.commaSeparatedText] }
    var data: Data
    init(data: Data) { self.data = data }
    init(configuration: ReadConfiguration) throws { self.data = Data() }
    func fileWrapper(configuration: WriteConfiguration) throws -> FileWrapper {
        return .init(regularFileWithContents: data)
    }
}

struct ResearchSettingsView: View {
    var body: some View {
        Text("研究模式設定")
            .padding()
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
