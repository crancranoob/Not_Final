import SwiftUI

struct ContentView: View {
    @EnvironmentObject var healthKitManager: HealthKitManager
    @EnvironmentObject var modelCoordinator: AIModelCoordinator
    
    var body: some View {
        NavigationSplitView {
            SidebarView()
        } detail: {
            MainContentView()

            DailyCheckInView { score in
                modelCoordinator.learnFromCheckIn(data: healthKitManager.healthData, userScore: score)
            }
            .padding(.top, 12)
    
            .onChange(of: healthKitManager.healthData) { _, newValue in
                modelCoordinator.analyze(data: newValue)
            }
        }
        .preferredColorScheme(.dark)
    }
}

struct SidebarView: View {
    @State private var selection: String? = "dashboard"
    
    var body: some View {
        List(selection: $selection) {
            NavigationLink("儀表板", value: "dashboard")
            NavigationLink("健康分析", value: "analysis")
            NavigationLink("歷史記錄", value: "history")
            NavigationLink("設定", value: "settings")
        }
        .listStyle(.sidebar)
        .tint(.white)
    }
}

struct MainContentView: View {
    var body: some View {
        ZStack {
            Color.black.edgesIgnoringSafeArea(.all)
            
            TabView {
                DashboardView()
                AnalysisView()
                HistoryView()
                SettingsView()
            }
        }
    }
}
