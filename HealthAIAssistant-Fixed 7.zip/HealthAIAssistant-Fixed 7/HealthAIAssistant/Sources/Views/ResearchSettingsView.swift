import SwiftUI

struct ResearchSettingsView: View {
    @AppStorage("researchModeEnabled") private var researchModeEnabled: Bool = false
    @StateObject private var whitelist = WhitelistManager.shared
    @State private var newSource: String = ""

    var body: some View {
        Form {
            Section(header: Text("研究模式")) {
                Toggle("啟用研究模式（背景更新知識庫）", isOn: $researchModeEnabled)
                    .onChange(of: researchModeEnabled) { _, enabled in
                        if enabled {
                            KnowledgeUpdater.shared.scheduleNextUpdate()
                        } else {
                            KnowledgeUpdater.shared.cancelAll()
                        }
                    }
                Text("研究模式會定期從白名單來源抓取論文摘要，僅存為『知識庫』，不會直接改模型權重。")
                    .font(.footnote).foregroundColor(.secondary)
            }

            Section(header: Text("白名單來源（RSS/網址）")) {
                HStack {
                    TextField("貼上 RSS 或可信網址", text: $newSource)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    Button("加入") {
                        whitelist.add(newSource)
                        newSource = ""
                    }
                    .disabled(newSource.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                if whitelist.sources.isEmpty {
                    Text("尚未加入來源。").foregroundColor(.secondary)
                } else {
                    List {
                        ForEach(whitelist.sources, id: \.self) { s in
                            Text(s).font(.caption)
                                .textSelection(.enabled)
                        }
                        .onDelete(perform: whitelist.remove)
                    }.frame(minHeight: 120)
                }
            }
        }
        .navigationTitle("研究模式與白名單")
    }
}
