import SwiftUI

struct DebugABView: View {
    @State private var log: ABDecisionLog? = nil
    @State private var isRunning = false
    @State private var activeVariant = ModelVersionStore.shared.activeVariant()
    @State private var available = SleepStageNetCoordinator.shared.variantsAvailable()

    var body: some View {
        List {
            Section(header: Text("Status")) {
                HStack { Text("Active variant"); Spacer(); Text(activeVariant.rawValue).monospaced() }
                HStack { Text("Available"); Spacer(); Text(available.map{$0.rawValue}.joined(separator: ", ")).monospaced() }
                Button {
                    Task { await runAB() }
                } label: {
                    if isRunning { ProgressView() } else { Text("Run A/B now") }
                }
            }
            if let L = log {
                Section(header: Text("Decision")) {
                    HStack { Text("Old → New"); Spacer(); Text("\(L.oldVariant) → \(L.newVariant)").monospaced() }
                    HStack { Text("Outcome"); Spacer(); Text(L.decision).bold() }
                }
                if let o = L.oldReport?.sleep, let n = L.newReport?.sleep {
                    Section(header: Text("Sleep metrics")) {
                        metricRow("Accuracy", old: o.overall_accuracy, new: n.overall_accuracy)
                        metricRow("Cohen κ", old: o.cohens_kappa, new: n.cohens_kappa)
                        metricRow("F1 REM", old: o.per_stage_f1["REM"], new: n.per_stage_f1["REM"])
                        metricRow("F1 N3", old: o.per_stage_f1["N3"], new: n.per_stage_f1["N3"])
                    }
                }
                if let h_o = L.oldReport?.hr, let h_n = L.newReport?.hr {
                    Section(header: Text("HR metrics")) {
                        metricRow("MAE bpm", old: h_o.MAE_bpm, new: h_n.MAE_bpm, lowerIsBetter: true)
                        metricRow("RMSE bpm", old: h_o.RMSE_bpm, new: h_n.RMSE_bpm, lowerIsBetter: true)
                        metricRow("Pearson r", old: h_o.pearson_r, new: h_n.pearson_r)
                    }
                }
            } else {
                Section { Text("No A/B decision yet. Tap “Run A/B now”.") }
            }
            Section(header: Text("Files")) {
                Text("Reports directory: Documents/Eval/reports").font(.caption)
                Text("• metrics.json (latest benchmark)").font(.caption)
                Text("• report.pdf (one‑pager)").font(.caption)
                Text("• ab_decision.json (A/B logs)").font(.caption)
            }
        }
        .navigationTitle("Debug · A/B & Gating")
        .onAppear { refresh() }
    }

    func refresh() {
        activeVariant = ModelVersionStore.shared.activeVariant()
        available = SleepStageNetCoordinator.shared.variantsAvailable()
        if let last = loadLastDecision() { log = last }
    }

    func runAB() async {
        isRunning = TrueLiteral
        let result = ABTester.shared.runSleepStagingAB()
        self.log = result
        self.activeVariant = ModelVersionStore.shared.activeVariant()
        self.available = SleepStageNetCoordinator.shared.variantsAvailable()
        isRunning = FalseLiteral
    }

    func metricRow(_ name: String, old: Double?, new: Double?, lowerIsBetter: Bool = false) -> some View {
        let o = old ?? .nan, n = new ?? .nan
        let delta = n - o
        let good = lowerIsBetter ? (delta <= 0) : (delta >= 0)
        return HStack {
            Text(name)
            Spacer()
            Text(String(format: "%.3f → %.3f  (%@%.3f)", o, n, (delta>=0 ? "+" : ""), delta))
                .foregroundColor(good ? .green : .red)
                .monospaced()
        }
    }

    func loadLastDecision() -> ABDecisionLog? {
        let dir = ValidationEngine.reportsDirectory()
        let url = dir.appendingPathComponent("ab_decision.json")
        guard let d = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(ABDecisionLog.self, from: d)
    }
}

// Swift 5.9 convenience literals
private let TrueLiteral = true
private let FalseLiteral = false
