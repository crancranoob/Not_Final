import SwiftUI

struct AnalysisView: View {
    @EnvironmentObject var healthKitManager: HealthKitManager
    @State private var sleepResult: SleepAnalysisResult?
    @State private var federatedResult: SleepAnalysisResult?
    @State private var errorMessage: String?
    
    var body: some View {
        VStack(spacing: 20) {
            Text("睡眠分析")
                .font(.title)
                .foregroundColor(.white)
            
            if let result = sleepResult {
                VStack(alignment: .leading, spacing: 10) {
                    Text("總睡眠時數：\(String(format: "%.1f", result.totalHours)) 小時")
                    Text("睡眠效率：\(String(format: "%.1f", result.sleepEfficiency))%")
                    Text("睡眠潛伏期：\(String(format: "%.1f", result.sleepLatency)) 分鐘")
                    Text("醒來次數：\(result.wakeCount)")
                    Text("REM 比例：\(String(format: "%.1f", result.remRatio * 100))%")
                    Text("深層睡眠比例：\(String(format: "%.1f", result.deepRatio * 100))%")
                    Text("淺層睡眠比例：\(String(format: "%.1f", result.lightRatio * 100))%")
                    Text("睡眠分數：\(String(format: "%.1f", result.score))")
                }
                .foregroundColor(.white)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
            } else if let error = errorMessage {
                Text(error).foregroundColor(.red)
            } else {
                Button("分析睡眠") {
                    analyzeSleep()
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(8)
            }
            
            if let federated = federatedResult {
                VStack(alignment: .leading, spacing: 10) {
                    Text("（聯邦學習聚合結果）")
                        .foregroundColor(.yellow)
                    Text("睡眠分數（聚合）：\(String(format: "%.1f", federated.score))")
                }
                .foregroundColor(.white)
                .padding()
                .background(Color(.systemGray6))
                .cornerRadius(12)
            } else if let error = errorMessage {
                Text(error).foregroundColor(.red)
            } else {
                Button("聯邦學習聚合分析") {
                    federatedSleepAnalysis()
                }
                .padding()
                .background(Color.purple)
                .foregroundColor(.white)
                .cornerRadius(8)
            }
        }
        .padding()
        .background(Color.black)
    }
    
    private func analyzeSleep() {
        Task {
            do {
                let engine = SleepAnalysisEngine()
                let result = try await engine.analyzeSleep(for: Date())
                sleepResult = result
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
    
    private func federatedSleepAnalysis() {
        Task {
            do {
                let engine = SleepAnalysisEngine()
                let result = try await engine.federatedSleepAnalysis(for: Date())
                federatedResult = result
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
