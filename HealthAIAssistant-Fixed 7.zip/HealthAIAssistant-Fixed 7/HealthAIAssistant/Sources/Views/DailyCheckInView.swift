import SwiftUI

struct DailyCheckInView: View {
    @EnvironmentObject var healthKitManager: HealthKitManager
    @EnvironmentObject var modelCoordinator: AIModelCoordinator
    @AppStorage("lastCheckIn") private var lastCheckIn: String = ""
    @State private var rating: Double = 3
    let onSubmit: (Double) -> Void

    var body: some View {
        VStack(spacing: 16) {
            Text("今日感覺如何？")
                .font(.title2)
            HStack {
                Text("差")
                Slider(value: $rating, in: 1...5, step: 1)
                Text("好")
            }
            .accessibilityLabel("每日自評")
            Button("提交") {
                onSubmit(rating)
                CSVDataManager.shared.addToday(from: healthKitManager.healthData, userScore: rating)
                lastCheckIn = ISO8601DateFormatter().string(from: Date())
            }
            .buttonStyle(.borderedProminent)
            if !lastCheckIn.isEmpty {
                Text("上次提交：\(lastCheckIn)")
                    .font(.footnote)
                    .foregroundColor(.secondary)
            }
        }
        .padding()
    }
}
