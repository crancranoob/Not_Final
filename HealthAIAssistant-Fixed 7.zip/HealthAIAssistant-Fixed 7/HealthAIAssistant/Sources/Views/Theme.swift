import SwiftUI

enum Theme {
    static let background = Color.black
    static let foreground = Color.white
    static let accent = Color.blue
    static let secondary = Color(.systemGray6)
    
    static let cardBackground = Color(.systemGray6)
    static let metricBackground = Color(.systemGray5)
    
    static let titleFont = Font.system(size: 24, weight: .bold)
    static let bodyFont = Font.system(size: 16)
    static let captionFont = Font.system(size: 12)
}
