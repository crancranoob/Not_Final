import Foundation
import Accelerate

struct SignalFeatures {
    // 基本統計
    static func basicStats(_ x: [Double]) -> [Double] {
        guard !x.isEmpty else { return Array(repeating: 0, count: 5) }
        var mean = 0.0
        vDSP.meanvD(x, 1, &mean, vDSP_Length(x.count))
        var std = 0.0
        vDSP.normalizedRootMeanSquareDistanceD(x, x.map{_ in mean}, &std, vDSP_Length(x.count))
        let minv = x.min() ?? 0
        let maxv = x.max() ?? 0
        let range = maxv - minv
        return [mean, std, minv, maxv, range]
    }

    // 簡化頻域能量分布（低/中/高 頻帶）
    static func spectralBands(_ x: [Double]) -> [Double] {
        let n = x.count
        guard n > 8 else { return [0,0,0] }
        let log2n = vDSP_Length(round(log2(Double(n))))
        let fftLength = 1 << log2n
        let half = fftLength / 2
        let realp = UnsafeMutablePointer<Double>.allocate(capacity: half)
        let imagp = UnsafeMutablePointer<Double>.allocate(capacity: half)
        defer { realp.deallocate(); imagp.deallocate() }
        var splitComplex = DSPDoubleSplitComplex(realp: realp, imagp: imagp)
        var window = [Double](repeating: 0, count: fftLength)
        vDSP_hann_windowD(&window, vDSP_Length(fftLength), Int32(vDSP_HANN_NORM))
        var inbuf = Array(x.prefix(fftLength))
        vDSP.multiply(inbuf, window, result: &inbuf)
        let setup = vDSP_DFT_zop_CreateSetupD(nil, vDSP_Length(fftLength), vDSP_DFT_Direction.FORWARD)!
        vDSP_DFT_ExecuteD(setup, inbuf, [Double](repeating: 0, count: fftLength), &splitComplex.realp.pointee, &splitComplex.imagp.pointee)
        vDSP_DFT_DestroySetupD(setup)
        var magsq = [Double](repeating: 0, count: Int(half))
        vDSP.squareMagnitudes(splitComplex, result: &magsq)
        let thirds = Int(half)/3
        let low = magsq[0..<thirds].reduce(0,+)
        let mid = magsq[thirds..<(2*thirds)].reduce(0,+)
        let hi = magsq[(2*thirds)..<Int(half)].reduce(0,+)
        return [low, mid, hi]
    }

    // 將多個 scalar 特徵合併
    static func concat(_ arrays: [[Double]]) -> [Double] {
        return arrays.flatMap { $0 }
    }
}
