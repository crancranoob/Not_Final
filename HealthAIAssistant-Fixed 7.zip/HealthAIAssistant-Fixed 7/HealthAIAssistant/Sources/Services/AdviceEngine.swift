import Foundation

final class AdviceEngine {
    static let shared = AdviceEngine()

    func advice(for data: HealthData, personalizedScore: Double, knowledge: [KnowledgeUpdater.KnowledgeItem]) -> String {
        var lines: [String] = []
        // 1) 基於個人化分數與閾值
        if personalizedScore < 2.5 {
            lines.append("今日整體狀態偏低，建議調整作息與降低晚間刺激（咖啡因、藍光）。")
        } else if personalizedScore < 3.5 {
            lines.append("狀態中等，可考慮輕量運動與提早就寢以改善恢復。")
        } else {
            lines.append("狀態良好，維持規律活動與補水。")
        }
        // 2) 指標偵測
        if data.sleepHours < 6 {
            lines.append("昨夜睡眠不足（<6 小時），建議今晚增加睡眠時數。")
        }
        if data.heartRate > 100 {
            lines.append("心率偏高，留意壓力或過度訓練跡象。")
        }
        if data.oxygenSaturation > 0 && data.oxygenSaturation < 0.94 {
            lines.append("SpO₂ 偏低，若持續出現請考慮專業諮詢。")
        }
        // 3) 知識庫引用（僅附上最近 1 條）
        let kvs = KnowledgeVectorStore.shared
        let query = "sleep recovery heart rate variability training fatigue"
        let sourceWeights = ["https://pubmed.": 1.2, "https://arxiv.": 1.1]
        let top = kvs.topK(for: query, items: knowledge, k: 1, sourceWeights: sourceWeights)
        if let (latest, conf) = top.first {
            lines.append(String(format: "近期研究（置信度 %.2f）：%@（來源：%@）", conf, latest.summary, latest.url))
        }
        return lines.joined(separator: " ")
    }
}
