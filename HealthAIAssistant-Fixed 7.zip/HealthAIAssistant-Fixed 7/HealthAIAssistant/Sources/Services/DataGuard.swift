import Foundation

struct ValidationIssue: Identifiable, Codable {
    let id = UUID()
    let date: Date
    let field: String
    let message: String
    let severity: Severity
    enum Severity: String, Codable { case warning, error }
}

final class DataGuard {
    static let shared = DataGuard()
    private init() {}

    /// Validate raw HealthData ranges & coherence.
    func validate(_ d: HealthData) -> [ValidationIssue] {
        var issues: [ValidationIssue] = []
        let now = Date()
        func add(_ field: String, _ msg: String, _ sev: ValidationIssue.Severity = .warning) {
            issues.append(ValidationIssue(date: now, field: field, message: msg, severity: sev))
        }
        // Plausible ranges (consumer-grade)
        if !(30...220).contains(d.heartRate) && d.heartRate > 0 { add("heartRate", "Out of plausible range: \(d.heartRate) bpm") }
        if !(0...300000).contains(d.steps) { add("steps", "Steps looks wrong: \(d.steps)") }
        if !(0...20000).contains(d.activeEnergy) { add("activeEnergy", "Active energy looks wrong: \(d.activeEnergy) kcal") }
        if !(0...18).contains(d.sleepHours) { add("sleepHours", "Sleep hours out of range: \(d.sleepHours) h") }
        if d.oxygenSaturation > 0 && !(0.85...1.0).contains(d.oxygenSaturation) { add("oxygenSaturation", "SpO₂ should be 0.85–1.00 (fraction): \(d.oxygenSaturation)") }
        if !(30...43).contains(d.bodyTemperature) && d.bodyTemperature > 0 { add("bodyTemperature", "Temp (°C) out of range: \(d.bodyTemperature)") }
        if !(0...1).contains(d.walkingStability) && d.walkingStability > 0 { add("walkingStability", "Normalized walking stability should be 0–1: \(d.walkingStability)") }
        if d.hrvSDNN > 0 && !(5...300).contains(d.hrvSDNN) { add("hrvSDNN", "HRV SDNN (ms) out of range: \(d.hrvSDNN)") }
        if d.respiratoryRate > 0 && !(6...40).contains(d.respiratoryRate) { add("respiratoryRate", "Resp rate out of range: \(d.respiratoryRate) /min") }
        // Coherence checks
        if d.steps < 200 && d.activeEnergy > 1500 { add("activeEnergy", "High energy with very low steps; verify watch wear time or workouts.", .warning) }
        if d.sleepHours < 3 && d.heartRate < 40 { add("heartRate", "Very low HR with very short sleep; verify measurements.", .warning) }
        return issues
    }
}
