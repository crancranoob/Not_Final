import Foundation

final class WeightsSyncManager: ObservableObject {
    static let shared = WeightsSyncManager()
    private let kv = NSUbiquitousKeyValueStore.default
    private let key = "model_weights_b64"

    func push() {
        let data = ModelWeightsManager.shared.exportData()
        guard !data.isEmpty else { return }
        let b64 = data.base64EncodedString()
        kv.set(b64, forKey: key)
        kv.synchronize()
    }

    func pull() {
        kv.synchronize()
        guard let b64 = kv.string(forKey: key), let data = Data(base64Encoded: b64) else { return }
        ModelWeightsManager.shared.importData(data)
    }
}
