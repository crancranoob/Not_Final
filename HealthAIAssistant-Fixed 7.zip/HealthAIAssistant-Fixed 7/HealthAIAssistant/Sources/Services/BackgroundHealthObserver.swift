import Foundation
import HealthKit
import BackgroundTasks

final class BackgroundHealthObserver {
    static let shared = BackgroundHealthObserver()
    private let healthStore = HKHealthStore()
    private var isSetUp = false

    func setUp() {
        guard HKHealthStore.isHealthDataAvailable(), !isSetUp else { return }
        isSetUp = true

        // Register BG task for periodic refresh (fallback)
        BGTaskScheduler.shared.register(forTaskWithIdentifier: "com.hardychan.HealthAIAssistant.refresh", using: nil) { task in
            self.handleAppRefresh(task: task as! BGAppRefreshTask)
        }

        // Enable background delivery for key types
        let types: [HKSampleType] = [
            HKObjectType.quantityType(forIdentifier: .heartRate)!,
            HKObjectType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!,
            HKObjectType.quantityType(forIdentifier: .respiratoryRate)!,
            HKObjectType.quantityType(forIdentifier: .oxygenSaturation)!,
            HKObjectType.quantityType(forIdentifier: .bodyTemperature)!,
            HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!,
            HKObjectType.quantityType(forIdentifier: .stepCount)!,
            HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)!
        ]
        for t in types {
            healthStore.enableBackgroundDelivery(for: t, frequency: .immediate) { _, _ in }
            startObserver(for: t)
        }
        scheduleRefresh()
    }

    private func startObserver(for type: HKSampleType) {
        let q = HKObserverQuery(sampleType: type, predicate: nil) { [weak self] _, completion, error in
            defer { completion() }
            guard error == nil else { return }
            self?.fetchAnchoredUpdates(for: type)
        }
        healthStore.execute(q)
    }

    private var anchors: [String: HKQueryAnchor] = [:]

    private func fetchAnchoredUpdates(for type: HKSampleType) {
        let key = type.identifier
        let anchor = anchors[key] ?? HKQueryAnchor(fromValue: HKAnchoredObjectQueryNoAnchor)
        let query = HKAnchoredObjectQuery(type: type, predicate: nil, anchor: anchor, limit: HKObjectQueryNoLimit) { [weak self] _, samplesOrNil, deleted, newAnchor, error in
            guard let self = self, error == nil else { return }
            self.anchors[key] = newAnchor

            let count = samplesOrNil?.count ?? 0
            if count > 0 {
                // Recompute risks & notify if needed
                DispatchQueue.main.async {
                    let data = HealthKitManager.shared.healthData
                    let (riskSummary, alerts) = RiskEngine.shared.evaluateAll(from: data)
                    for a in alerts { NotificationManager.shared.notify(title: a.title, body: a.body) }
                    let goals = GoalsEngine.shared.status(for: data)
                    if !goals.metSleep || !goals.metSteps || !goals.metEnergy {
                        NotificationManager.shared.notify(title: "目標偏離提醒", body: "睡眠:\(goals.metSleep ? "✅" : "❌") 步數:\(goals.metSteps ? "✅" : "❌") 能量:\(goals.metEnergy ? "✅" : "❌")")
                    }
                }
            }
        }
        healthStore.execute(query)
    }

    // BG refresh as a safety net
    func scheduleRefresh() {
        let req = BGAppRefreshTaskRequest(identifier: "com.hardychan.HealthAIAssistant.refresh")
        req.earliestBeginDate = Date(timeIntervalSinceNow: 60*30) // 30 mins
        try? BGTaskScheduler.shared.submit(req)
    }
    private func handleAppRefresh(task: BGAppRefreshTask) {
        scheduleRefresh()
        task.expirationHandler = { }
        // Minimal refresh work: check backup age & recompute risks
        BackupManager.shared.checkBackupAge(maxDays: 7)
        let data = HealthKitManager.shared.healthData
        let (_, alerts) = RiskEngine.shared.evaluateAll(from: data)
        for a in alerts { NotificationManager.shared.notify(title: a.title, body: a.body) }
        task.setTaskCompleted(success: true)
    }
}
