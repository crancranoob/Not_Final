import Foundation

final class Profiler {
    static func time<T>(_ label: String, _ block: () -> T) -> T {
        let t0 = CFAbsoluteTimeGetCurrent()
        let result = block()
        let dt = CFAbsoluteTimeGetCurrent() - t0
        print("[Profiler] \(label): \(String(format: "%.3f", dt)) s")
        return result
    }
}
