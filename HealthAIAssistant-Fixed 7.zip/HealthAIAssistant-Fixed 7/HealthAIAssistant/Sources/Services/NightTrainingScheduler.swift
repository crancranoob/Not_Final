import Foundation
import BackgroundTasks
import UIKit

final class NightTrainingScheduler {
    static let shared = NightTrainingScheduler()
    private init() {}

    private let taskId = "com.hardychan.HealthAIAssistant.nighttrain"

    func register() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: taskId, using: nil) { task in
            self.handle(task as! BGProcessingTask)
        }
    }
    func schedule() {
        let req = BGProcessingTaskRequest(identifier: taskId)
        req.requiresExternalPower = true
        req.requiresNetworkConnectivity = false
        // iOS decides exact time; we'll guard at runtime for 00:00–07:00
        do { try BGTaskScheduler.shared.submit(req) } catch { print("BG submit error: \(error)") }
    }
    private func withinWindow(_ date: Date = Date()) -> Bool {
        let h = Calendar.current.component(.hour, from: date)
        return (0 <= h && h < 7)
    }
    private func isCharging() -> Bool {
        UIDevice.current.isBatteryMonitoringEnabled = true
        return UIDevice.current.batteryState == .charging || UIDevice.current.batteryState == .full
    }
    private func handle(_ task: BGProcessingTask) {
        schedule() // reschedule next
        task.expirationHandler = {
            // Best effort save current checkpoint
        }
        guard withinWindow(), isCharging() else {
            task.setTaskCompleted(success: true)
            return
        }
        DispatchQueue.global(qos: .utility).async {
            let csv = CSVDataManager.shared.records
            let trainer = Trainer.shared
            let coord = AIModelCoordinator.shared
            // Resumable heavy training
            trainer.trainHeavyNight(records: csv, coordinator: coord)

            // Sleep model nightly training
            SleepTrainer.shared.trainNight()
            _ = TeacherAnalyzer.shared.analyze(records: csv, coordinator: coord)
            NightOrchestrator.shared.runAll(records: csv, coordinator: coord)
            DistillationTrainer.shared.distillAtNight(records: csv, coordinator: coord)

            task.setTaskCompleted(success: true)
        }
    }
}
