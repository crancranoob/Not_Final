import Foundation

final class WhitelistManager: ObservableObject {
    static let shared = WhitelistManager()
    @Published var sources: [String] = []

    private let storeURL: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("whitelist.json")
    }()

    init() {
        load()
        if sources.isEmpty {
            // 建議的安全白名單（示意）
            sources = [
                "https://export.arxiv.org/api/query?search_query=all:sleep+OR+heart+rate&start=0&max_results=5",
                "https://pubmed.ncbi.nlm.nih.gov/?term=sleep+heart+rate&filter=simsearch1.fha&size=50"
            ]
            save()
        }
    }

    func load() {
        guard let data = try? Data(contentsOf: storeURL) else { return }
        if let list = try? JSONDecoder().decode([String].self, from: data) {
            sources = list
        }
    }
    func save() {
        if let data = try? JSONEncoder().encode(sources) {
            try? data.write(to: storeURL)
        }
    }
    func add(_ url: String) {
        let trimmed = url.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        if !sources.contains(trimmed) { sources.append(trimmed); save() }
    }
    func remove(at offsets: IndexSet) {
        sources.remove(atOffsets: offsets)
        save()
    }
}
