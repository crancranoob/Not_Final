import Foundation

final class DailyReportEngine {
    static let shared = DailyReportEngine()

    func buildReport(for d: HealthData, coordinator: AIModelCoordinator) -> String {
        // Scores
        let (score, usedFallback, warn) = coordinator.safePersonalizedScore(from: d)
        let knowledge = KnowledgeUpdater.shared.loadKnowledge()
        let advice = AdviceEngine.shared.advice(for: d, personalizedScore: score, knowledge: knowledge)

        // Risk summary
        let (riskSummary, alerts) = RiskEngine.shared.evaluateAll(from: d)

        var blocks: [String] = []
        blocks.append("# 每日健康總結")
        blocks.append(String(format: "今日個人化分數：**%.2f/5** %@", score, usedFallback ? "（採用保守回退）" : ""))
        if let w = warn { blocks.append("> 檢核：\(w)") }

        // Compare vs 7d rolling baseline (very light)
        let hr = d.heartRate, hrv = d.hrvSDNN, rr = d.respiratoryRate, sh = d.sleepHours
        blocks.append("**關鍵指標**：HR=\(Int(hr)) bpm，HRV(SDNN)=\(Int(hrv)) ms，RR=\(String(format: "%.1f", rr))/min，睡眠 \(String(format: "%.1f", sh)) h。")

        // Validation highlights
        let issues = DataGuard.shared.validate(d)
        if !issues.isEmpty {
            let top = issues.prefix(3).map { "- \($0.field)：\($0.message)" }.joined(separator: "\n")
            blocks.append("**資料檢核**：\n\(top)\(issues.count > 3 ? "\n…": "")")
        } else {
            blocks.append("**資料檢核**：未發現明顯問題。")
        }

        // Risk / Prediction
        if !alerts.isEmpty {
            blocks.append("**風險與預測**：")
            for a in alerts { blocks.append("- \(a.title)：\(a.body)") }
        } else {
            blocks.append("**風險與預測**：目前無顯著風險。")
        }

        // Advice + citation
        blocks.append("**個人化建議**：\(advice)\n\n前往「睡眠階段」查看昨夜深眠/REM/效率與覺醒圖。")

        
        // Percentiles & trend (last 30 days if available from CSV)
        let recs = CSVDataManager.shared.records
        let last30 = Array(recs.suffix(30))
        if !last30.isEmpty {
            let hrList = last30.map{ $0.heartRate }
            let hrvList = last30.map{ $0.hrvSDNN ?? 0 }
            let slpList = last30.map{ $0.sleepHours }
            let pHR = StatsEngine.shared.withinPersonPercentile(values: hrList, current: d.heartRate)
            let pHRV = StatsEngine.shared.withinPersonPercentile(values: hrvList, current: d.hrvSDNN)
            let pSlp = StatsEngine.shared.withinPersonPercentile(values: slpList, current: d.sleepHours)
            blocks.append(String(format: "**同人百分位**：HR=%.0f%%（越低越好）、HRV=%.0f%%（越高越好）、睡眠=%.0f%%", pHR*100, pHRV*100, pSlp*100))
            // Trend slopes over time index
            let pairsHR = Array(zip(0..<hrList.count, hrList)).map{ (Double($0.0), $0.1) }
            let pairsHRV = Array(zip(0..<hrvList.count, hrvList)).map{ (Double($0.0), $0.1) }
            let slopeHR = StatsEngine.shared.slope(pairsHR)
            let slopeHRV = StatsEngine.shared.slope(pairsHRV)
            blocks.append(String(format: "**趨勢**：HR slope=%.3f（負向較佳），HRV slope=%.3f（正向較佳）", slopeHR, slopeHRV))
        }
        
        // Explainability: top contributing features today
        let attn = coordinator.loadAttentive(dIn: 9)
        let reg = coordinator.loadOnlineModel(featureCount: 9 + attn.dModel)
        let last = coordinator.features(from: d)
        let embed = attn.forward([last])
        let names = ["HR","Steps","ActiveEnergy","Sleep","SpO2","Temp","Stability","HRV","Resp"] + (0..<attn.dModel).map{ "CTX\($0)" }
        let contribs = Explainability.shared.contributions(lastFeatures: last, embed: embed, reg: reg, names: names)
        let top3 = contribs.prefix(3).map { String(format: "%@: %.3f", $0.name, $0.value) }.joined(separator: "， ")
        blocks.append("**當日影響因子（前 3）**：" + top3)
        
        // Goals, sleep debt & bedtime suggestion
        let st = GoalsEngine.shared.status(for: d)
        var goalLines: [String] = []
        goalLines.append("睡眠 " + (st.metSleep ? "✅" : "❌"))
        goalLines.append("步數 " + (st.metSteps ? "✅" : "❌"))
        goalLines.append("能量 " + (st.metEnergy ? "✅" : "❌"))
        blocks.append("**目標達成**：" + goalLines.joined(separator: " · "))
        let last7 = Array(recs.suffix(7))
        let debt = GoalsEngine.shared.sleepDebt(last7: last7)
        let bt = GoalsEngine.shared.suggestedBedtime(today: Date(), debt: debt)
        blocks.append(String(format: "**睡眠債**：%.1f 小時；**建議就寢**：%02d:%02d（依債務提前）", debt, bt.hour ?? 22, bt.minute ?? 0))

        return blocks.joined(separator: "\n\n")
    }
}
