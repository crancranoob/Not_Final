import Foundation
import HealthKit

final class HealthKitHistoryImporter: ObservableObject {
    static let shared = HealthKitHistoryImporter()
    private let store = HKHealthStore()
    private init() {}

    enum ImportError: Error { case notAuthorized, noData }

    func importDays(lookbackDays: Int = 90, completion: @escaping (Result<[DailyRecord], Error>) -> Void) {
        let end = Date()
        guard let start = Calendar.current.date(byAdding: .day, value: -lookbackDays, to: end) else {
            completion(.failure(ImportError.noData)); return
        }

        // Define types
        guard
            let hrType = HKQuantityType.quantityType(forIdentifier: .heartRate),
            let hrvType = HKQuantityType.quantityType(forIdentifier: .heartRateVariabilitySDNN),
            let rrType = HKQuantityType.quantityType(forIdentifier: .respiratoryRate),
            let spo2Type = HKQuantityType.quantityType(forIdentifier: .oxygenSaturation),
            let tempType = HKQuantityType.quantityType(forIdentifier: .bodyTemperature),
            let stepsType = HKQuantityType.quantityType(forIdentifier: .stepCount),
            let energyType = HKQuantityType.quantityType(forIdentifier: .activeEnergyBurned),
            let sleepType = HKObjectType.categoryType(forIdentifier: .sleepAnalysis)
        else { completion(.failure(ImportError.noData)); return }

        let types: Set<HKObjectType> = [hrType, hrvType, rrType, spo2Type, tempType, stepsType, energyType, sleepType]
// BEGIN Hydration & Caffeine
        guard
            let waterType = HKQuantityType.quantityType(forIdentifier: .dietaryWater),
            let cafeType = HKQuantityType.quantityType(forIdentifier: .dietaryCaffeine)
        else { completion(.failure(ImportError.noData)); return }
        var water: [(Date, Double)] = []
        var cafe: [(Date, Double, Bool)] = [] // (date, mg, isLate)
        func fetchWater() {
            group.enter()
            let pred = HKQuery.predicateForSamples(withStart: start, end: end, options: [])
            let q = HKSampleQuery(sampleType: waterType, predicate: pred, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, _ in
                for s in samples as? [HKQuantitySample] ?? [] {
                    let liters = s.quantity.doubleValue(for: HKUnit.literUnit(with: .milli)).advanced(by: 0) / 1000.0 // ML to L if needed
                    water.append((s.startDate, liters))
                }
                group.leave()
            }
            self.store.execute(q)
        }
        func fetchCaffeine() {
            group.enter()
            let pred = HKQuery.predicateForSamples(withStart: start, end: end, options: [])
            let q = HKSampleQuery(sampleType: cafeType, predicate: pred, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, samples, _ in
                for s in samples as? [HKQuantitySample] ?? [] {
                    let mg = s.quantity.doubleValue(for: HKUnit.gramUnit(with: .milli))
                    let hour = Calendar.current.component(.hour, from: s.startDate)
                    let isLate = hour >= 14
                    cafe.append((s.startDate, mg, isLate))
                }
                group.leave()
            }
            self.store.execute(q)
        }
        fetchWater()
        fetchCaffeine()
// END Hydration & Caffeine

        store.requestAuthorization(toShare: nil, read: types) { ok, _ in
            guard ok else { completion(.failure(ImportError.notAuthorized)); return }

            let group = DispatchGroup()
            var hr: [(Date, Double)] = []
            var hrv: [(Date, Double)] = []
            var rr: [(Date, Double)] = []
            var spo2: [(Date, Double)] = []
            var temp: [(Date, Double)] = []
            var steps: [(Date, Double)] = []
            var energy: [(Date, Double)] = []
            var sleepSamples: [HKCategorySample] = []

            func fetchQuantity(_ type: HKQuantityType, unit: HKUnit, into arr: inout [(Date, Double)]) {
                group.enter()
                let pred = HKQuery.predicateForSamples(withStart: start, end: end, options: [])
                let sort = [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)]
                let q = HKSampleQuery(sampleType: type, predicate: pred, limit: HKObjectQueryNoLimit, sortDescriptors: sort) { _, samples, _ in
                    for s in samples as? [HKQuantitySample] ?? [] {
                        arr.append((s.startDate, s.quantity.doubleValue(for: unit)))
                    }
                    group.leave()
                }
                self.store.execute(q)
            }
            func fetchCategory(_ type: HKCategoryType, into out: inout [HKCategorySample]) {
                group.enter()
                let pred = HKQuery.predicateForSamples(withStart: start, end: end, options: [])
                let sort = [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)]
                let q = HKSampleQuery(sampleType: type, predicate: pred, limit: HKObjectQueryNoLimit, sortDescriptors: sort) { _, samples, _ in
                    out.append(contentsOf: (samples as? [HKCategorySample]) ?? [])
                    group.leave()
                }
                self.store.execute(q)
            }

            fetchQuantity(hrType, unit: HKUnit.count().unitDivided(by: HKUnit.minute()), into: &hr)
            fetchQuantity(hrvType, unit: HKUnit.secondUnit(with: .milli), into: &hrv) // SDNN ms
            fetchQuantity(rrType, unit: HKUnit.count().unitDivided(by: HKUnit.minute()), into: &rr)
            fetchQuantity(spo2Type, unit: HKUnit.percent(), into: &spo2)
            fetchQuantity(tempType, unit: HKUnit.degreeCelsius(), into: &temp)
            fetchQuantity(stepsType, unit: HKUnit.count(), into: &steps)
            fetchQuantity(energyType, unit: HKUnit.kilocalorie(), into: &energy)
            fetchCategory(sleepType, into: &sleepSamples)

            group.notify(queue: .global(qos: .userInitiated)) {
                // Aggregate per day
                var byDay: [Date: DailyRecord] = [:]
                func dayStart(_ d: Date) -> Date {
                    Calendar.current.startOfDay(for: d)
                }
                func rec(_ day: Date) -> DailyRecord {
                    if let r = byDay[day] { return r }
                    var r = DailyRecord(date: day)
                    byDay[day] = r; return r
                }
                func set(_ day: Date, _ updater: (inout DailyRecord) -> Void) {
                    var r = byDay[day] ?? DailyRecord(date: day)
                    updater(&r); byDay[day] = r
                }
                // heart rate (average per day)
                let hrGrouped = Dictionary(grouping: hr, by: { dayStart($0.0) })
                for (day, arr) in hrGrouped {
                    var seq = arr.map{$0.1}
                    let kf = AdaptiveKalman1D(q: 0.05, r: 2.0)
                    seq = kf.filter(seq)
                    seq = HaarWaveletDenoiser.denoise(seq, threshold: 1.2)
                    let avg = seq.reduce(0,+)/Double(max(1, seq.count))
                    set(day) { $0.heartRate = avg }
                }
                // hrv (median per day)
                let hrvGrouped = Dictionary(grouping: hrv, by: { dayStart($0.0) })
                for (day, arr) in hrvGrouped {
                    var seq = arr.map{$0.1}
                    let kf = AdaptiveKalman1D(q: 0.02, r: 5.0)
                    seq = kf.filter(seq)
                    let med = seq.sorted()[seq.count/2]
                    set(day) { $0.hrvSDNN = med }
                }
                // respiratory rate
                let rrGrouped = Dictionary(grouping: rr, by: { dayStart($0.0) })
                for (day, arr) in rrGrouped {
                    let avg = arr.map{$0.1}.reduce(0,+)/Double(arr.count)
                    set(day) { $0.respiratoryRate = avg }
                }
                // SpO2
                let spo2G = Dictionary(grouping: spo2, by: { dayStart($0.0) })
                for (day, arr) in spo2G {
                    let avg = arr.map{$0.1}.reduce(0,+)/Double(arr.count)
                    set(day) { $0.oxygenSaturation = avg/100.0 }
                }
                // temp
                let tempG = Dictionary(grouping: temp, by: { dayStart($0.0) })
                for (day, arr) in tempG {
                    let avg = arr.map{$0.1}.reduce(0,+)/Double(arr.count)
                    set(day) { $0.bodyTemperature = avg }
                }
                // steps
                let stepsG = Dictionary(grouping: steps, by: { dayStart($0.0) })
                for (day, arr) in stepsG {
                    let sum = arr.map{$0.1}.reduce(0,+)
                    set(day) { $0.steps = Int(sum) }
                }
                // active energy
                let energyG = Dictionary(grouping: energy, by: { dayStart($0.0) })
                for (day, arr) in energyG {
                    let sum = arr.map{$0.1}.reduce(0,+)
                    set(day) { $0.activeEnergy = sum }
                }
                // sleep (sum asleep categories per day in hours)
                let sleepByDay = Dictionary(grouping: sleepSamples, by: { dayStart($0.startDate) })
                for (day, arr) in sleepByDay {
                    var total: TimeInterval = 0
                    for s in arr {
                        if s.value == HKCategoryValueSleepAnalysis.asleepCore.rawValue ||
                            s.value == HKCategoryValueSleepAnalysis.asleepDeep.rawValue ||
                            s.value == HKCategoryValueSleepAnalysis.asleepREM.rawValue {
                            total += s.endDate.timeIntervalSince(s.startDate)
                        }
                    }
                    set(day) { $0.sleepHours = total / 3600.0 }
                }

                // hydration per day (liters)
let waterG = Dictionary(grouping: water, by: { dayStart($0.0) })
var ctxArr: [DayContext] = []
for (day, arr) in waterG {
    let sumL = arr.map{$0.1}.reduce(0,+)
    var c = ContextStore.shared.get(day) ?? DayContext(date: day)
    c.hydrationLiters = sumL
    ctxArr.append(c)
}
// caffeine per day (mg) + late mg
let cafeG = Dictionary(grouping: cafe, by: { dayStart($0.0) })
for (day, arr) in cafeG {
    let total = arr.map{$0.1}.reduce(0,+)
    let late = arr.filter{$0.2}.map{$0.1}.reduce(0,+)
    var c = ctxArr.first(where: { Calendar.current.isDate($0.date, inSameDayAs: day) }) ?? (ContextStore.shared.get(day) ?? DayContext(date: day))
    c.caffeineMgTotal = total
    c.caffeineMgLate = late
    if let idx = ctxArr.firstIndex(where: { Calendar.current.isDate($0.date, inSameDayAs: day) }) {
        ctxArr[idx] = c
    } else {
        ctxArr.append(c)
    }
}
// hydration lag (yesterday liters)
let sortedCtx = ctxArr.sorted { $0.date < $1.date }
for i in 0..<sortedCtx.count {
    var c = sortedCtx[i]
    if i > 0 { c.hydrationPrevLiters = sortedCtx[i-1].hydrationLiters }
    ContextStore.shared.set(c)
}

                let imported = byDay.keys.sorted().map { byDay[$0]! }.sorted { $0.date < $1.date }
                if imported.isEmpty { completion(.failure(ImportError.noData)); return }

                // Merge into CSV store (replace overlapping days)
                var existing = CSVDataManager.shared.records
                let existingDays = Set(existing.map { Calendar.current.startOfDay(for: $0.date) })
                let filtered = imported.filter { !existingDays.contains(Calendar.current.startOfDay(for: $0.date)) }
                existing.append(contentsOf: filtered)
                existing.sort { $0.date < $1.date }
                CSVDataManager.shared.records = existing
                CSVDataManager.shared.save()
                completion(.success(imported))
            }
        }
    }
}
