import Foundation

struct ResourceMetrics: Sendable {
    var cpuLoad: Double = 0.0
    var memoryPressure: Double = 0.0
    var gpuUtilization: Double = 0.0
    var memoryAvailable: UInt64 = 0
}

final class ResourceMonitor {
    private let updateInterval: TimeInterval = 1.0
    private var monitoringTask: Task<Void, Never>?
    private let metricsQueue = DispatchQueue(label: "ai.health.metrics")
    
    private var listeners: [(ResourceMetrics) -> Void] = []
    private var currentMetrics: ResourceMetrics = .init()
    
    func startMonitoring(_ listener: @escaping (ResourceMetrics) -> Void) {
        listeners.append(listener)
        
        if monitoringTask == nil {
            monitoringTask = Task {
                while !Task.isCancelled {
                    await updateMetrics()
                    try? await Task.sleep(nanoseconds: UInt64(updateInterval * 1_000_000_000))
                }
            }
        }
    }
    
    private func updateMetrics() async {
        let metrics = ResourceMetrics(
            cpuLoad: await measureCPULoad(),
            memoryPressure: await measureMemoryPressure(),
            gpuUtilization: await measureGPUUtilization(),
            memoryAvailable: await getAvailableMemory()
        )
        
        nonisolated(unsafe) let monitor = self
        
        metricsQueue.async { [metrics] in
            monitor.currentMetrics = metrics
            monitor.notifyListeners(metrics)
        }
    }
    
    private func notifyListeners(_ metrics: ResourceMetrics) {
        // Deliver on main to keep UI listeners safe
        DispatchQueue.main.async {
            for listener in self.listeners {
                listener(metrics)
            }
        }
    }
    
    // MARK: - Metric helpers
    private func measureCPULoad() async -> Double {
        // Use existing project placeholder for CPU load if available
        let load = getCPULoad()
        return max(0.0, min(load, 1.0))
    }

    private func measureMemoryPressure() async -> Double {
        // Approximate memory pressure as used / total
        let total = ProcessInfo.processInfo.physicalMemory
        let used = getMemoryUsage()
        guard total > 0 else { return 0.0 }
        let pressure = Double(used) / Double(total)
        return max(0.0, min(pressure, 1.0))
    }

    private func measureGPUUtilization() async -> Double {
        // No public API for true GPU utilization; use project placeholder for Metal usage
        let metalUsage = getMetalUsage()
        return max(0.0, min(metalUsage, 1.0))
    }

    private func getAvailableMemory() async -> UInt64 {
        let total = ProcessInfo.processInfo.physicalMemory
        let used = getMemoryUsage()
        if used >= total { return 0 }
        return total - used
    }
}
