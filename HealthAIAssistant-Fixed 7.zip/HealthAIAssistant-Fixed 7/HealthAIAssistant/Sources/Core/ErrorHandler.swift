import Foundation
import os.log

final class ErrorHandler {
    private let logger = Logger(subsystem: "com.app.HealthAIAssistant", category: "Errors")

    enum ErrorLevel {
        case info, warning, critical
    }

    func handle(_ error: Error, level: ErrorLevel = .critical, context: [String: Any] = [:]) async {
        let message = "Error: \(error.localizedDescription), Context: \(context)"
        
        switch level {
        case .info:
            logger.info("\(message)")
        case .warning:
            logger.warning("\(message)")
            // 可在此處觸發非阻斷式 UI 提示
        case .critical:
            logger.fault("\(message)")
            // 觸發緊急恢復機制或向用戶顯示嚴重錯誤訊息
            await attemptRecovery(from: error)
        }
    }

    private func attemptRecovery(from error: Error) async {
        // 實現恢復邏輯，例如：
        // - 如果是模型載入失敗，嘗試載入備用模型
        // - 如果是網路錯誤，提示用戶檢查網路並提供重試選項
        // - 如果是數據處理錯誤，跳過該數據點並標記
        logger.error("Attempting recovery from error: \(error.localizedDescription)")
    }
}
