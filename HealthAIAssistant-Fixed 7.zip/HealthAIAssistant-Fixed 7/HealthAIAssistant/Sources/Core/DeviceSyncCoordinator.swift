import Foundation
import CloudKit
import Combine

final class DeviceSyncCoordinator {
    private let syncEngine = SyncEngine()
    private let deviceManager = DeviceManager()
    private let conflictResolver = ConflictResolver()
    
    private var syncSubscriptions = Set<AnyCancellable>()
    private let syncQueue = DispatchQueue(label: "health.sync", qos: .userInitiated)
    
    func setupDeviceSync() {
        // 設置實時同步
        deviceManager.observeConnectedDevices()
            .sink { [weak self] devices in
                self?.handleDeviceStateChange(devices)
            }
            .store(in: &syncSubscriptions)
            
        // 設置數據同步
        syncEngine.observeChanges()
            .sink { [weak self] changes in
                self?.handleDataChanges(changes)
            }
            .store(in: &syncSubscriptions)
    }
    
    private func handleDeviceStateChange(_ devices: [ConnectedDevice]) {
        Task {
            for device in devices {
                switch device.state {
                case .connected:
                    await initiateSyncSession(with: device)
                case .disconnected:
                    await handleDeviceDisconnection(device)
                }
            }
        }
    }
    
    private func initiateSyncSession(with device: ConnectedDevice) async {
        do {
            let session = try await SyncSession(device: device)
            try await syncEngine.startSync(session)
        } catch {
            await handleSyncError(error)
        }
    }
}
