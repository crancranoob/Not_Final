import Foundation
import CoreML
import Metal

final class PerformanceOptimizer {
    private let metalDevice = MTLCreateSystemDefaultDevice()
    private let memoryMonitor = MemoryMonitor()
    private let powerMonitor = PowerMonitor()
    
    func optimizeForDevice() -> DeviceOptimizationPlan {
        let deviceCapabilities = analyzeDeviceCapabilities()
        let memoryBudget = calculateMemoryBudget()
        let powerProfile = powerMonitor.getCurrentProfile()
        
        return DeviceOptimizationPlan(
            quantization: determineOptimalQuantization(deviceCapabilities),
            batchSize: calculateOptimalBatchSize(memoryBudget),
            metalPerformance: configureMetalPerformance(deviceCapabilities),
            powerMode: determinePowerMode(powerProfile)
        )
    }
    
    func monitorResourceUsage(_ completion: @escaping (ResourceMetrics) -> Void) {
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in
            let metrics = ResourceMetrics(
                memory: self.memoryMonitor.getCurrentUsage(),
                cpu: self.getCPUUsage(),
                gpu: self.getGPUUsage(),
                temperature: self.getCurrentTemperature()
            )
            completion(metrics)
        }
    }
    
    private func configureMetalPerformance(_ capabilities: DeviceCapabilities) -> MetalConfig {
        let deviceType = capabilities.deviceType
        
        let config = MetalConfig(
            threadExecutionWidth: determineOptimalThreadWidth(deviceType),
            maxBufferSize: calculateOptimalBufferSize(deviceType),
            pipelineDepth: deviceType == .m4 ? 8 : 4,
            tileSize: deviceType == .m4 ? 32 : 16,
            preferredMemoryLocation: deviceType == .m4 ? .managed : .private
        )
        
        if deviceType == .m4 {
            config.enableHeapResourceManagement()
            config.optimizeForUnifiedMemory()
        } else if deviceType == .a17Pro {
            config.enableTileBasedDeferredRendering()
            config.optimizeForMobileGPU()
        }
        
        return config
    }
    
    private func calculateOptimalBatchSize(_ budget: MemoryBudget) -> Int {
        let deviceMemory = budget.availableMemory
        let modelSize = budget.modelMemoryFootprint
        
        return max(1, Int(deviceMemory * 0.3 / modelSize))
    }
    
    private func determineOptimalQuantization(_ capabilities: DeviceCapabilities) -> QuantizationConfig {
        if capabilities.supportsMixedPrecision {
            return QuantizationConfig(
                weights: .int4,
                activations: .int8,
                gradients: .float16,
                biases: .float32
            )
        }
        return QuantizationConfig(uniform: .int8)
    }
}
