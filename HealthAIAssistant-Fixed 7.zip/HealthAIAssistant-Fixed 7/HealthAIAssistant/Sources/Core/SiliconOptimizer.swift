import Foundation
import CoreML

final class SiliconOptimizer {
    private let deviceProfile: DeviceProfile
    
    init() {
        self.deviceProfile = Self.detectSiliconType()
    }
    
    /// 根據設備類型生成優化的 Core ML 配置（iOS / iPadOS）
    func optimizeForDevice() -> MLModelConfiguration {
        let config = MLModelConfiguration()
        config.computeUnits = .all
        switch deviceProfile.chipType {
        case .m4, .a17Pro:
            if #available(iOS 16.0, *) {
                config.allowLowPrecisionAccumulationOnGPU = true
            }
        case .other:
            config.allowLowPrecisionAccumulationOnGPU = false
        }
        return config
    }

    private static func detectSiliconType() -> DeviceProfile {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }

        if identifier.contains("iPhone16,") || identifier.contains("iPhone15,") {
            return DeviceProfile(chipType: .a17Pro)
        }
        // 預設視為 other
        return DeviceProfile(chipType: .other)
    }
}

private extension SiliconOptimizer {
    struct DeviceProfile {
        enum ChipType {
            case m4
            case a17Pro
            case other
        }
        let chipType: ChipType
    }
}
