import CoreML
import Foundation

final class ModelCache {
    private let memoryCache = NSCache<NSString, MLModel>()
    private let diskCache = DiskCache()
    private let compressionQueue = DispatchQueue(label: "ai.health.modelCache")
    
    func get(_ identifier: String) -> MLModel? {
        if let model = memoryCache.object(forKey: identifier as NSString) {
            return model
        }
        
        if let model = diskCache.retrieve(identifier) {
            memoryCache.setObject(model, forKey: identifier as NSString)
            return model
        }
        
        return nil
    }
    
    func cache(_ model: MLModel, for identifier: String) {
        memoryCache.setObject(model, forKey: identifier as NSString)
        
        compressionQueue.async {
            self.diskCache.store(model, for: identifier)
        }
    }
}
