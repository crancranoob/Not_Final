import Foundation

struct HealthData: Codable {
    var heartRate: Double = 0
    var steps: Int = 0
    var activeEnergy: Double = 0
    var sleepHours: Double = 0
    var oxygenSaturation: Double = 0
    var bodyTemperature: Double = 0
    var walkingStability: Double = 0
    
    var hrvSDNN: Double = 0
    var historicalData: [String: [Double]] = [:]
    var dailyAnalysis: HealthAnalysis?
    
    var caffeine: Double = 0
    var waterIntake: Double = 0
    var bloodPressureSystolic: Double = 0
    var bloodPressureDiastolic: Double = 0
    var respiratoryRate: Double = 0
    var mindfulMinutes: Int = 0
    
    var profile: UserProfile = UserProfile()
    var symptoms: [Symptom] = []
}

struct HealthAnalysis: Codable {
    var date: Date
    var insights: [String]
    var recommendations: [String]
    var trends: [String: Trend]
}

struct Trend: Codable {
    var value: Double
    var change: Double
    var interpretation: String
}

struct UserProfile: Codable {
    let height: Double = 182.0
    let weight: Double = 63.0
    let birthDate: Date = DateFormatter.iso8601Full.date(from: "2008-06-03")!
    let gender: String = "male"
    let ethnicity: String = "Asian"
    let region: String = "Hong Kong"
    
    var age: Int {
        Calendar.current.dateComponents([.year], from: birthDate, to: Date()).year ?? 0
    }
}

struct Symptom: Codable {
    var type: String
    var severity: Int
    var timestamp: Date
    var notes: String?
}
