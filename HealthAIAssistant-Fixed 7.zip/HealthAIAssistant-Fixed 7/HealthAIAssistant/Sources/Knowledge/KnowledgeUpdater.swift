import Foundation
import BackgroundTasks

/// 背景抓取醫學論文摘要的簡化版本（僅示意，實際應加上來源白名單與解析）
final class KnowledgeUpdater {
    static let shared = KnowledgeUpdater()
    static let taskIdentifier = "com.hardychan.healthai.knowledge.refresh"

    private let queue = DispatchQueue(label: "knowledge.updates")
    private let storeURL: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("knowledge.json")
    }()

    /// 註冊 BG 任務
    func registerBackgroundTask() {
        BGTaskScheduler.shared.register(forTaskWithIdentifier: Self.taskIdentifier, using: nil) { task in
            self.handleAppRefresh(task: task as! BGAppRefreshTask)
        }
    }

    /// 排程下一次抓取
    func scheduleNextUpdate() {
        let request = BGAppRefreshTaskRequest(identifier: Self.taskIdentifier)
        request.earliestBeginDate = Date(timeIntervalSinceNow: 12*3600) // 12 小時後
        do {
            try BGTaskScheduler.shared.submit(request)
        } catch {
            // print("BG submit failed: \(error)")
        }
    }

    private func handleAppRefresh(task: BGAppRefreshTask) {
        scheduleNextUpdate() // 先安排下一次
        let op = BlockOperation {
            self.fetchAndStoreSummaries()
        }
        task.expirationHandler = {
            op.cancel()
        }
        op.completionBlock = {
            task.setTaskCompleted(success: !op.isCancelled)
        }
        OperationQueue().addOperation(op)
    }

    /// 讀取白名單 RSS（示意），產出摘要並存到本地知識庫
    func fetchAndStoreSummaries() {
        // 建議：把來源放在白名單，例如：arXiv (cs.LG / q-bio), PubMed RSS, medRxiv，並且做嚴格的來源標註
        // 這裡只做示意：將固定字串寫入 knowledge.json
        let item = KnowledgeItem(title: "示例：睡眠與心率變異研究 (placeholder)",
                                 url: "https://example.org/paper",
                                 summary: "低 HRV 可能與睡眠品質下降相關，但需個體化基線做對照。",
                                 date: Date())
        var db = loadKnowledge()
        db.append(item)
        saveKnowledge(db)
    }

    struct KnowledgeItem: Codable {
        let title: String
        let url: String
        let summary: String
        let date: Date
    }

    func loadKnowledge() -> [KnowledgeItem] {
        guard let data = try? Data(contentsOf: storeURL) else { return [] }
        return (try? JSONDecoder().decode([KnowledgeItem].self, from: data)) ?? []
    }

    func saveKnowledge(_ items: [KnowledgeItem]) {
        if let data = try? JSONEncoder().encode(items) {
            try? data.write(to: storeURL)
        }
    }
}


extension KnowledgeUpdater {
    func cancelAll() {
        BGTaskScheduler.shared.cancelAllTaskRequests()
    }
    
    /// 根據白名單來源抓取（示意：此處僅將來源列入摘要中）
    func fetchAndStoreSummaries() {
        let sources = WhitelistManager.shared.sources
        guard !sources.isEmpty else { return }
        var db = loadKnowledge()
        let now = Date()
        for s in sources.prefix(5) {
            let item = KnowledgeItem(title: "來源更新（示意）", url: s, summary: "已更新知識庫索引項。實作時應下載並解析內容。", date: now)
            db.append(item)
        }
        saveKnowledge(db)
    }
}
