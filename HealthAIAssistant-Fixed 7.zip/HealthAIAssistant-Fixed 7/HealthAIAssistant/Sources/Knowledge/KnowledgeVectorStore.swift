import Foundation
import CryptoKit

final class KnowledgeVectorStore {
    static let shared = KnowledgeVectorStore()
    let dim = 512

    func vectorize(_ text: String) -> [Double] {
        let tokens = tokenize(text.lowercased())
        var vec = [Double](repeating: 0, count: dim)
        for t in tokens {
            let h = Self.hash(t)
            vec[h % dim] += 1.0
        }
        let norm = sqrt(vec.reduce(0) { $0 + $1*$1 })
        if norm > 0 {
            for i in 0..<vec.count { vec[i] /= norm }
        }
        return vec
    }

    func cosine(_ a: [Double], _ b: [Double]) -> Double {
        var s = 0.0
        for i in 0..<min(a.count, b.count) { s += a[i]*b[i] }
        return s
    }

    func topK(for query: String, items: [KnowledgeUpdater.KnowledgeItem], k: Int = 3, sourceWeights: [String: Double] = [:]) -> [(KnowledgeUpdater.KnowledgeItem, Double)] {
        let q = vectorize(query)
        var scored: [(KnowledgeUpdater.KnowledgeItem, Double)] = []
        for it in items {
            let vec = vectorize(it.title + " " + it.summary)
            var score = cosine(q, vec)
            for (prefix, w) in sourceWeights {
                if it.url.hasPrefix(prefix) { score *= w }
            }
            let days = Date().timeIntervalSince(it.date) / 86400
            let recency = pow(0.5, days/30.0)
            score *= (0.5 + 0.5 * recency)
            scored.append((it, score))
        }
        return scored.sorted(by: { $0.1 > $1.1 }).prefix(k).map { $0 }
    }

    private func tokenize(_ s: String) -> [String] {
        return s.split { !$0.isLetter && !$0.isNumber }.map(String.init)
    }
    private static func hash(_ s: String) -> Int {
        let data = Data(s.utf8)
        let digest = Insecure.MD5.hash(data: data)
        return Int(digest.reduce(0) { ($0 << 4) ^ Int($1) } & 0x7fffffff)
    }
}
