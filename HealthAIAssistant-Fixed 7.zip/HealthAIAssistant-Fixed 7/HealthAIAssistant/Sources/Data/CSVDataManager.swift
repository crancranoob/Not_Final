import Foundation
import UniformTypeIdentifiers
import SwiftUI

struct DailyRecord: Codable, Identifiable {
    let id: String
    let date: Date
    var heartRate: Double
    var steps: Int
    var activeEnergy: Double
    var sleepHours: Double
    var oxygenSaturation: Double
    var bodyTemperature: Double
    var walkingStability: Double
    var hrvSDNN: Double?
    var respiratoryRate: Double?
    var userScore: Double?  // 1~5

    init(date: Date = Date(),
         heartRate: Double, steps: Int, activeEnergy: Double,
         sleepHours: Double, oxygenSaturation: Double, bodyTemperature: Double,
         walkingStability: Double, hrvSDNN: Double? = nil, respiratoryRate: Double? = nil, userScore: Double?) {
        self.id = ISO8601DateFormatter().string(from: date)
        self.date = date
        self.heartRate = heartRate
        self.steps = steps
        self.activeEnergy = activeEnergy
        self.sleepHours = sleepHours
        self.oxygenSaturation = oxygenSaturation
        self.bodyTemperature = bodyTemperature
        self.walkingStability = walkingStability
        self.hrvSDNN = hrvSDNN
        self.respiratoryRate = respiratoryRate
        self.userScore = userScore
    }
}

final class CSVDataManager: ObservableObject {
    static let shared = CSVDataManager()

    private let storeURL: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("records.json")
    }()

    @Published var records: [DailyRecord] = []

    init() {
        load()
    }

    func addToday(from data: HealthData, userScore: Double?) {
        let rec = DailyRecord(
            heartRate: data.heartRate,
            steps: data.steps,
            activeEnergy: data.activeEnergy,
            sleepHours: data.sleepHours,
            oxygenSaturation: data.oxygenSaturation,
            bodyTemperature: data.bodyTemperature,
            walkingStability: data.walkingStability,
            hrvSDNN: data.hrvSDNN,
            respiratoryRate: data.respiratoryRate,
            userScore: userScore
        )
        records.append(rec)
        save()
    }

    func load() {
        guard let data = try? Data(contentsOf: storeURL) else { return }
        if let items = try? JSONDecoder().decode([DailyRecord].self, from: data) {
            records = items
        }
    }
    func save() {
        if let data = try? JSONEncoder().encode(records) {
            try? data.write(to: storeURL)
        }
    }

    // MARK: CSV
    static let csvUTType = UTType.commaSeparatedText

    func exportCSV() -> Data {
        var rows: [String] = []
        rows.append("date,heartRate,steps,activeEnergy,sleepHours,oxygenSaturation,bodyTemperature,walkingStability,hrvSDNN,respiratoryRate,userScore")
        let df = ISO8601DateFormatter()
        for r in records {
            let line = [
                df.string(from: r.date),
                String(format: "%.3f", r.heartRate),
                String(r.steps),
                String(format: "%.3f", r.activeEnergy),
                String(format: "%.3f", r.sleepHours),
                String(format: "%.3f", r.oxygenSaturation),
                String(format: "%.3f", r.bodyTemperature),
                String(format: "%.3f", r.walkingStability),
                r.hrvSDNN != nil ? String(format: "%.3f", r.hrvSDNN!) : "",
                r.respiratoryRate != nil ? String(format: "%.3f", r.respiratoryRate!) : "",
                r.userScore != nil ? String(format: "%.3f", r.userScore!) : ""
            ].joined(separator: ",")
            rows.append(line)
        }
        return rows.joined(separator: "\n").data(using: .utf8) ?? Data()
    }

    func importCSV(_ data: Data) {
        guard let text = String(data: data, encoding: .utf8) else { return }
        let lines = text.split(separator: "\n")
        guard lines.count > 1 else { return }
        let df = ISO8601DateFormatter()
        var newRecs: [DailyRecord] = []
        for line in lines.drop(1) {
            let cols = line.split(separator: ",", omittingEmptySubsequences: false).map { String($0) }
            if cols.count >= 11 {
                let date = df.date(from: cols[0]) ?? Date()
                let hr = Double(cols[1]) ?? 0
                let steps = Int(cols[2]) ?? 0
                let ae = Double(cols[3]) ?? 0
                let sh = Double(cols[4]) ?? 0
                let spo2 = Double(cols[5]) ?? 0
                let temp = Double(cols[6]) ?? 0
                let ws = Double(cols[7]) ?? 0
                let hrv = Double(cols[8])
                let rr = Double(cols[9])
                let score = Double(cols[10])
                let rec = DailyRecord(date: date, heartRate: hr, steps: steps, activeEnergy: ae,
                                      sleepHours: sh, oxygenSaturation: spo2, bodyTemperature: temp,
                                      walkingStability: ws, hrvSDNN: hrv, respiratoryRate: rr, userScore: score)
                newRecs.append(rec)
            }
        }
        records.append(contentsOf: newRecs)
        save()
    }
        guard let text = String(data: data, encoding: .utf8) else { return }
    }
}
