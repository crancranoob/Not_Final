import Foundation

class DataValidator {
    private let scientificValidator = ScientificValidator()
    private let statisticalAnalyzer = StatisticalAnalyzer()
    
    func validate(_ data: RawMedicalData, source: DataSource, requirements: DataRequirements) async throws -> MedicalDataset {
        // 1. 驗證來源可信度
        guard await verifySourceCredibility(source) else {
            throw ValidationError.untrustedSource
        }
        
        // 2. 檢查數據完整性
        try validateDataIntegrity(data, requirements)
        
        // 3. 統計分析
        let statistics = try await statisticalAnalyzer.analyze(data)
        guard statistics.isStatisticallySignificant else {
            throw ValidationError.insufficientStatisticalSignificance
        }
        
        // 4. 科學驗證
        try await scientificValidator.validateMethodology(data.methodology)
        
        // 將 DataSource 轉換為 Dataset 以符合 MedicalDataset 的型別需求
        guard let sourceURL = URL(string: source.apiEndpoint) else {
            throw ValidationError.untrustedSource
        }
        let dataset = Dataset(name: source.name, url: sourceURL, type: .clinical)
        
        return MedicalDataset(
            source: dataset,
            data: data,
            validation: ValidationMetadata(
                timestamp: Date(),
                statisticalMetrics: statistics,
                validityPeriod: requirements.validityPeriod
            )
        )
    }
    
    func validate(_ data: RawMedicalData, source: Dataset) throws -> Bool {
        // 1. 檢查來源是否為公開合法
        guard source.url.host?.contains("physionet.org") == true || source.url.host?.contains("ncbi.nlm.nih.gov") == true else {
            throw ValidationError.untrustedSource
        }
        // 2. 檢查數據結構
        guard data.isValid else {
            throw ValidationError.invalidFormat
        }
        // 3. 檢查樣本量
        guard data.sampleCount > 100 else {
            throw ValidationError.insufficientSampleSize
        }
        return true
    }
    
    private func verifySourceCredibility(_ source: DataSource) async -> Bool {
        guard let url = URL(string: source.apiEndpoint), let host = url.host else {
            return false
        }
        // Whitelist well-known, trusted medical data hosts
        if host.contains("physionet.org") || host.contains("ncbi.nlm.nih.gov") {
            return true
        }
        return false
    }
    
    private func validateDataIntegrity(_ data: RawMedicalData, _ requirements: DataRequirements) throws {
        // 基本格式檢查
        guard data.isValid else {
            throw ValidationError.invalidFormat
        }
        // 基本樣本量檢查（與簡化版驗證一致）
        guard data.sampleCount > 100 else {
            throw ValidationError.insufficientSampleSize
        }
        // 如需依據 requirements 進一步檢查，可在此擴充
    }
}
