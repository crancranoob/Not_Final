import Foundation
import UniformTypeIdentifiers

struct ModelWeights: Codable {
    var regressor: OnlineRegressor
    var attentive: AttentiveAggregator
}

final class ModelWeightsManager {
    static let shared = ModelWeightsManager()
    private let url: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("model_weights.json")
    }()

    func save(reg: OnlineRegressor, attn: AttentiveAggregator) {
        let pkg = ModelWeights(regressor: reg, attentive: attn)
        if let data = try? JSONEncoder().encode(pkg) {
            try? data.write(to: url)
        }
    }
    func load() -> ModelWeights? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(ModelWeights.self, from: data)
    }

    // Export/Import via Files
    func exportData() -> Data { (try? Data(contentsOf: url)) ?? Data() }
    func importData(_ data: Data) {
        try? data.write(to: url)
    }
}

extension UTType {
    static var modelWeights: UTType { UTType(filenameExtension: "weightsjson") ?? .json }
}
