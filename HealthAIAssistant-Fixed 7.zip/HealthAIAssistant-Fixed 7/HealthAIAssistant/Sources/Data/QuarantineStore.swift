import Foundation


struct QuarantinedItem: Codable, Identifiable {
    let id: String   // DailyRecord.id
    let date: Date
    let reason: String
}

final class QuarantineStore: ObservableObject {
    static let shared = QuarantineStore()
    @Published private(set) var items: [QuarantinedItem] = []

    private let url: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("quarantined.json")
    }()

    private init() { load() }

    func load() {
        guard let data = try? Data(contentsOf: url) else { return }
        if let arr = try? JSONDecoder().decode([QuarantinedItem].self, from: data) {
            items = arr
        }
    }
    func save() {
        if let data = try? JSONEncoder().encode(items) {
            try? data.write(to: url)
        }
    }
    func add(id: String, date: Date, reason: String) {
        if !items.contains(where: { $0.id == id }) {
            items.append(QuarantinedItem(id: id, date: date, reason: reason))
            NotificationManager.shared.notify(title: "資料已隔離", body: "\(id)：\(reason)")
            save()
        }
    }
    func remove(id: String) {
        items.removeAll { $0.id == id }
        save()
    }
    func isQuarantined(_ id: String) -> Bool {
        return items.contains { $0.id == id }
    }
}
