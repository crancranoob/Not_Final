import Foundation

final class BackupManager {
    static let shared = BackupManager()
    private init() {}

    private var doc: URL { FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first! }

    func backupAll() {
        let stamp = ISO8601DateFormatter().string(from: Date())
        let dir = doc.appendingPathComponent("backup_\(stamp)")
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let candidates = [
            "records.json",
            "model_weights.json",
            "online_regressor.json",
            "attentive.json",
            "knowledge.json",
            "training_reports.json",
            "whitelist.json"
        ]
        for name in candidates {
            let src = doc.appendingPathComponent(name)
            if FileManager.default.fileExists(atPath: src.path) {
                let dst = dir.appendingPathComponent(name)
                try? FileManager.default.removeItem(at: dst)
                try? FileManager.default.copyItem(at: src, to: dst)
            }
        }
        trimBackups(keep: 10)
    }

    func listBackups() -> [URL] {
        let items = (try? FileManager.default.contentsOfDirectory(at: doc, includingPropertiesForKeys: nil)) ?? []
        return items.filter { $0.lastPathComponent.hasPrefix("backup_") }.sorted { $0.lastPathComponent < $1.lastPathComponent }
    }

    func restore(from url: URL) {
        let candidates = (try? FileManager.default.contentsOfDirectory(at: url, includingPropertiesForKeys: nil)) ?? []
        for file in candidates {
            let dst = doc.appendingPathComponent(file.lastPathComponent)
            try? FileManager.default.removeItem(at: dst)
            try? FileManager.default.copyItem(at: file, to: dst)
        }
    }

    private func trimBackups(keep: Int) {
        var backups = listBackups()
        while backups.count > keep {
            if let first = backups.first {
                try? FileManager.default.removeItem(at: first)
                backups.removeFirst()
            }
        }
    }
}


extension BackupManager {
    func checkBackupAge(maxDays: Int = 7) {
        let backs = listBackups()
        guard let last = backs.last else { return }
        let age = Date().timeIntervalSince(last.creationDate()) / 86400.0
        if age > Double(maxDays) {
            NotificationManager.shared.notify(title: "備份過期提醒", body: String(format: "最近備份已 %.0f 天前。請建立新備份。", age))
        }
    }
}
private extension URL {
    func creationDate() -> Date {
        (try? resourceValues(forKeys: [.creationDateKey]).creationDate) ?? Date.distantPast
    }
}
