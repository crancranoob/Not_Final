import Foundation

class MedicalDataFetcher {
    private let authenticator = APIAuthenticator()
    private let dataValidator = DataValidator()
    
    // 經過認證的數據源
    private let verifiedSources = [
        DataSource(
            id: "who",
            name: "World Health Organization",
            apiEndpoint: "https://api.who.int/data",
            authType: .oauth2,
            updateFrequency: .daily
        ),
        DataSource(
            id: "nih",
            name: "National Institutes of Health",
            apiEndpoint: "https://api.nih.gov/pubmed",
            authType: .apiKey,
            updateFrequency: .hourly
        ),
        DataSource(
            id: "nejm",
            name: "New England Journal of Medicine",
            apiEndpoint: "https://api.nejm.org/data",
            authType: .oauth2,
            updateFrequency: .daily
        )
    ]
    
    func fetchVerifiedData() async throws -> [MedicalDataset] {
        var datasets: [MedicalDataset] = []
        
        for source in verifiedSources {
            // 驗證數據源
            guard await authenticator.validateSource(source) else {
                throw DataError.invalidSource(source.id)
            }
            
            // 獲取數據
            let rawData = try await fetchData(from: source)
            
            // 驗證數據
            let validatedData = try await dataValidator.validate(
                rawData,
                source: source,
                requirements: DataRequirements(
                    minimumSampleSize: 1000,
                    requiredFields: ["methodology", "peerReview", "publishDate"],
                    validityPeriod: .oneYear
                )
            )
            
            datasets.append(validatedData)
        }
        
        return datasets
    }
    
    private func fetchData(from source: DataSource) async throws -> RawMedicalData {
        let client = APIClient(source: source)
        
        // 建立安全連接
        try await client.establishSecureConnection()
        
        // 獲取認證的數據
        let response = try await client.fetchData(
            withHeaders: [
                "Authorization": await authenticator.getToken(for: source),
                "Data-Version": "latest",
                "Verification-Required": "true"
            ]
        )
        
        return response.data
    }
    
    // 此檔案已包含 fetchOpenDataset 及 parseRawData，允許下載公開資料（PhysioNet/NCBI）以供研究使用。
    func fetchOpenDataset(_ dataset: Dataset) async throws -> RawMedicalData {
        // 僅允許下載公開數據集
        let (data, response) = try await URLSession.shared.data(from: dataset.url)
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw DataError.invalidSource(dataset.name)
        }
        // 假設數據為CSV或JSON，根據實際情況解析
        return try parseRawData(data, for: dataset)
    }
    
    private func parseRawData(_ data: Data, for dataset: Dataset) throws -> RawMedicalData {
        // 根據 dataset.type 決定解析方式
        // 這裡僅做簡單範例
        if dataset.type == .wearable {
            // 解析CSV
            return try RawMedicalData(csvData: data)
        } else {
            // 解析JSON
            return try RawMedicalData(jsonData: data)
        }
    }
}

struct DataRequirements {
    let minimumSampleSize: Int
    let requiredFields: [String]
    let validityPeriod: ValidityPeriod
    
    enum ValidityPeriod {
        case oneMonth
        case threeMonths
        case sixMonths
        case oneYear
    }
}
