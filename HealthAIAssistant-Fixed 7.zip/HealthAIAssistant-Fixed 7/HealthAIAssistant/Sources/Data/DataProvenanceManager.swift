import Foundation

/// 管理數據來源、權限和處理歷史，確保數據的可追溯性和合規性。
final class DataProvenanceManager {
    private var provenanceRecords: [String: ProvenanceRecord] = [:]
    private let privacyManager = PrivacyManager()

    /// 記錄一個新的數據集來源
    func recordDataSource(name: String, sourceURL: URL, accessDate: Date, consent: DataConsent) {
        let record = ProvenanceRecord(
            sourceName: name,
            sourceURL: sourceURL,
            accessDate: accessDate,
            consent: consent,
            processingHistory: []
        )
        provenanceRecords[name] = record
    }

    /// 驗證數據使用是否符合規定
    func validateDataUsage(for datasetName: String, usage: DataUsage) async -> Bool {
        guard let record = provenanceRecords[datasetName] else { return false }
        return await privacyManager.canUseData(record: record, for: usage)
    }
    
    func requireUserConsent(for dataset: Dataset) -> Bool {
        // 彈出用戶授權視窗（僅範例，實際需用 UI 實現）
        print("請確認您同意使用 \(dataset.name) 數據於學術研究分析。")
        // 假設用戶同意
        return true
    }
}

struct ProvenanceRecord {
    let sourceName: String
    let sourceURL: URL
    let accessDate: Date
    let consent: DataConsent
    var processingHistory: [String]
}

struct DataConsent {
    let canUseForTraining: Bool
    let canUseForAnalysis: Bool
    let dataRetentionPeriod: TimeInterval
}

enum DataUsage {
    case modelTraining
    case prediction
    case research
}
