import Foundation

final class SettingsStore: ObservableObject, Codable {
    static let shared = SettingsStore.load()

    // Safety/validation
    @Published var zThreshold: Double = 3.0
    @Published var deltaMAE: Double = 0.05
    @Published var discrepancyThreshold: Double = 1.5
    @Published var backupMaxDays: Int = 7
    @Published var ewmaAlpha: Double = 0.2
    @Published var hrHighZ: Double = 2.0
    @Published var hrvLowZ: Double = -2.0
    @Published var tempHighZ: Double = 2.0
    @Published var spo2Low: Double = 0.92
    @Published var respHighZ: Double = 2.0

    // Goals
    @Published var goalSleepHours: Double = 7.5
    @Published var goalSteps: Int = 8000
    @Published var goalActiveEnergy: Double = 500
    @Published var goalBedtimeHour: Int = 23

    enum CodingKeys: String, CodingKey {
        case zThreshold, deltaMAE, discrepancyThreshold, backupMaxDays, ewmaAlpha, hrHighZ, hrvLowZ, tempHighZ, spo2Low, respHighZ, goalSleepHours, goalSteps, goalActiveEnergy, goalBedtimeHour
    }
    required init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        zThreshold = try c.decode(Double.self, forKey: .zThreshold)
        deltaMAE = try c.decode(Double.self, forKey: .deltaMAE)
        discrepancyThreshold = try c.decode(Double.self, forKey: .discrepancyThreshold)
        backupMaxDays = try c.decode(Int.self, forKey: .backupMaxDays)
        ewmaAlpha = try c.decode(Double.self, forKey: .ewmaAlpha)
        hrHighZ = try c.decode(Double.self, forKey: .hrHighZ)
        hrvLowZ = try c.decode(Double.self, forKey: .hrvLowZ)
        tempHighZ = try c.decode(Double.self, forKey: .tempHighZ)
        spo2Low = try c.decode(Double.self, forKey: .spo2Low)
        respHighZ = try c.decode(Double.self, forKey: .respHighZ)
        goalSleepHours = try c.decode(Double.self, forKey: .goalSleepHours)
        goalSteps = try c.decode(Int.self, forKey: .goalSteps)
        goalActiveEnergy = try c.decode(Double.self, forKey: .goalActiveEnergy)
        goalBedtimeHour = try c.decode(Int.self, forKey: .goalBedtimeHour)
    }
    init() {}
    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(zThreshold, forKey: .zThreshold)
        try c.encode(deltaMAE, forKey: .deltaMAE)
        try c.encode(discrepancyThreshold, forKey: .discrepancyThreshold)
        try c.encode(backupMaxDays, forKey: .backupMaxDays)
        try c.encode(ewmaAlpha, forKey: .ewmaAlpha)
        try c.encode(hrHighZ, forKey: .hrHighZ)
        try c.encode(hrvLowZ, forKey: .hrvLowZ)
        try c.encode(tempHighZ, forKey: .tempHighZ)
        try c.encode(spo2Low, forKey: .spo2Low)
        try c.encode(respHighZ, forKey: .respHighZ)
        try c.encode(goalSleepHours, forKey: .goalSleepHours)
        try c.encode(goalSteps, forKey: .goalSteps)
        try c.encode(goalActiveEnergy, forKey: .goalActiveEnergy)
        try c.encode(goalBedtimeHour, forKey: .goalBedtimeHour)
    }

    private static let url: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("settings.json")
    }()
    static func load() -> SettingsStore {
        if let data = try? Data(contentsOf: url), let s = try? JSONDecoder().decode(SettingsStore.self, from: data) {
            return s
        }
        return SettingsStore()
    }
    func save() {
        if let data = try? JSONEncoder().encode(self) {
            try? data.write(to: SettingsStore.url)
        }
    }
}
