import Foundation

struct JournalEntry: Codable, Identifiable {
    let id: String
    let date: Date
    var symptoms: [String]
    var medications: [String]
    var notes: String

    init(date: Date = Date(), symptoms: [String] = [], medications: [String] = [], notes: String = "") {
        self.id = ISO8601DateFormatter().string(from: date)
        self.date = date
        self.symptoms = symptoms
        self.medications = medications
        self.notes = notes
    }
}

final class JournalStore: ObservableObject {
    static let shared = JournalStore()
    @Published var items: [JournalEntry] = []

    private let url: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("journal.json")
    }()
    private init() { load() }
    func load() {
        if let data = try? Data(contentsOf: url), let arr = try? JSONDecoder().decode([JournalEntry].self, from: data) {
            items = arr
        }
    }
    func save() {
        if let data = try? JSONEncoder().encode(items) { try? data.write(to: url) }
    }
    func add(_ e: JournalEntry) { items.append(e); save() }
}
