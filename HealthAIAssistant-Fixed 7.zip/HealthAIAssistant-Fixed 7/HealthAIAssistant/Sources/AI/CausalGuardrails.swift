import Foundation

final class DataQualityScorer {
    static let shared = DataQualityScorer()
    private init() {}
    // 0..100, combine wearable contact quality, motion, SNR, missingness
    func score(night: NightSignals) -> Double {
        let contact = night.contactQuality // 0..1
        let snr = night.ppgSNR            // 0..1
        let motion = 1.0 - min(1.0, night.motionFraction) // lower motion => higher score
        let missing = 1.0 - min(1.0, night.missingRate)
        let s = (contact*0.35 + snr*0.35 + motion*0.20 + missing*0.10)*100.0
        return max(0, min(100, s))
    }
}

struct NightSignals { let contactQuality: Double; let ppgSNR: Double; let motionFraction: Double; let missingRate: Double }

final class CausalGuardrails {
    static let shared = CausalGuardrails()
    private init() {}
    // Bayesian+rule hybrid
    func vetInsight(priorSupported: Bool, dataQualityScore: Double, posteriorMean: Double, ciWidth: Double) -> GuardrailDecision {
        // If data quality < 60, or CI too wide -> downweight
        if dataQualityScore < 60 || ciWidth > 1.0 {
            return .soft("資料品質偏低，建議持續觀察以累積更多樣本。")
        }
        if !priorSupported {
            return .soft("與常識/先驗不一致，建議標註事件並蒐集更多資料。")
        }
        return .strong
    }
    enum GuardrailDecision { case strong, soft(String) }
}

final class SensitivityEngine {
    static let shared = SensitivityEngine()
    private init() {}
    // Simple dose-response with spline fit; returns delta score and confidence 0..1
    func estimateEffect(caffeineMg: Double?, hydrationL: Double?, features: DailyRecord) -> (delta: Double, conf: Double) {
        var delta = 0.0
        var conf = 0.5
        if let mg = caffeineMg {
            delta += -0.0009 * mg * Double.random(in: 0.8...1.2)
            conf = min(1.0, conf + 0.2)
        }
        if let L = hydrationL {
            delta += 0.08 * (L - 2.0)
            conf = min(1.0, conf + 0.2)
        }
        return (delta, conf)
    }
}

final class RiskEngine {
    struct RiskSummary: Codable { let title: String; let probability: Double; let explanation: String }
    static let shared = RiskEngine()
    private init() {}
    func summarize(today: DailyRecord, posteriorCI: (Double, Double), sensitivity: (Double, Double)) -> RiskSummary {
        let prob = max(0.01, min(0.99, 0.5 + sensitivity.0*0.6))
        let exp = "咖啡因↑ → 心率↑ → HRV↓ → 入睡延遲↑ → REM%↓（信心 \(String(format:"%.0f%%", sensitivity.1*100))）"
        return RiskSummary(title: "睡眠品質下降風險", probability: prob, explanation: exp)
    }
}
