import Foundation
import CoreML

final class DatasetManager {
    // 僅允許合法公開數據集
    private let openDatasets = [
        Dataset(name: "PhysioNet", url: URL(string: "https://physionet.org/physiobank/database/")!, type: .wearable),
        Dataset(name: "Sample PubMed", url: URL(string: "https://ftp.ncbi.nlm.nih.gov/pubmed/")!, type: .literature)
    ]
    
    private let dataFetcher = MedicalDataFetcher()
    private let preprocessor = DataPreprocessor()
    private let provenanceManager = DataProvenanceManager()
    
    func prepareTrainingData() async throws -> TrainingSet {
        var combinedData = CombinedDataset()
        
        // 1. 下載並驗證公開數據
        for dataset in openDatasets {
            let rawData = try await dataFetcher.fetchOpenDataset(dataset)
            let validated = try await preprocessor.processAndValidate(rawData, dataset: dataset)
            provenanceManager.recordDataSource(
                name: dataset.name,
                sourceURL: dataset.url,
                accessDate: Date(),
                consent: DataConsent(canUseForTraining: true, canUseForAnalysis: true, dataRetentionPeriod: 365*24*3600)
            )
            combinedData.integrate(validated, weight: 1.0)
        }
        
        // 2. 可選：生成模擬數據（僅供測試/開發）
        #if DEBUG
        let simulatedData = generateSimulatedData()
        let processedSimulated = await preprocessor.process(simulatedData)
        combinedData.integrate(processedSimulated, weight: 0.2)
        #endif
        
        return try await createTrainingSet(from: combinedData)
    }
    
    private func generateSimulatedData() -> MedicalDataset {
        // 僅供開發測試，嚴禁用於發表或臨床
        return MedicalDataset.simulate()
    }
    
    private func createTrainingSet(from data: CombinedDataset) async throws -> TrainingSet {
        // 數據集分割
        let (training, validation, testing) = data.split(ratio: (0.7, 0.15, 0.15))
        
        // 進行數據增強
        let augmented = await augmentData(training)
        
        return TrainingSet(
            training: augmented,
            validation: validation,
            testing: testing,
            metadata: generateMetadata(data)
        )
    }
}
