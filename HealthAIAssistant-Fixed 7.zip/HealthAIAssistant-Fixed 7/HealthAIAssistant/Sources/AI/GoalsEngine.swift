import Foundation

struct GoalStatus {
    let metSleep: Bool
    let metSteps: Bool
    let metEnergy: Bool
}

final class GoalsEngine {
    static let shared = GoalsEngine()

    func status(for d: HealthData) -> GoalStatus {
        let s = SettingsStore.shared
        return GoalStatus(
            metSleep: d.sleepHours >= s.goalSleepHours,
            metSteps: d.steps >= s.goalSteps,
            metEnergy: d.activeEnergy >= s.goalActiveEnergy
        )
    }

    func sleepDebt(last7: [DailyRecord]) -> Double {
        let s = SettingsStore.shared.goalSleepHours
        guard !last7.isEmpty else { return 0 }
        let total = last7.map { $0.sleepHours }.reduce(0,+)
        return (s*Double(last7.count)) - total
    }

    func suggestedBedtime(today: Date, debt: Double) -> DateComponents {
        // Simple rule: if debt>=1.0h, suggest bedtime earlier by min(90min, debt*60)
        let minutes = Int(min(90, max(0, debt*60)))
        var comps = Calendar.current.dateComponents([.year,.month,.day,.hour,.minute], from: today)
        let targetHour = SettingsStore.shared.goalBedtimeHour
        comps.hour = targetHour
        comps.minute = 0
        let base = Calendar.current.date(from: comps) ?? today
        let earlier = Calendar.current.date(byAdding: .minute, value: -minutes, to: base) ?? base
        return Calendar.current.dateComponents([.hour, .minute], from: earlier)
    }

    func nonWearDetected(hrSeries: [Double], step: Int) -> Bool {
        // very low variance HR + zero steps suggests non-wear
        guard !hrSeries.isEmpty else { return false }
        let mean = hrSeries.reduce(0,+)/Double(hrSeries.count)
        let var_ = hrSeries.reduce(0) { $0 + ($1-mean)*($1-mean) } / Double(hrSeries.count)
        return var_ < 4.0 && step == 0  // sd < 2 bpm and zero steps
    }
}
