import Foundation

final class StatsEngine {
    static let shared = StatsEngine()

    func percentile(_ x: [Double], p: Double) -> Double {
        guard !x.isEmpty else { return 0 }
        let sorted = x.sorted()
        let i = max(0, min(sorted.count-1, Int(round(p * Double(sorted.count-1)))))
        return sorted[i]
    }

    func slope(_ pairs: [(Double, Double)]) -> Double {
        // simple OLS slope
        guard pairs.count >= 2 else { return 0 }
        let n = Double(pairs.count)
        let sx = pairs.reduce(0) { $0 + $1.0 }
        let sy = pairs.reduce(0) { $0 + $1.1 }
        let sxx = pairs.reduce(0) { $0 + $1.0*$1.0 }
        let sxy = pairs.reduce(0) { $0 + $1.0*$1.1 }
        let denom = (n*sxx - sx*sx)
        if abs(denom) < 1e-8 { return 0 }
        return (n*sxy - sx*sy) / denom
    }

    func withinPersonPercentile(values: [Double], current: Double) -> Double {
        guard values.count >= 5 else { return 0.5 }
        let sorted = values.sorted()
        let rank = Double(sorted.firstIndex(where: { $0 >= current }) ?? sorted.count-1) / Double(sorted.count-1)
        return rank
    }
}
