import Foundation

public struct SignalUtils {
    // Simple moving median (odd window)
    public static func median(_ x: [Double], window: Int) -> [Double] {
        guard window > 1, window % 2 == 1, x.count >= window else { return x }
        let k = window // no division for median
        var out = x
        for i in 0..<x.count {
            let a = max(0, i - k/2), b = min(x.count-1, i + k/2)
            let slice = Array(x[a...b]).sorted()
            out[i] = slice[slice.count/2]
        }
        return out
    }
}

public final class AdaptiveKalman1D {
    // Classic 1D KF with adaptive measurement noise based on local variance
    private var x: Double = 0          // state
    private var p: Double = 1          // covariance
    private var q: Double              // process noise
    private var rBase: Double          // base measurement noise
    public init(q: Double = 0.01, r: Double = 1.0) {
        self.q = q; self.rBase = r
    }
    public func reset(to val: Double) { x = val; p = 1 }
    public func filter(_ values: [Double]) -> [Double] {
        guard !values.isEmpty else { return values }
        var out = [Double]()
        x = values[0]; p = 1
        let n = values.count
        for i in 0..<n {
            // Predict
            p += q
            // Adaptive R from local variance in a small window
            let a = max(0, i-3), b = min(n-1, i+3)
            let s = values[a...b]; let mean = s.reduce(0,+)/Double(s.count)
            let varLoc = max(1e-6, s.map{($0-mean)*($0-mean)}.reduce(0,+)/Double(s.count))
            let r = rBase + 0.5 * varLoc
            // Update
            let k = p / (p + r)
            x = x + k * (values[i] - x)
            p = (1 - k) * p
            out.append(x)
        }
        return out
    }
}

// Minimal Haar wavelet denoising (1-level soft-threshold)
public final class HaarWaveletDenoiser {
    public static func denoise(_ x: [Double], threshold: Double) -> [Double] {
        guard x.count >= 4 else { return x }
        var approx: [Double] = []
        var detail: [Double] = []
        for i in stride(from: 0, to: x.count-1, by: 2) {
            let a = (x[i] + x[i+1]) / 2.0
            let d = (x[i] - x[i+1]) / 2.0
            approx.append(a)
            // soft threshold
            let sign = d >= 0 ? 1.0 : -1.0
            let val = max(0.0, abs(d) - threshold) * sign
            detail.append(val)
        }
        // Reconstruct
        var out: [Double] = []
        for i in 0..<approx.count {
            let a = approx[i], d = detail[i]
            out.append(a + d)
            out.append(a - d)
        }
        if out.count > x.count { out.removeLast(out.count - x.count) }
        return out
    }
}

public enum HRV {
    // RMSSD (ms) from RR intervals (s)
    public static func rmssd(rrSeconds: [Double]) -> Double {
        guard rrSeconds.count >= 2 else { return 0 }
        var diffs: [Double] = []
        for i in 1..<rrSeconds.count { let d = rrSeconds[i] - rrSeconds[i-1]; diffs.append(d*d) }
        let meanSq = diffs.reduce(0,+)/Double(diffs.count)
        return sqrt(meanSq) * 1000.0
    }
}
