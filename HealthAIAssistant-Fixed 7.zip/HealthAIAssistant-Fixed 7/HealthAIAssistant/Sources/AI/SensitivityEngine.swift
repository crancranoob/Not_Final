import Foundation

public struct SensitivityPoint: Codable, Identifiable {
    public let id = UUID().uuidString
    public let factor: String            // e.g., "caffeine", "hydration"
    public let bucket: String            // e.g., "100-200 mg", "late"
    public let effect: Double            // predicted delta on score or physiologic metric
    public let lcl: Double               // lower 95% CI
    public let ucl: Double               // upper 95% CI
    public let n: Int                    // sample count
}

public struct SensitivitySummary: Codable {
    public let date: Date
    public let points: [SensitivityPoint]
    public let grades: [String:String]   // factor -> A/B/C
}

/// n-of-1 causal-leaning engine: case-crossover + dose/time bins + bootstrap CI + grades
final class SensitivityEngine {
    static let shared = SensitivityEngine()
    private init() {}

    private func bootstrapCI(samples: [Double], reps: Int = 500) -> (Double, Double, Double) {
        guard !samples.isEmpty else { return (0,0,0) }
        let mean = samples.reduce(0,+)/Double(samples.count)
        var boots: [Double] = []
        for _ in 0..<reps {
            var s = 0.0
            for _ in 0..<samples.count {
                s += samples[Int.random(in: 0..<samples.count)]
            }
            boots.append(s/Double(samples.count))
        }
        boots.sort()
        let l = boots[Int(0.025 * Double(boots.count))]
        let u = boots[Int(0.975 * Double(boots.count))]
        return (mean, l, u)
    }

    private func grade(effect: Double, lcl: Double, ucl: Double, n: Int) -> String {
        if n >= 20 && lcl * ucl > 0 && abs(effect) >= 0.5 { return "A" } // strong, consistent
        if n >= 10 && (abs(effect) >= 0.3 || lcl * ucl > 0) { return "B" }
        return "C"
    }

    /// Analyze caffeine & hydration; extendable to more factors.
    func analyze(records: [DailyRecord]) -> SensitivitySummary {
        var points: [SensitivityPoint] = []
        // We need context (hydration/caffeine)
        let ctxMap = Dictionary(uniqueKeysWithValues: ContextStore.shared.all().map { ($0.date, $0) })

        // Build matched samples (simple case-crossover using similar steps/energy & weekday matching)
        func similarDays(to r: DailyRecord, in pool: [DailyRecord]) -> [DailyRecord] {
            let wd = Calendar.current.component(.weekday, from: r.date)
            return pool.filter {
                let wd2 = Calendar.current.component(.weekday, from: $0.date)
                let stepsClose = abs(Double($0.steps) - Double(r.steps)) < 2000
                let energyClose = abs($0.activeEnergy - r.activeEnergy) < 250
                return wd == wd2 && stepsClose && energyClose && $0.date != r.date
            }
        }

        // Caffeine bins (mg) total and late
        let recs = records.sorted { $0.date < $1.date }
        var caf_bins: [(name:String, pred:(DayContext)->Bool)] = [
            ("0 mg", { $0.caffeineMgTotal <= 1 }),
            ("1-100 mg", { $0.caffeineMgTotal > 1 && $0.caffeineMgTotal <= 100 }),
            ("100-200 mg", { $0.caffeineMgTotal > 100 && $0.caffeineMgTotal <= 200 }),
            ("200-300 mg", { $0.caffeineMgTotal > 200 && $0.caffeineMgTotal <= 300 }),
            (">300 mg", { $0.caffeineMgTotal > 300 })
        ]
        var late_bins: [(name:String, pred:(DayContext)->Bool)] = [
            ("0 mg after 14:00", { $0.caffeineMgLate <= 1 }),
            ("1-100 mg after 14:00", { $0.caffeineMgLate > 1 && $0.caffeineMgLate <= 100 }),
            ("100-200 mg after 14:00", { $0.caffeineMgLate > 100 && $0.caffeineMgLate <= 200 }),
            (">200 mg after 14:00", { $0.caffeineMgLate > 200 })
        ]

        // For each bin, compute ΔHR (as example physiologic target) and ΔScore (meta score) vs matched controls
        func deltas(for pred: (DayContext)->Bool, label: String) -> (dHR:[Double], dScore:[Double]) {
            var dHR: [Double] = []
            var dScore: [Double] = []
            for r in recs {
                guard let c = ctxMap[r.date], pred(c) else { continue }
                let pool = similarDays(to: r, in: recs)
                guard !pool.isEmpty else { continue }
                let ctrl = pool.randomElement()!
                // Targets
                let hrDelta = (r.heartRate) - (ctrl.heartRate)
                let scoreDelta = MetaCombinerCoordinator.shared.predict(data:
                                    AIModelCoordinator.shared.healthDataFromDaily(r))
                                 - MetaCombinerCoordinator.shared.predict(data:
                                    AIModelCoordinator.shared.healthDataFromDaily(ctrl))
                dHR.append(hrDelta); dScore.append(scoreDelta)
            }
            return (dHR, dScore)
        }

        // Build points for caffeine
        for b in caf_bins {
            let (dhr, dsc) = deltas(for: b.pred, label: b.name)
            if !dsc.isEmpty {
                let (m,l,u) = bootstrapCI(samples: dsc)
                points.append(SensitivityPoint(factor: "caffeine", bucket: b.name, effect: m, lcl: l, ucl: u, n: dsc.count))
            }
        }
        for b in late_bins {
            let (dhr, dsc) = deltas(for: b.pred, label: b.name)
            if !dsc.isEmpty {
                let (m,l,u) = bootstrapCI(samples: dsc)
                points.append(SensitivityPoint(factor: "late_caffeine", bucket: b.name, effect: m, lcl: l, ucl: u, n: dsc.count))
            }
        }
        // Hydration bins (liters)
        let hyd_bins: [(String,(DayContext)->Bool)] = [
            ("<1.0 L", { $0.hydrationLiters < 1.0 }),
            ("1.0–2.0 L", { $0.hydrationLiters >= 1.0 && $0.hydrationLiters < 2.0 }),
            (">=2.0 L", { $0.hydrationLiters >= 2.0 })
        ]
        for (name, pred) in hyd_bins {
            let (dhr, dsc) = deltas(for: pred, label: name)
            if !dsc.isEmpty {
                let (m,l,u) = bootstrapCI(samples: dsc)
                points.append(SensitivityPoint(factor: "hydration", bucket: name, effect: m, lcl: l, ucl: u, n: dsc.count))
            }
        }

        // Grades per factor (based on strongest bucket)
        var grades: [String:String] = [:]
        for f in ["caffeine","late_caffeine","hydration"] {
            let pf = points.filter { $0.factor == f }
            if let best = pf.max(by: { abs($0.effect) < abs($1.effect) }) {
                grades[f] = grade(effect: best.effect, lcl: best.lcl, ucl: best.ucl, n: best.n)
            }
        }
        let summary = SensitivitySummary(date: Date(), points: points, grades: grades)
        // Persist summary
        if let data = try? JSONEncoder().encode(summary) {
            let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            let url = doc.appendingPathComponent("sensitivity_summary.json")
            try? data.write(to: url)
        }
        return summary
    }
}
