import Foundation

final class ModelBootstrap {
    static let shared = ModelBootstrap()
    private init() { }
    private var done = false

    func ensureRegistered() {
        guard !done else { return }
        done = true
        // Sleep staging registration happens in SleepStageNetCoordinator.load()
        // Register other submodels (placeholders) so ValidationEngine has a summary string:
        let hrvSig = ModelSignature(name: "HRVDenoiserKalmanWavelet", version: "0.2.0", task: "hrv_denoise",
                                    input: "RR intervals / HR series", output: "cleaned HR/HRV")
        ModelRegistry.shared.register(model: "hrv_denoise", version: hrvSig.version, signature: hrvSig)

        let spo2Sig = ModelSignature(name: "SpO2Calibrator", version: "0.1.0", task: "spo2_correction",
                                     input: "ppg spo2 + context", output: "calibrated spo2")
        ModelRegistry.shared.register(model: "spo2_correction", version: spo2Sig.version, signature: spo2Sig)

        let metaSig = ModelSignature(name: "MetaCombiner", version: "1.7.0", task: "personal_score",
                                     input: "daily features", output: "score 1..5 (+CI)")
        ModelRegistry.shared.register(model: "meta_score", version: metaSig.version, signature: metaSig)
    }
}
