import Foundation
import UIKit

final class BootstrapTrainer {
    static let shared = BootstrapTrainer()
    private init() {}

    private func isCharging() -> Bool {
        UIDevice.current.isBatteryMonitoringEnabled = true
        return UIDevice.current.batteryState == .charging || UIDevice.current.batteryState == .full
    }
    private func withinNightWindow(_ d: Date = Date()) -> Bool {
        let h = Calendar.current.component(.hour, from: d)
        return (0 <= h && h < 7)
    }

    func startBootstrap(lookbackDays: Int = 180) {
        // 1) Import history
        HealthKitHistoryImporter.shared.importDays(lookbackDays: lookbackDays) { result in
            switch result {
            case .failure(let e):
                NotificationManager.shared.notify(title: "歷史匯入失敗", body: "\(e.localizedDescription)")
            case .success(let recs):
                NotificationManager.shared.notify(title: "歷史資料已匯入", body: "共 \(recs.count) 天，準備個人化訓練。")
                self.runTrainingNowIfAllowed(orSchedule: true)
            }
        }
    }

    func runTrainingNowIfAllowed(orSchedule: Bool) {
        if isCharging() && withinNightWindow() {
            DispatchQueue.global(qos: .utility).async {
                let recs = CSVDataManager.shared.records
                let coord = AIModelCoordinator.shared
                // Teacher heavy training (resumable)
                Trainer.shared.trainHeavyNight(records: recs, coordinator: coord)
                // Orchestrate experts/meta/calibration
                NightOrchestrator.shared.runAll(records: recs, coordinator: coord)
                NotificationManager.shared.notify(title: "個人化訓練完成", body: "老師/學生/專家/組合器已更新")
            }
        } else if orSchedule {
            // Schedule using NightTrainingScheduler (it will run at next charge + window)
            NightTrainingScheduler.shared.schedule()
            NotificationManager.shared.notify(title: "已排程夜間個人化訓練", body: "將在充電且 00:00–07:00 執行。")
        }
    }
}
