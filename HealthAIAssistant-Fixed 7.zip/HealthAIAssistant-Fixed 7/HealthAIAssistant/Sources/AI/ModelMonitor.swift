import Foundation

struct TrainingReport: Codable {
    let date: Date
    let epochs: Int
    let batchSize: Int
    let windowSize: Int
    let trainMAE: Double
    let holdoutMAE: Double
    let accepted: Bool
}

final class ModelMonitor {
    static let shared = ModelMonitor()
    private init() {}

    private var logURL: URL {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("training_reports.json")
    }

    func append(_ r: TrainingReport) {
        var arr = (try? JSONDecoder().decode([TrainingReport].self, from: Data(contentsOf: logURL))) ?? []
        arr.append(r)
        if let data = try? JSONEncoder().encode(arr) {
            try? data.write(to: logURL)
        }
    }

    /// Compute MAE on provided dataset with current coordinator models
    func mae(on dataset: [([[Double]], Double)], coordinator: AIModelCoordinator) -> Double {
        guard !dataset.isEmpty else { return 0 }
        var sum = 0.0
        for (seq, y) in dataset {
            let last = seq.last ?? []
            let attn = coordinator.loadAttentive(dIn: last.count)
            let reg = coordinator.loadOnlineModel(featureCount: last.count + attn.dModel)
            let embed = attn.forward(seq)
            let pred = reg.predict(last + embed)
            sum += abs(pred - y)
        }
        return sum / Double(dataset.count)
    }
}
