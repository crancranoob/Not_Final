import CoreML
import Foundation

// Minimal stubs to satisfy dependencies
enum AIError: Error {
    case invalidOutput
}

struct HealthContext {
    // Add fields as needed; this is a minimal placeholder
    func vectorize() -> [Double] { return [] }
}

final class HealthTokenizer {
    // Minimal tokenizer that returns token IDs; replace with real implementation
    func encode(_ text: String) -> [Int] {
        // Very naive tokenization by Unicode scalars
        return text.unicodeScalars.map { Int($0.value % 1024) }
    }
}

final class HealthResponseGenerator {
    private let model: MLModel
    private let tokenizer: HealthTokenizer

    init(model: MLModel) {
        self.model = model
        self.tokenizer = HealthTokenizer()
    }

    // 同步版本：在主推論流程中更穩定
    func generateResponseSync(for query: String, context: HealthContext) throws -> String {
        let inputFeatures = try createInputFeatures(query: query, context: context)
        let output = try model.prediction(from: inputFeatures)
        guard let response = output.featureValue(for: "response")?.stringValue else {
            throw AIError.invalidOutput
        }
        return response
    }

    // async wrapper
    func generateResponse(for query: String, context: HealthContext) async throws -> String {
        return try generateResponseSync(for: query, context: context)
    }

    private func createInputFeatures(query: String, context: HealthContext) throws -> MLFeatureProvider {
        let tokenizedQuery = tokenizer.encode(query)
        let contextVector = context.vectorize()

        let dictionary: [String: Any] = [
            "input_query": tokenizedQuery,
            "health_context": contextVector
        ]
        return try MLDictionaryFeatureProvider(dictionary: dictionary)
    }
}
