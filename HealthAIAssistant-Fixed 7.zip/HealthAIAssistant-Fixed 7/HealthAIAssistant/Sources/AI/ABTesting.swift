import Foundation

struct ABDecisionLog: Codable {
    let timestamp: Date
    let oldVariant: String
    let newVariant: String
    let decision: String
    let oldReport: EvalReport?
    let newReport: EvalReport?
}

final class ModelVersionStore {
    static let shared = ModelVersionStore()
    private init() {}
    private let key = "sleep_active_variant"
    func activeVariant() -> SleepModelVariant {
        let s = UserDefaults.standard.string(forKey: key) ?? "swift"
        return SleepModelVariant(rawValue: s) ?? .swift
    }
    func setActive(_ v: SleepModelVariant) {
        UserDefaults.standard.set(v.rawValue, forKey: key)
        SleepStageNetCoordinator.shared.setActiveVariant(v)
    }
}

final class ABTester {
    static let shared = ABTester()
    private init() {}

    // Try to run a labeled benchmark if available; else skip.
    func runSleepStagingAB(gates: DynamicModelManager.Gates = .init()) -> ABDecisionLog {
        let available = SleepStageNetCoordinator.shared.variantsAvailable()
        guard available.contains(.swift) else {
            return ABDecisionLog(timestamp: Date(), oldVariant: "n/a", newVariant: "n/a", decision: "no_variants", oldReport: nil, newReport: nil)
        }
        let active = ModelVersionStore.shared.activeVariant()
        let candidate: SleepModelVariant = (active == .swift && available.contains(.coreml)) ? .coreml : .swift

        // Build dataset (best-effort): prefer real labeled dataset, else synthetic placeholder
        let dataset = buildSleepBenchmark()

        // Old report
        let oldPairs = pairsForVariant(variant: active, dataset: dataset)
        let oldReport = ValidationEngine.shared.runBenchmark(dataset: BenchmarkDataset(name: "sleep_ab_\(active)", count: oldPairs.count, hr: nil, hrv: nil, sleep: oldPairs, spo2: nil, rr: nil, temp: nil))
        // New report
        let newPairs = pairsForVariant(variant: candidate, dataset: dataset)
        let newReport = ValidationEngine.shared.runBenchmark(dataset: BenchmarkDataset(name: "sleep_ab_\(candidate)", count: newPairs.count, hr: nil, hrv: nil, sleep: newPairs, spo2: nil, rr: nil, temp: nil))

        let decision = DynamicModelManager.shared.decideUpgrade(old: oldReport, new: newReport, gates: gates)
        let log = ABDecisionLog(timestamp: Date(), oldVariant: active.rawValue, newVariant: candidate.rawValue, decision: (decision == .upgrade ? "upgrade" : "keep_old"), oldReport: oldReport, newReport: newReport)
        persist(log)
        if decision == .upgrade { ModelVersionStore.shared.setActive(candidate) }
        return log
    }

    private func buildSleepBenchmark() -> (truth: [Int], windows: [[[Double]]]) {
        // TODO: load from bundled resource if available; for now synthesize 4h with simple stage blocks
        let epochs = 8*60 // 4 hours @ 30s epochs
        var truth: [Int] = []
        var windows: [[[Double]]] = []
        func synthEpoch(stage: Int, e: Int) -> [[Double]] {
            let T = 300
            var x = Array(repeating: Array(repeating: 0.0, count: T), count: 3)
            for t in 0..<T {
                let tt = Double(e*T + t)
                x[0][t] = 0.5 * sin(tt/45.0) + Double.random(in: -0.05...0.05) + (stage==0 ? 0.2 : 0.0)
                x[1][t] = 0.3 * sin(tt/120.0) + Double.random(in: -0.03...0.03) + (stage==3 ? -0.1 : 0.0)
                x[2][t] = (stage==0) ? Double.random(in: 0.05...0.2) : Double.random(in: 0.0...0.08)
            }
            return x
        }
        for e in 0..<epochs {
            let st: Int
            switch e / 120 {
            case 0: st = 2
            case 1: st = 3
            case 2: st = 4
            case 3: st = 2
            default: st = 2
            }
            truth.append(st)
            windows.append(synthEpoch(stage: st, e: e))
        }
        return (truth, windows)
    }

    private func pairsForVariant(variant: SleepModelVariant, dataset: (truth: [Int], windows: [[[Double]]])) -> [(Int, Int)] {
        let pred = SleepStageNetCoordinator.shared.predictStagesBatch(using: variant, windows: dataset.windows) ?? Array(repeating: 2, count: dataset.truth.count)
        let n = min(pred.count, dataset.truth.count)
        var pairs: [(Int, Int)] = []
        for i in 0..<n { pairs.append((dataset.truth[i], pred[i])) }
        return pairs
    }

    private func persist(_ log: ABDecisionLog) {
        let dir = ValidationEngine.reportsDirectory() // same Eval/reports path
        let url = dir.appendingPathComponent("ab_decision.json")
        if let d = try? JSONEncoder().encode(log) { try? d.write(to: url) }
    }
}

final class UpgradeOrchestrator {
    static let shared = UpgradeOrchestrator()
    private init() {}
    func runIfCandidateAvailable() {
        // Candidate is CoreML when currently on Swift and CoreML present
        let available = SleepStageNetCoordinator.shared.variantsAvailable()
        let active = ModelVersionStore.shared.activeVariant()
        if active == .swift && available.contains(.coreml) {
            _ = ABTester.shared.runSleepStagingAB()
        }
    }
}
