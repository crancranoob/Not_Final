import Foundation

struct StudentMLP: Codable {
    var W1: [Double]
    var b1: [Double]
    var W2: [Double]
    var b2: Double
    let dIn: Int
    let dHid: Int

    init(dIn: Int = 9, dHid: Int = 24) {
        self.dIn = dIn; self.dHid = dHid
        self.W1 = (0..<(dIn*dHid)).map { _ in Double.random(in: -0.02...0.02) }
        self.b1 = (0..<dHid).map { _ in 0.0 }
        self.W2 = (0..<dHid).map { _ in Double.random(in: -0.02...0.02) }
        self.b2 = 0.0
    }
    func forward(_ x: [Double]) -> Double {
        var h = [Double](repeating: 0, count: dHid)
        for i in 0..<dHid {
            var s = b1[i]
            for j in 0..<dIn { s += W1[i*dIn + j] * x[j] }
            h[i] = max(0, s)
        }
        var y = b2
        for i in 0..<dHid { y += W2[i] * h[i] }
        // map raw to 1..5 via Platt-like sigmoid scaled
        let z = 1.0 / (1.0 + exp(-y))
        return 1.0 + 4.0 * z
    }
    mutating func update(x: [Double], yTrue: Double, lr: Double = 1e-3) {
        // Backprop vs target in 1..5
        // Forward
        var h = [Double](repeating: 0, count: dHid)
        var pre = [Double](repeating: 0, count: dHid)
        for i in 0..<dHid {
            var s = b1[i]
            for j in 0..<dIn { s += W1[i*dIn + j] * x[j] }
            pre[i] = s
            h[i] = max(0, s)
        }
        var y = b2
        for i in 0..<dHid { y += W2[i] * h[i] }
        let z = 1.0 / (1.0 + exp(-y))
        let yPred = 1.0 + 4.0 * z
        let gradOut = (yPred - y) * 0 + (yPred - yTrue) // simple L2 on calibrated output

        // dW2/db2
        for i in 0..<dHid { W2[i] -= lr * gradOut * h[i] }
        b2 -= lr * gradOut
        // back to h with ReLU
        var gradH = [Double](repeating: 0, count: dHid)
        for i in 0..<dHid { gradH[i] = gradOut * W2[i] * (pre[i] > 0 ? 1 : 0) }
        for i in 0..<dHid {
            b1[i] -= lr * gradH[i]
            for j in 0..<dIn { W1[i*dIn + j] -= lr * gradH[i] * x[j] }
        }
    }
}

/// Lightweight ensemble for uncertainty
struct StudentEnsemble: Codable {
    var members: [StudentMLP]
    init(k: Int = 3, dIn: Int = 9, dHid: Int = 24) {
        members = (0..<k).map { _ in StudentMLP(dIn: dIn, dHid: dHid) }
    }
    func predict(_ x: [Double]) -> (mean: Double, std: Double) {
        let preds = members.map { $0.forward(x) }
        let mean = preds.reduce(0,+)/Double(preds.count)
        let var_ = preds.reduce(0) { $0 + pow($1-mean, 2) } / Double(preds.count)
        return (mean, sqrt(max(var_, 1e-9)))
    }
    mutating func update(x: [Double], y: Double, lr: Double = 1e-3) {
        for i in 0..<members.count { members[i].update(x: x, yTrue: y, lr: lr) }
    }
}

final class StudentModelCoordinator: ObservableObject {
    static let shared = StudentModelCoordinator()
    private let url: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("student_model.json")
    }()
    @Published var ensemble: StudentEnsemble = StudentEnsemble()
    init() { load() }
    func load() {
        if let data = try? Data(contentsOf: url), let m = try? JSONDecoder().decode(StudentEnsemble.self, from: data) {
            ensemble = m
        }
    }
    func save() {
        if let data = try? JSONEncoder().encode(ensemble) { try? data.write(to: url) }
    }
    func predict(x: [Double]) -> (mean: Double, std: Double) { ensemble.predict(x) }
    func update(x: [Double], y: Double) { ensemble.update(x: x, y: y) ; save() }
}

extension StudentModelCoordinator {
    func updateOnline(x: [Double], target: Double, lr: Double = 5e-4) {
        var ens = ensemble
        ens.update(x: x, y: target, lr: lr)
        ensemble = ens
        save()
    }
}
