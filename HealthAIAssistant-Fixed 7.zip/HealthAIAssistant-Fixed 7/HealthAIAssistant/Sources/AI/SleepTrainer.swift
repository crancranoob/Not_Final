import Foundation
import UIKit

final class SleepTrainer {
    static let shared = SleepTrainer()
    private init() {}

    /// Nightly training for the sleep model, charging-only and within 00:00–07:00 enforced by scheduler.
    func trainNight(epochs: Int = 10, lr: Double = 1e-3) {
        // Build a small supervised dataset from your last N nights by using your own daily self-score as proxy target (or derived targets)
        let recs = CSVDataManager.shared.records
        guard recs.count >= 7 else { return }
        var dataset: [([Double], Double)] = []
        for r in recs {
            let nf = NightFeatures(date: r.date,
                                   duration: r.sleepHours*3600,
                                   efficiency: 0.85, // placeholder if not computed per night
                                   remPct: 0.2,
                                   deepPct: 0.15,
                                   awakenings: 2,
                                   meanHR: r.heartRate,
                                   meanHRV: r.hrvSDNN ?? 40,
                                   meanRR: r.respiratoryRate ?? 14)
            if let y = r.userScore {
                dataset.append((nf.asVector(), y*20)) // scale 1–5 -> 20–100
            }
        }
        guard dataset.count >= 7 else { return }

        var model = SleepModelCoordinator.shared.model
        for _ in 0..<epochs {
            let shuffled = dataset.shuffled()
            for (x, y) in shuffled {
                model.update(x: x, yTrue: y, lr: lr)
            }
        }
        SleepModelCoordinator.shared.model = model
        SleepModelCoordinator.shared.save()
        NotificationManager.shared.notify(title: "睡眠模型已更新", body: "已在夜間完成大型睡眠模型的訓練。")
    }
}
