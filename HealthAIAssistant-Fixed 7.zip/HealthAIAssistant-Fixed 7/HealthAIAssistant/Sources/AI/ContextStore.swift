import Foundation

struct DayContext: Codable, Identifiable {
    let id: String
    let date: Date
    var hydrationLiters: Double
    var caffeineMgTotal: Double
    var caffeineMgLate: Double // after 14:00 local
    var hydrationPrevLiters: Double // yesterday's liters (for lag)
    init(date: Date, hydrationLiters: Double = 0, caffeineMgTotal: Double = 0, caffeineMgLate: Double = 0, hydrationPrevLiters: Double = 0) {
        self.id = UUID().uuidString
        self.date = Calendar.current.startOfDay(for: date)
        self.hydrationLiters = hydrationLiters
        self.caffeineMgTotal = caffeineMgTotal
        self.caffeineMgLate = caffeineMgLate
        self.hydrationPrevLiters = hydrationPrevLiters
    }
}

final class ContextStore: ObservableObject {
    static let shared = ContextStore()
    @Published private(set) var days: [Date: DayContext] = [:] // keyed by startOfDay
    private init() { load() }
    private var url: URL {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("context_store.json")
    }
    func set(_ ctx: DayContext) {
        days[Calendar.current.startOfDay(for: ctx.date)] = ctx; save()
    }
    func merge(_ arr: [DayContext]) {
        for c in arr { days[Calendar.current.startOfDay(for: c.date)] = c }
        save()
    }
    func get(_ date: Date) -> DayContext? { days[Calendar.current.startOfDay(for: date)] }
    func all() -> [DayContext] { Array(days.values).sorted { $0.date < $1.date } }
    private func save() {
        let arr = Array(days.values)
        if let d = try? JSONEncoder().encode(arr) { try? d.write(to: url) }
    }
    private func load() {
        guard let d = try? Data(contentsOf: url), let arr = try? JSONDecoder().decode([DayContext].self, from: d) else { return }
        for c in arr { days[Calendar.current.startOfDay(for: c.date)] = c }
    }
}
