import Foundation

struct BayesianPosterior: Codable {
    let mean: Double
    let lower: Double
    let upper: Double
}

final class BayesianLayer {
    static let shared = BayesianLayer()
    private init() {}
    // Treat normalized score in [0,1] as a Beta posterior; convert to 1..5 after
    func infer(scoreRaw: Double, priorAlpha: Double = 8, priorBeta: Double = 8, n: Int = 20, varianceHint: Double = 0.05) -> BayesianPosterior {
        // Clamp raw to (0,1); interpret as success rate proxy
        let p = min(0.999, max(0.001, (scoreRaw - 1.0) / 4.0))
        let alphaPost = priorAlpha + p*Double(n)
        let betaPost = priorBeta + (1.0-p)*Double(n)
        // Mean
        let meanP = alphaPost / (alphaPost + betaPost)
        // Approx 95% CI with normal approx to Beta
        let varP = (alphaPost * betaPost) / (pow(alphaPost + betaPost, 2) * (alphaPost + betaPost + 1))
        let sd = sqrt(max(1e-6, varP))
        let lo = max(0.0, meanP - 1.96*sd), hi = min(1.0, meanP + 1.96*sd)
        // Map back to 1..5
        return BayesianPosterior(mean: 1.0 + 4.0*meanP, lower: 1.0 + 4.0*lo, upper: 1.0 + 4.0*hi)
    }
}
