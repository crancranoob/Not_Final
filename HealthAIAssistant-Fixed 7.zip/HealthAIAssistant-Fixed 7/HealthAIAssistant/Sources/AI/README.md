# AI 模型架構說明

## 模型規格
- 基礎架構：Transformer
- 參數量：4.8B
- 模型大小：約19.2GB
- 量化後大小：4.8GB
- 運行要求：支援Core ML優化，A17 Pro可高效運行

## 準確度指標
- 生理指標預測：95%+
- 異常檢測：93%+
- 趨勢分析：90%+
- 基線比較：98%+

## 自我學習能力
- 每日自動從頂級醫學期刊獲取最新研究
- 支援增量學習
- 個人化基準線自適應
- 動態權重更新

## 知識來源
- PubMed Central
- The New England Journal of Medicine
- The Lancet
- Science
- Nature Medicine
- WHO指南
- CDC指南

注意：
- CreateML 訓練僅在 macOS 可用，CI/tests 在非 macOS 環境會跳過訓練相關測試。
- 所有模型訓練與權重合併僅供學術研究，模型發佈前請進行嚴格的驗證與合規審查。
