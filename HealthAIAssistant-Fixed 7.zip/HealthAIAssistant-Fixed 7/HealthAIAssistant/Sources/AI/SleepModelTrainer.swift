import Foundation
import CoreML
#if canImport(CreateML)
#if canImport(CreateML)
import CreateML
#endif
#endif

final class SleepModelTrainer {
	// 訓練睡眠分數回歸模型（輸入 CSV 有 columns 包含 features 與 targetColumn）
	#if canImport(CreateML)
	func trainRegressor(trainingCSV: URL, validationCSV: URL?, targetColumn: String = "sleep_score", modelName: String, saveFolder: URL) throws -> MLModel {
		let trainingTable = try MLDataTable(contentsOf: trainingCSV)
		let regressor = try MLRegressor(trainingData: trainingTable, targetColumn: targetColumn)
		// 可對 regressor 進行配置（如最大樹數、深度等）若使用 CreateML 的參數
		let timestamp = ISO8601DateFormatter().string(from: Date())
		let filename = "\(modelName)-\(timestamp).mlmodel"
		let saveURL = saveFolder.appendingPathComponent(filename)
		try regressor.write(to: saveURL)
		// 載入 Core ML MLModel 並回傳
		let coremlModel = try MLModel(contentsOf: saveURL)
		try registerModel(coremlModel, identifier: modelName, version: timestamp)
		return coremlModel
	}
	#endif

	private func registerModel(_ model: MLModel, identifier: String, version: String) throws {
		// 儲存 model 到 ModelRegistry（若存在）
		do {
			try ModelRegistry.shared.registerModel(model, identifier: identifier, version: version)
		} catch {
			// 若無 registry，嘗試將 model 保存在 Documents
			let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
			let fallback = docs.appendingPathComponent("\(identifier)-\(version).mlmodel")
			try model.write(to: fallback)
		}
	}
}
