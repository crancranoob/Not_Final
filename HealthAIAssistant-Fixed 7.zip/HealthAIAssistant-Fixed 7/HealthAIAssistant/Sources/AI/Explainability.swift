import Foundation

struct Contribution { let name: String; let value: Double }

final class Explainability {
    static let shared = Explainability()
    func contributions(lastFeatures: [Double], embed: [Double], reg: OnlineRegressor, names: [String]) -> [Contribution] {
        // reg.weights length should match lastFeatures+embed
        let xAll = lastFeatures + embed
        let w = reg.weights
        var arr: [Contribution] = []
        let count = min(xAll.count, w.count, names.count)
        for i in 0..<count {
            arr.append(Contribution(name: names[i], value: xAll[i] * w[i]))
        }
        // sort by absolute contribution descending
        return arr.sorted { abs($0.value) > abs($1.value) }
    }
}
