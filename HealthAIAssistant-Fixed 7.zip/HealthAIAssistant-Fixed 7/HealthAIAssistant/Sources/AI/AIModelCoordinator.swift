import CoreML
import Foundation
#if canImport(CreateML)
import CreateML
#endif
import NaturalLanguage
import Vision

class AIModelCoordinator: ObservableObject {
    private let optimizer = PerformanceOptimizer()
    private let resourceMonitor = ResourceMonitor()
    private let performanceMonitor = PerformanceMonitor()
    private let errorHandler = ErrorHandler()
    private let modelCache = ModelCache()
    
    @Published var isAnalyzing = false
    @Published var currentAnalysis: HealthAnalysis?
    
    private var healthModel: MLModel?
    private var medicalKnowledgeModel: MLModel?
    private var vitalSignsModel: MLModel?
    private var sleepAnalysisModel: MLModel?
    private var symptomClassifier: MLModel?
    private var transformerModel: HealthTransformer?
    private var personalBaseline: PersonalBaseline
    private var knowledgeUpdater: MedicalKnowledgeUpdater
    
    private let medicalKnowledgeValidator = MedicalKnowledgeValidator()
    private let healthMetricsAnalyzer = HealthMetricsAnalyzer()
    
    private var chatHistory: [(String, String)] = []
    private var internetAccess = false
    
    @Published var isLearning = false
    
    private let normalRanges = [
        "heartRate": (min: 60.0, max: 100.0),
        "oxygenSaturation": (min: 95.0, max: 100.0),
        "systolicBP": (min: 90.0, max: 120.0),
        "diastolicBP": (min: 60.0, max: 80.0),
        "bodyTemperature": (min: 36.1, max: 37.2),
        "respiratoryRate": (min: 12.0, max: 20.0)
    ]
    
    private let modelConfig = TransformerConfig(
        layers: 12,
        attention_heads: 16,
        hidden_size: 768,
        intermediate_size: 3072,
        max_position_embeddings: 512
    )
    
    init() {
        setupModels()
        personalBaseline = PersonalBaseline()
        knowledgeUpdater = MedicalKnowledgeUpdater()
    }
    
    private func setupModels() {
        Task {
            do {
                // iOS / iPadOS: 優先使用所有可用單元 (CPU + GPU + Neural Engine)
                let config = MLModelConfiguration()
                config.computeUnits = .all
                // 在 iOS 16.0+ 可啟用進階選項
                if #available(iOS 16.0, *) {
                    config.allowLowPrecisionAccumulationOnGPU = true
                }
                
                async let hTask = loadModel("HealthAnalyzer", config)
                async let kTask = loadModel("MedicalKnowledge", config)
                async let vTask = loadModel("VitalSigns", config)
                
                let hModel = try await hTask
                let kModel = try await kTask
                let vModel = try await vTask

                try await setupModelPipeline([hModel, kModel, vModel])
            } catch {
                await errorHandler.handle(error)
            }
        }
    }

    private func loadModel(_ name: String, _ config: MLModelConfiguration) async throws -> MLModel {
        if let cached = modelCache.get(name) { return cached }

        return try await performanceMonitor.measure("LoadModel-\(name)") {
            // 先在 bundle 找 .mlmodelc / .mlmodel
            if let compiledURL = Bundle.main.url(forResource: name, withExtension: "mlmodelc") {
                return try MLModel(contentsOf: compiledURL, configuration: config)
            } else if let modelURL = Bundle.main.url(forResource: name, withExtension: "mlmodel") {
                let compiled = try MLModel.compileModel(at: modelURL)
                return try MLModel(contentsOf: compiled, configuration: config)
            } else {
                throw ModelError.invalidVersion
            }
        }
    }
    
    func analyzeHealthData(_ data: HealthData) async throws -> HealthAnalysis {
        // 嘗試從註冊表或快取載入預測模型
        let predictorModel = ModelRegistry.shared.getModel("HealthPredictor") ?? modelCache.get("HealthPredictor")
        let predictionEngine = PredictionEngine(model: predictorModel)
        
        // 使用增強的預測引擎（async）
        let predictions = try await predictionEngine.predict(data)
        
        // 執行多維度分析（並行）
        async let vitalAnalysis = analyzeVitalSignsEnhanced(data)
        async let trendsAnalysis = analyzeHealthTrendsEnhanced(data)
        async let riskAnalysis = analyzeHealthRisksEnhanced(data)
        
        let results = await (
            vitals: vitalAnalysis,
            trends: trendsAnalysis,
            risks: riskAnalysis
        )
        
        // 整合分析結果
        return integrateAnalysis(
            predictions: predictions,
            vitalSigns: results.vitals,
            trends: results.trends,
            risks: results.risks
        )
    }
    
    private func analyzeVitalSignsEnhanced(_ data: HealthData) async -> VitalSignsAnalysis {
        let analyzer = VitalSignsAnalyzer(
            configuration: .init(
                samplingRate: .highFrequency,
                windowSize: .adaptive,
                sensitivity: .high
            )
        )
        
        return await analyzer.analyze(
            data,
            withContext: .init(
                personalBaseline: personalBaseline,
                timeOfDay: .current,
                recentActivity: await fetchRecentActivity()
            )
        )
    }
    
    private func analyzeHealthRisksEnhanced(_ data: HealthData) async -> RiskAnalysis {
        let riskEngine = HealthRiskEngine()
        return await riskEngine.analyzeRisks(
            data,
            using: [
                .statisticalModeling,
                .machineLearning,
                .expertSystems,
                .bayesianInference
            ],
            withConfidenceThreshold: 0.95
        )
    }
    
    func toggleInternetAccess() {
        internetAccess.toggle()
    }
    
    func processMedicalQuery(_ query: String, withContext context: HealthData?) async -> String {
        guard let medicalKnowledgeModel = medicalKnowledgeModel else {
            return "醫療知識模型未載入"
        }
        
        // 添加到聊天歷史
        chatHistory.append((query, ""))
        
        // 結合上下文生成回應
        let response = await generateMedicalResponse(
            query: query,
            context: context,
            history: chatHistory
        )
        
        // 更新聊天歷史的回應
        chatHistory[chatHistory.count - 1].1 = response
        
        return response
    }
    
    private func analyzeMetrics(_ data: HealthData) async -> [String] {
        var insights: [String] = []
        
        // 深入分析生命體徵
        let vitalSignsAnalysis = await analyzeVitalSigns(data)
        insights.append(contentsOf: vitalSignsAnalysis)
        
        // 分析睡眠質量
        if let sleepAnalysis = await analyzeSleepPattern(data) {
            insights.append(contentsOf: sleepAnalysis)
        }
        
        // 分析運動模式
        let activityAnalysis = await analyzeActivityPatterns(data)
        insights.append(contentsOf: activityAnalysis)
        
        // 進行綜合健康評估
        let overallHealth = await performOverallHealthAssessment(data)
        insights.append(contentsOf: overallHealth)
        
        return insights
    }
    
    private func analyzeVitalSigns(_ data: HealthData) async -> [String] {
        var analysis: [String] = []
        
        // 深度心率分析
        if let hrvData = await calculateHRV(data.heartRateData) {
            analysis.append(contentsOf: interpretHRV(hrvData))
        }
        
        // 血氧飽和度深度分析
        if data.oxygenSaturation < normalRanges["oxygenSaturation"]!.min {
            let severity = calculateSeverity(data.oxygenSaturation, 
                                          forMetric: "oxygenSaturation")
            analysis.append(generateAlert(forMetric: "oxygenSaturation", 
                                       severity: severity))
        }
        
        // 血壓趨勢分析
        if let bpTrend = analyzeBPTrend(data) {
            analysis.append(contentsOf: interpretBPTrend(bpTrend))
        }
        
        return analysis
    }
    
    private func calculateHRV(_ heartRateData: [Double]) async -> HRVMetrics? {
        guard heartRateData.count >= 300 else { return nil }
        
        let timeSeriesAnalyzer = TimeSeriesAnalyzer()
        let hrvMetrics = HRVMetrics(
            sdnn: timeSeriesAnalyzer.calculateSDNN(heartRateData),
            rmssd: timeSeriesAnalyzer.calculateRMSSD(heartRateData),
            pnn50: timeSeriesAnalyzer.calculatePNN50(heartRateData),
            lfhfRatio: timeSeriesAnalyzer.calculateLFHFRatio(heartRateData)
        )
        
        return hrvMetrics
    }
    
    private func interpretHRV(_ metrics: HRVMetrics) -> [String] {
        var insights = [String]()
        
        // SDNN 分析 (心率變異性標準差)
        if metrics.sdnn < 50 {
            insights.append("您的心率變異性偏低，可能表示壓力水平較高")
        }
        
        // RMSSD 分析 (相鄰心跳間隔差值的均方根)
        if metrics.rmssd < 20 {
            insights.append("副交感神經活性可能較低，建議進行放鬆訓練")
        }
        
        // LF/HF比率分析 (交感/副交感神經平衡)
        if metrics.lfhfRatio > 2.5 {
            insights.append("交感神經活性較高，可能處於壓力狀態")
        }
        
        return insights
    }
    
    private func generateRecommendations(from insights: [String]) async -> [String] {
        // 根據分析生成建議
        var recommendations: [String] = []
        
        for insight in insights {
            if insight.contains("心率偏高") {
                recommendations.append("建議進行放鬆活動，減少咖啡因攝入")
            }
            // 添加更多建議邏輯
        }
        
        return recommendations
    }
    
    private func analyzeTrends(_ data: HealthData) async -> [String: Trend] {
        var trends: [String: Trend] = [:]
        
        // 分析時序數據
        let timeframes: [TimeFrame] = [.day, .week, .month, .year]
        for metric in data.metrics.keys {
            let timeseriesData = await fetchHistoricalData(for: metric, timeframes: timeframes)
            let analysis = await performTimeSeriesAnalysis(timeseriesData)
            let baseline = personalBaseline.getDeviation(metric: metric, value: data.metrics[metric]!)
            
            trends[metric] = Trend(
                current: data.metrics[metric]!,
                historical: timeseriesData,
                analysis: analysis,
                baselineComparison: baseline,
                significance: calculateSignificance(analysis),
                confidenceInterval: calculateConfidenceInterval(analysis)
            )
        }
        
        return trends
    }

    private func performTimeSeriesAnalysis(_ data: [TimeseriesPoint]) async -> TimeseriesAnalysis {
        // 使用進階時間序列分析
        let decomposition = await seasonalDecomposition(data)
        let trends = await detectTrends(decomposition)
        let patterns = await identifyPatterns(decomposition)
        let predictions = await forecastValues(using: decomposition)
        
        return TimeseriesAnalysis(
            trend: trends,
            seasonality: decomposition.seasonal,
            patterns: patterns,
            forecast: predictions,
            accuracy: calculateAccuracy(predictions, actual: data),
            confidence: calculateConfidenceIntervals(predictions)
        )
    }

    private func updateModels() async {
        // 定期更新和改進模型
        let modelPerformance = await evaluateModelPerformance()
        if modelPerformance.requiresUpdate {
            await performIncrementalLearning()
            await validateModelAccuracy()
        }
        
        // 更新醫學知識庫
        let newFindings = await fetchLatestMedicalFindings()
        if !newFindings.isEmpty {
            await updateKnowledgeBase(with: newFindings)
            await validateKnowledgeIntegrity()
        }
    }
    
    private func generateMedicalResponse(query: String, context: HealthData?, history: [(String, String)]) async -> String {
        let queryClassification = await classifyMedicalQuery(query)
        let relevantStudies = await fetchRelevantStudies(query)
        let evidenceBasedGuidelines = await fetchMedicalGuidelines(query)
        
        // 使用醫學知識圖譜進行推理
        let knowledgeGraph = MedicalKnowledgeGraph()
        let reasoning = await knowledgeGraph.performClinicalReasoning(
            query: query,
            context: context,
            evidence: relevantStudies
        )
        
        // 整合多源醫療建議
        var response = await synthesizeMedicalAdvice(
            reasoning: reasoning,
            guidelines: evidenceBasedGuidelines,
            userProfile: context?.profile
        )
        
        // 添加可信度評分
        let confidence = calculateConfidenceScore(reasoning, evidenceBasedGuidelines)
        response += "\n\n證據等級：\(confidence.description)"
        
        return response
    }
    
    private func classifyMedicalQuery(_ query: String) async -> QueryClassification {
        let classifier = try? NLClassifier(mlModel: symptomClassifier!)
        let prediction = classifier?.predictedLabel(for: query)
        
        return QueryClassification(
            category: prediction ?? "general",
            urgency: determineUrgency(query),
            requiresSpecialistAttention: checkSpecialistRequired(query)
        )
    }
    
    // 新增支援結構
    struct QueryIntent {
        enum QueryType {
            case medical, lifestyle, emergency
        }
        
        enum Urgency {
            case low, normal, high, emergency
        }
        
        let type: QueryType
        let urgency: Urgency
    }
    
    struct HRVMetrics {
        let sdnn: Double    // 心率變異性標準差
        let rmssd: Double   // 相鄰RR間期差值的均方根
        let pnn50: Double   // NN50除以總數
        let lfhfRatio: Double // 低頻高頻比
    }
    
    struct QueryClassification {
        let category: String
        let urgency: QueryIntent.Urgency
        let requiresSpecialistAttention: Bool
    }
    
    class MedicalKnowledgeValidator {
        private let medicalOntology = MedicalOntology()
        private let evidenceEvaluator = EvidenceEvaluator()
        
        func validateAndSynthesizeInformation(_ information: [String]) async -> String {
            let validatedInfo = await validateMedicalClaims(information)
            let synthesized = await synthesizeEvidence(validatedInfo)
            let crossReferenced = await crossReferenceWithGuidelines(synthesized)
            
            return formatResponse(crossReferenced)
        }
        
        private func validateMedicalClaims(_ claims: [String]) async -> [ValidatedClaim] {
            return await claims.asyncMap { claim in
                let evidenceLevel = await evidenceEvaluator.evaluateClaim(claim)
                let sourceReliability = await checkSourceReliability(claim)
                let consistencyScore = await checkConsistencyWithKnowledge(claim)
                
                return ValidatedClaim(
                    claim: claim,
                    evidenceLevel: evidenceLevel,
                    reliability: sourceReliability,
                    consistency: consistencyScore
                )
            }
        }
    }
    
    class HealthMetricsAnalyzer {
        private let diseasePredictor = DiseasePredictor()
        private let anomalyDetector = AnomalyDetector()
        
        func analyzeHealthMetrics(_ data: HealthData) async -> HealthAnalysis {
            let predictions = await diseasePredictor.predictPotentialConditions(data)
            let anomalies = await anomalyDetector.detectAnomalies(in: data)
            
            return HealthAnalysis(
                predictions: predictions,
                anomalies: anomalies,
                riskAssessment: calculateRiskScore(data)
            )
        }
        
        private func calculateRiskScore(_ data: HealthData) -> RiskScore {
            // 實現風險評分計算
            var score = 0.0
            
            // 評估生命體徵
            if data.heartRate > 100 { score += 2.0 }
            if data.oxygenSaturation < 95 { score += 3.0 }
            
            return RiskScore(
                value: score,
                factors: identifyRiskFactors(data),
                recommendations: generateRiskRecommendations(score)
            )
        }
    }
    
    class DiseasePredictor {
        private var model: MLModel
        private let conditions: Set<String> = ["心血管疾病", "睡眠障礙", "壓力相關疾病", "代謝異常"]
        private let deepLearningModel = try? MLModel(contentsOf: Bundle.main.url(forResource: "DeepHealthNet", withExtension: "mlmodel")!)
        
        func predictPotentialConditions(_ data: HealthData) async -> [Prediction] {
            var predictions: [Prediction] = []
            
            for condition in conditions {
                if let risk = await calculateRisk(for: condition, with: data) {
                    predictions.append(Prediction(
                        condition: condition,
                        probability: risk.probability,
                        confidence: risk.confidence,
                        evidenceStrength: risk.evidenceStrength
                    ))
                }
            }
            
            return predictions
        }
        
        private func calculateRisk(for condition: String, with data: HealthData) async -> Risk? {
            guard let model = deepLearningModel else { return nil }
            
            let features = extractFeatures(from: data)
            let prediction = try? model.prediction(from: features)
            
            guard let outputFeatures = prediction?.featureValue(for: "risk_score") else { return nil }
            
            let probability = outputFeatures.doubleValue
            let confidence = calculateConfidence(features)
            let evidenceLevel = determineEvidenceLevel(confidence)
            
            return Risk(
                probability: probability,
                confidence: confidence,
                evidenceStrength: evidenceLevel
            )
        }
        
        private func extractFeatures(from data: HealthData) -> MLFeatureProvider {
            let features = [
                "heart_rate": data.heartRate,
                "oxygen_saturation": data.oxygenSaturation,
                "blood_pressure_systolic": data.bloodPressureSystolic,
                "blood_pressure_diastolic": data.bloodPressureDiastolic,
                "body_temperature": data.bodyTemperature,
                "respiratory_rate": data.respiratoryRate,
                "hrv_sdnn": data.hrvMetrics?.sdnn ?? 0.0,
                "activity_level": data.activityMetrics.dailySteps
            ]
            
            return try! MLDictionaryFeatureProvider(dictionary: features)
        }
    }
    
    class AnomalyDetector {
        private let algorithms = [
            "IsolationForest",
            "LocalOutlierFactor",
            "OneClassSVM"
        ]
        
        func detectAnomalies(in data: HealthData) async -> [Anomaly] {
            var anomalies: [Anomaly] = []
            
            for algorithm in algorithms {
                if let detected = await runDetection(algorithm, on: data) {
                    anomalies.append(contentsOf: detected)
                }
            }
            
            return anomalies
        }
    }
    
    private func initializeTransformerModel() {
        transformerModel = HealthTransformer(
            config: modelConfig,
            modelURL: Bundle.main.url(forResource: "HealthTransformer-4.8B", withExtension: "mlmodel")!
        )
    }
    
    private func updateKnowledge() async {
        let sources = [
            "pubmed": "https://pubmed.ncbi.nlm.nih.gov",
            "nejm": "https://www.nejm.org",
            "thelancet": "https://www.thelancet.com",
            "science": "https://www.science.org",
            "nature": "https://www.nature.com"
        ]
        
        for (source, url) in sources {
            let newPapers = await knowledgeUpdater.fetchLatestPapers(from: url)
            let validatedKnowledge = await knowledgeUpdater.validateNewKnowledge(newPapers)
            await knowledgeUpdater.integrateKnowledge(validatedKnowledge)
        }
    }
    
    private func analyzeHealthTrends(_ data: HealthData) async -> TrendAnalysis {
        let daily = await compareToPrevious(data, timeFrame: .day)
        let weekly = await compareToPrevious(data, timeFrame: .week)
        let monthly = await compareToPrevious(data, timeFrame: .month)
        let yearly = await compareToPrevious(data, timeFrame: .year)
        let baseline = await compareToBaseline(data)
        
        return TrendAnalysis(
            dailyComparison: daily,
            weeklyComparison: weekly,
            monthlyComparison: monthly,
            yearlyComparison: yearly,
            baselineComparison: baseline,
            significance: calculateStatisticalSignificance([daily, weekly, monthly, yearly]),
            confidenceInterval: calculateConfidenceIntervals(data)
        )
    }
    
    private func updatePersonalBaseline(_ data: HealthData) {
        personalBaseline.updateBaseline(with: data)
    }
    
    private func adjustModelPerformance(based metrics: ResourceMetrics) {
        let adjustmentStrategy = determineAdjustmentStrategy(metrics)
        
        switch adjustmentStrategy {
        case .reduceComplexity(let level):
            reduceModelComplexity(level: level)
        case .increasePerformance(let capabilities):
            increaseModelPerformance(capabilities)
        case .optimizeMemory(let target):
            optimizeMemoryUsage(target)
        case .none:
            break
        }
        
        updateModelConfiguration()
    }
    
    private func determineAdjustmentStrategy(_ metrics: ResourceMetrics) -> AdjustmentStrategy {
        if metrics.memoryPressure > 0.85 {
            return .optimizeMemory(target: 0.7)
        }
        
        if metrics.cpuLoad > 0.9 {
            return .reduceComplexity(level: .aggressive)
        }
        
        if metrics.gpuUtilization < 0.5 && metrics.memoryAvailable > 2_000_000_000 {
            return .increasePerformance([.enableParallel, .increasePrecision])
        }
        
        return .none
    }

    private func reduceModelComplexity(level: ComplexityReduction) {
        switch level {
        case .moderate:
            modelConfig.updateLayers(max: 8)
            modelConfig.updateAttentionHeads(max: 12)
        case .aggressive:
            modelConfig.updateLayers(max: 6)
            modelConfig.updateAttentionHeads(max: 8)
            modelConfig.enableQuantization(.int8)
        }
    }
    
    private func updateModelConfiguration() {
        Task {
            do {
                let updatedConfig = try await performanceMonitor.measureAsync("ConfigUpdate") {
                    try await reloadModelsWithCurrentConfig()
                }
                modelCache.invalidate()
                await applyNewConfiguration(updatedConfig)
            } catch {
                await errorHandler.handle(error, level: .warning)
            }
        }
    }
}

class HealthTransformer {
    private var model: MLModel
    private var tokenizer: HealthTokenizer
    private var attentionMaps: [String: [Float]]
    
    func processQuery(_ query: String, context: HealthContext) async -> TransformerOutput {
        let encoded = tokenizer.encode(query)
        let contextEmbedding = await embedHealthContext(context)
        
        let output = try? model.prediction(
            input: MLMultiArray(concatenating: [encoded, contextEmbedding])
        )
        
        return TransformerOutput(
            response: decodeResponse(output),
            attention: extractAttentionMaps(output),
            confidence: calculateConfidence(output)
        )
    }
}

class MedicalKnowledgeUpdater {
    private var knowledgeBase: MLDynamicModel
    private let validationThreshold = 0.95
    
    func validateNewKnowledge(_ papers: [MedicalPaper]) async -> [ValidatedKnowledge] {
        return await papers.asyncMap { paper in
            let evidenceLevel = await evaluateEvidenceLevel(paper)
            let methodologyScore = evaluateMethodology(paper)
            let impactFactor = await getJournalImpactFactor(paper.journal)
            
            return ValidatedKnowledge(
                content: paper,
                evidenceLevel: evidenceLevel,
                reliability: calculateReliability(methodologyScore, impactFactor),
                lastUpdated: Date()
            )
        }.filter { $0.reliability >= validationThreshold }
    }
    
    func integrateKnowledge(_ knowledge: [ValidatedKnowledge]) async {
        for item in knowledge {
            await knowledgeBase.updateWeights(with: item)
            await updateClinicalGuidelines(based: item)
        }
    }
}

struct PersonalBaseline {
    private var baselineMetrics: [String: BaselineStats]
    private let updateWeight = 0.05  // 增量學習權重
    
    mutating func updateBaseline(with data: HealthData) {
        for (metric, value) in data.metrics {
            if baselineMetrics[metric] == nil {
                baselineMetrics[metric] = BaselineStats()
            }
            baselineMetrics[metric]?.update(value, weight: updateWeight)
        }
    }
    
    func getDeviation(metric: String, value: Double) -> Deviation {
        guard let stats = baselineMetrics[metric] else { return .unknown }
        return stats.calculateDeviation(value)
    }
}

struct BaselineStats {
    var mean: Double
    var standardDeviation: Double
    var confidenceInterval: (lower: Double, upper: Double)
    var sampleSize: Int
    
    mutating func update(_ newValue: Double, weight: Double) {
        // 實現增量更新算法
        mean = (1 - weight) * mean + weight * newValue
        // 更新其他統計數據
    }
}

struct TimeseriesAnalysis {
    let trend: Trendline
    let seasonality: [SeasonalPattern]
    let patterns: [IdentifiedPattern]
    let forecast: [Prediction]
    let accuracy: AccuracyMetrics
    let confidence: ConfidenceIntervals
}

struct AccuracyMetrics {
    let mse: Double          // Mean Squared Error
    let mae: Double          // Mean Absolute Error
    let rmse: Double         // Root Mean Squared Error
    let r2: Double          // R-squared value
    let crossValidation: CrossValidationResults
}

struct CrossValidationResults {
    let folds: Int
    let scores: [Double]
    let mean: Double
    let standardDeviation: Double
}

struct PerformanceMetrics {
    var executionTime: TimeInterval
    var memoryUsage: UInt64
    var cpuLoad: Double
    var metalUsage: Double
}

class PerformanceMonitor {
    private var metrics: [String: [PerformanceMetrics]] = [:]
    
    func measureAsync<T>(_ operation: String, _ block: () async throws -> T) async throws -> T {
        let start = DispatchTime.now()
        let result = try await block()
        let end = DispatchTime.now()
        
        let metrics = PerformanceMetrics(
            executionTime: Double(end.uptimeNanoseconds - start.uptimeNanoseconds) / 1_000_000_000,
            memoryUsage: getMemoryUsage(),
            cpuLoad: getCPULoad(),
            metalUsage: getMetalUsage()
        )
        
        updateMetrics(operation, metrics)
        return result
    }
}

extension AIModelCoordinator {
    /// Fallback analysis when Core ML models are not bundled.
    func analyzeWithoutML(_ data: HealthData) -> HealthAnalysis {
        // Simple rule-based scoring
        var issues: [String] = []
        let hr = data.heartRate
        if hr > 100 { issues.append("Elevated heart rate") }
        if hr < 45 { issues.append("Low heart rate") }
        if data.sleepHours < 6 { issues.append("Insufficient sleep") }
        if data.oxygenSaturation > 0 && data.oxygenSaturation < 0.94 { issues.append("Low SpO₂") }
        
        let score = max(0, 100 - issues.count * 10)
        return HealthAnalysis(score: score, notes: issues)
    }
}


extension AIModelCoordinator {
    func analyze(data: HealthData) {
        // Use fallback for now
        let result = analyzeWithoutML(data)
        DispatchQueue.main.async {
            self.currentAnalysis = result
            let body = DailyReportEngine.shared.generateReport(from: data)
            NotificationManager.shared.scheduleDailyReport(body: body)
        }
    }
}


import Accelerate

private let OnlineModelStoreURL: URL = {
    let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    return doc.appendingPathComponent("online_regressor.json")
}()

extension AIModelCoordinator {
    /// 以當日健康資料轉成特徵向量（示例）
    func features(from d: HealthData) -> [Double] {
        return [
            d.heartRate,
            Double(d.steps),
            d.activeEnergy,
            d.sleepHours,
            d.oxygenSaturation,
            d.bodyTemperature,
            d.walkingStability,
            d.hrvSDNN,
            d.respiratoryRate
        ]
    }
    
    func loadOnlineModel(featureCount: Int) -> OnlineRegressor {
        if let data = try? Data(contentsOf: OnlineModelStoreURL),
           let model = try? JSONDecoder().decode(OnlineRegressor.self, from: data) {
            return model
        }
        return OnlineRegressor(featureCount: featureCount, learningRate: 0.005)
    }
    
    func saveOnlineModel(_ m: OnlineRegressor) {
        if let data = try? JSONEncoder().encode(m) {
            try? data.write(to: OnlineModelStoreURL)
        }
    }
    
    /// 供 DailyCheckIn 使用：用使用者評分做持續學習
    func learnFromCheckIn(data: HealthData, userScore: Double) {
        var model = loadOnlineModel(featureCount: 9)
        let x = features(from: data)
        model.update(x: x, yTrue: userScore)
        saveOnlineModel(model)
    }
    
    /// 以線上模型產生個人化分數（與 fallback 合併使用）
    func personalizedScore(from data: HealthData) -> Double {
        let x = features(from: data)
        let model = loadOnlineModel(featureCount: x.count)
        return model.predict(x).clamped(to: 1...5)
    }
}
extension Double {
    func clamped(to range: ClosedRange<Double>) -> Double {
        return min(max(self, range.lowerBound), range.upperBound)
    }
}


extension AIModelCoordinator {
    func loadAttentive(dIn: Int) -> AttentiveAggregator {
        let url = OnlineModelStoreURL.deletingLastPathComponent().appendingPathComponent("attentive.json")
        if let data = try? Data(contentsOf: url),
           let attn = try? JSONDecoder().decode(AttentiveAggregator.self, from: data) {
            return attn
        }
        return AttentiveAggregator(dIn: dIn, dModel: 16, lr: 0.001)
    }
    func saveAttentive(_ m: AttentiveAggregator) {
        let url = OnlineModelStoreURL.deletingLastPathComponent().appendingPathComponent("attentive.json")
        if let data = try? JSONEncoder().encode(m) {
            try? data.write(to: url)
        }
    }
    
    /// 產生個人化分數 + 建議（結合知識庫）
    func personalizedAdvice(from data: HealthData) -> (Double, String) {
        let (score0, source) = masterPersonalizedScore(from: data)
        let score = score0
        let usedFallback = (source != "student")
        let warn = usedFallback ? "使用 \(source) 模型輸出" : nil
        if let warn = warn { NotificationManager.shared.notify(title: "模型檢核警示", body: warn) }
        let knowledge = KnowledgeUpdater.shared.loadKnowledge()
        let text = AdviceEngine.shared.advice(for: data, personalizedScore: score, knowledge: knowledge)
        return (score, text)
    }
}

    /// Rule vs Learned cross-check. If discrepancy > threshold, fall back to rule score and warn.
    func safePersonalizedScore(from data: HealthData, discrepancyThreshold: Double = SettingsStore.shared.discrepancyThreshold) -> (score: Double, usedFallback: Bool, warning: String?) {
        let learned = personalizedScore(from: data)
        let rule = analyzeWithoutML(data) // existing heuristic score
        let gap = abs(learned - rule)
        if gap > discrepancyThreshold {
            let msg = String(format: "Learned vs Rule 差異 %.2f 過大，採用規則分數以保守輸出。", gap)
            return (rule, true, msg)
        } else {
            return (learned, false, nil)
        }
    }

    func studentScore(from data: HealthData) -> (score: Double, std: Double) {
        let x = features(from: data)
        let (m, sd) = StudentModelCoordinator.shared.predict(x: x)
        return (m, sd)
    }
    
    func masterPersonalizedScore(from data: HealthData) -> (score: Double, source: String) {
        // Sleep context check (very simple heuristic: if last sleepHours > 0 today)
        if data.sleepHours > 0.1 {
            let sq = SleepModelCoordinator.shared.sleepQualityScore()
            return (max(1.0, min(5.0, sq/20.0)), "sleep")
        }
        // Student first
        let (sMean, sStd) = studentScore(from: data)
        if sStd < 0.25 {
            return (sMean, "student")
        }
        // Fallback to teacher
        let attn = loadAttentive(dIn: 9)
        let reg = loadOnlineModel(featureCount: 9 + attn.dModel)
        let x = features(from: data)
        let embed = attn.forward([x])
        let tPred = reg.predict(x + embed)
        return (tPred, "teacher")
    }

    // Daytime scoring with self-repair: if student uncertainty high or drift detected, query teacher and update student online.
    func scoreWithSelfRepair(from data: HealthData, uncertaintyThresh: Double = 0.25, driftThresh: Double = 0.75) -> (score: Double, source: String) {
        let x = features(from: data)
        let (sMean, sStd) = StudentModelCoordinator.shared.predict(x: x)
        let sCal = CalibrationStore.shared.calibrator(for: .student).apply(sMean)
        var chosen = (sCal, "student")
        var needTeacher = false
        
        if sStd >= uncertaintyThresh { needTeacher = true }
        // Optional drift check: compare to rule baseline
        let rule = RuleBaseline.shared.score(from: data) // assume exists; else set drift to false
        if abs(sCal - rule) > driftThresh { needTeacher = true }
        
        if needTeacher {
            // Compute teacher synchronously here (light data), update student online, and log to buffer
            let attn = loadAttentive(dIn: 9)
            let embed = attn.forward([x])
            let reg = loadOnlineModel(featureCount: 9 + attn.dModel)
            let tPred = reg.predict(x + embed)
            let tCal = CalibrationStore.shared.calibrator(for: .teacher).apply(tPred)
            // online correction
            StudentModelCoordinator.shared.updateOnline(x: x, target: tCal)
            // log to buffer
            let cc = CorrectionCase(features: x, student: sCal, teacher: tCal, label: nil)
            CorrectionBuffer.shared.append(cc)
            chosen = (tCal, "teacher-corrected")
        }
        return chosen
    }

    func healthDataFromDaily(_ r: DailyRecord) -> HealthData {
        var d = HealthData()
        d.heartRate = r.heartRate
        d.steps = r.steps
        d.activeEnergy = r.activeEnergy
        d.sleepHours = r.sleepHours
        d.oxygenSaturation = r.oxygenSaturation ?? 0.97
        d.bodyTemperature = r.bodyTemperature ?? 36.5
        d.walkingStability = r.walkingStability ?? 0.0
        d.hrvSDNN = r.hrvSDNN ?? 40.0
        d.respiratoryRate = r.respiratoryRate ?? 14.0
        return d
    }
