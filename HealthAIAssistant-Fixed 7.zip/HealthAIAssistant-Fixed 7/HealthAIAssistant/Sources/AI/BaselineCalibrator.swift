import Foundation

struct BaselineWindow: Codable {
    var meanHR: Double
    var meanHRV: Double
    var meanSleep: Double
    var updatedAt: Date
}

final class BaselineCalibrator {
    static let shared = BaselineCalibrator()
    private init() { load() }
    private var url: URL {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("baseline_calibrator.json")
    }
    private(set) var window = BaselineWindow(meanHR: 60, meanHRV: 40, meanSleep: 7, updatedAt: Date.distantPast)

    func update(with records: [DailyRecord]) {
        let last7 = Array(records.suffix(7))
        guard !last7.isEmpty else { return }
        let mHR = last7.map{$0.heartRate}.reduce(0,+)/Double(last7.count)
        let mHRV = last7.map{($0.hrvSDNN ?? 0)}.reduce(0,+)/Double(last7.count)
        let mSleep = last7.map{$0.sleepHours}.reduce(0,+)/Double(last7.count)
        window = BaselineWindow(meanHR: mHR, meanHRV: mHRV, meanSleep: mSleep, updatedAt: Date())
        save()
    }
    func zHR(_ hr: Double) -> Double { (hr - window.meanHR) / max(1.0, window.meanHR * 0.15) }
    func zHRV(_ hrv: Double) -> Double { (hrv - window.meanHRV) / max(5.0, window.meanHRV * 0.25) }
    func zSleep(_ s: Double) -> Double { (s - window.meanSleep) / max(0.5, window.meanSleep * 0.15) }
    func adjustFalsePositives(score: Double, hr: Double, hrv: Double) -> Double {
        // If HR is slightly high but HRV is normal, dampen negative impact (reduce false positives)
        let zh = zHR(hr), zv = zHRV(hrv)
        if zh > 0.5 && zv > -0.3 { return min(5.0, score + 0.1) }
        return score
    }
    private func save() { if let d = try? JSONEncoder().encode(window) { try? d.write(to: url) } }
    private func load() { if let d = try? Data(contentsOf: url), let w = try? JSONDecoder().decode(BaselineWindow.self, from: d) { window = w } }
}
