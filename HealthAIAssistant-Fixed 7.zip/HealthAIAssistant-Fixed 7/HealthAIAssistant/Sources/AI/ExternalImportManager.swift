import Foundation

final class ExternalImportManager {
	let appGroupID: String? = nil // 若使用 App Group，填寫 group.com.example.app

	/// 匯入 CSV（簡單解析），回傳原始字典序列
	func importCSV(from url: URL) throws -> [[String: String]] {
		let content = try String(contentsOf: url)
		var rows: [[String: String]] = []
		let lines = content.split(whereSeparator: \.isNewline).map { String($0) }
		guard lines.count > 1 else { return [] }
		let headers = lines[0].split(separator: ",").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }
		for line in lines.dropFirst() {
			let cols = line.split(separator: ",").map { String($0).trimmingCharacters(in: .whitespacesAndNewlines) }
			var dict: [String: String] = [:]
			for (idx, header) in headers.enumerated() {
				dict[header] = idx < cols.count ? cols[idx] : ""
			}
			rows.append(dict)
		}
		return rows
	}

	/// 匯入 JSON array of objects
	func importJSON(from url: URL) throws -> [[String: Any]] {
		let data = try Data(contentsOf: url)
		let obj = try JSONSerialization.jsonObject(with: data, options: [])
		guard let arr = obj as? [[String: Any]] else { throw ImportError.invalidFormat }
		return arr
	}

	/// 嘗試從 App Group 目錄讀取文件（若已設定）
	func importFromAppGroup(filename: String) throws -> URL? {
		guard let group = appGroupID else { return nil }
		let fm = FileManager.default
		guard let containerURL = fm.containerURL(forSecurityApplicationGroupIdentifier: group) else { return nil }
		let fileURL = containerURL.appendingPathComponent(filename)
		guard fm.fileExists(atPath: fileURL.path) else { return nil }
		return fileURL
	}
}

enum ImportError: Error {
	case invalidFormat
}
