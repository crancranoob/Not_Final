import Foundation

struct CorrectionCase: Codable, Identifiable {
    let id: String
    let date: Date
    let features: [Double]   // same order as AIModelCoordinator.features(from:)
    let student: Double
    let teacher: Double?
    let label: Double?       // if user provided or derived
    init(features: [Double], student: Double, teacher: Double? = nil, label: Double? = nil, date: Date = Date()) {
        self.id = UUID().uuidString
        self.date = date
        self.features = features
        self.student = student
        self.teacher = teacher
        self.label = label
    }
}

final class CorrectionBuffer {
    static let shared = CorrectionBuffer()
    private init() { load() }
    private var cases: [CorrectionCase] = []
    private var url: URL {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("correction_buffer.json")
    }
    private let maxCount = 1000

    func append(_ item: CorrectionCase) {
        cases.append(item)
        if cases.count > maxCount { cases.removeFirst(cases.count - maxCount) }
        save()
    }
    func all() -> [CorrectionCase] { cases }
    func clear() { cases.removeAll(); save() }
    private func save() { if let d = try? JSONEncoder().encode(cases) { try? d.write(to: url) } }
    private func load() {
        if let d = try? Data(contentsOf: url), let arr = try? JSONDecoder().decode([CorrectionCase].self, from: d) {
            cases = arr
        }
    }
}
