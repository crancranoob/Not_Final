import Foundation

/// Lightweight on-device CNN-LSTM implemented in Swift as a fallback when CoreML model isn't present.
/// Input: [epochs][channels][samples], e.g., epochs x 3 x 300 (30s @10Hz), channels: [ppg_like, rr_like, motion_mag]
/// Output: per-epoch stage class: 0=Wake,1=N1,2=N2,3=N3,4=REM
final class SleepStageNetCore {
    struct Weights: Codable {
        var conv1_w: [[[Double]]] // outC x inC x k
        var conv1_b: [Double]     // outC
        var lstm_wi: [[Double]]   // hidden x input_size
        var lstm_wf: [[Double]]
        var lstm_wo: [[Double]]
        var lstm_wc: [[Double]]
        var lstm_ui: [[Double]]   // hidden x hidden
        var lstm_uf: [[Double]]
        var lstm_uo: [[Double]]
        var lstm_uc: [[Double]]
        var lstm_bi: [Double]
        var lstm_bf: [Double]
        var lstm_bo: [Double]
        var lstm_bc: [Double]
        var fc_w: [[Double]]      // num_classes x hidden
        var fc_b: [Double]
    }
    var w: Weights

    init(random inputChannels: Int = 3, convOut: Int = 8, k: Int = 5, hidden: Int = 32, classes: Int = 5) {
        // Initialize small random weights; in practice, load trained weights from bundle JSON.
        func rand(_ n: Int) -> [Double] { (0..<n).map { _ in Double.random(in: -0.05...0.05) } }
        func r2(_ r: Int, _ c: Int) -> [[Double]] { (0..<r).map { _ in rand(c) } }
        func r3(_ a: Int, _ b: Int, _ c: Int) -> [[[Double]]] { (0..<a).map { _ in (0..<b).map { _ in rand(c) } } }
        w = Weights(
            conv1_w: r3(convOut, inputChannels, k),
            conv1_b: rand(convOut),
            lstm_wi: r2(hidden, convOut),
            lstm_wf: r2(hidden, convOut),
            lstm_wo: r2(hidden, convOut),
            lstm_wc: r2(hidden, convOut),
            lstm_ui: r2(hidden, hidden),
            lstm_uf: r2(hidden, hidden),
            lstm_uo: r2(hidden, hidden),
            lstm_uc: r2(hidden, hidden),
            lstm_bi: rand(hidden),
            lstm_bf: rand(hidden),
            lstm_bo: rand(hidden),
            lstm_bc: rand(hidden),
            fc_w: r2(classes, hidden),
            fc_b: rand(classes)
        )
    }

    // Simple 1D valid convolution
    private func conv1d(_ x: [[Double]], _ w: [[[Double]]], _ b: [Double]) -> [[Double]] {
        // x: inC x T, w: outC x inC x k, b: outC
        let inC = x.count, T = x[0].count, outC = w.count, k = w[0][0].count
        let outT = max(1, T - k + 1)
        var out = Array(repeating: Array(repeating: 0.0, count: outT), count: outC)
        for oc in 0..<outC {
            for t in 0..<outT {
                var s = b[oc]
                for ic in 0..<inC {
                    for kk in 0..<k { s += x[ic][t+kk] * w[oc][ic][kk] }
                }
                out[oc][t] = max(0, s) // ReLU
            }
        }
        return out
    }

    // Single-layer LSTM over time dimension (features = convOut)
    private func lstm(_ x: [[Double]]) -> [Double] {
        // x: feats x T
        let H = w.lstm_wi.count
        let T = x[0].count
        var h = Array(repeating: 0.0, count: H)
        var c = Array(repeating: 0.0, count: H)
        for t in 0..<T {
            // x_t vector
            let xt = x.map { $0[t] } // length feats = convOut
            var i = Array(repeating: 0.0, count: H)
            var f = Array(repeating: 0.0, count: H)
            var o = Array(repeating: 0.0, count: H)
            var g = Array(repeating: 0.0, count: H)
            for j in 0..<H {
                // input terms
                var xi=0.0, xf=0.0, xo=0.0, xg=0.0
                for k in 0..<xt.count {
                    xi += w.lstm_wi[j][k]*xt[k]
                    xf += w.lstm_wf[j][k]*xt[k]
                    xo += w.lstm_wo[j][k]*xt[k]
                    xg += w.lstm_wc[j][k]*xt[k]
                }
                // recurrent terms
                var hi=0.0, hf=0.0, ho=0.0, hg=0.0
                for k in 0..<H {
                    hi += w.lstm_ui[j][k]*h[k]
                    hf += w.lstm_uf[j][k]*h[k]
                    ho += w.lstm_uo[j][k]*h[k]
                    hg += w.lstm_uc[j][k]*h[k]
                }
                i[j] = 1.0/(1.0 + exp(-(xi+hi+w.lstm_bi[j])))
                f[j] = 1.0/(1.0 + exp(-(xf+hf+w.lstm_bf[j])))
                o[j] = 1.0/(1.0 + exp(-(xo+ho+w.lstm_bo[j])))
                g[j] = tanh(xg+hg+w.lstm_bc[j])
                c[j] = f[j]*c[j] + i[j]*g[j]
                h[j] = o[j]*tanh(c[j])
            }
        }
        return h
    }

    private func linear(_ h: [Double]) -> [Double] {
        var out = Array(repeating: 0.0, count: w.fc_w.count)
        for c in 0..<w.fc_w.count {
            var s = w.fc_b[c]
            for j in 0..<h.count { s += w.fc_w[c][j]*h[j] }
            out[c] = s
        }
        return out
    }

    private func argmax(_ v: [Double]) -> Int {
        var m = v[0], idx = 0
        for i in 1..<v.count { if v[i] > m { m = v[i]; idx = i } }
        return idx
    }

    func predictEpoch(_ epoch: [[Double]]) -> Int {
        // epoch: inC x T (e.g., 3 x 300)
        let conv = conv1d(epoch, w.conv1_w, w.conv1_b)
        let h = lstm(conv)
        let logits = linear(h)
        return argmax(logits)
    }

    func predict(epochs: [[[Double]]]) -> [Int] {
        return epochs.map { predictEpoch($0) }
    }
}
