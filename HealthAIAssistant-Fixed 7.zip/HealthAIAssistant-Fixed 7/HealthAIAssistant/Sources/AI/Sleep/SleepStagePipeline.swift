import Foundation

struct SleepStageSummary: Codable {
    let date: Date
    let stages: [Int]   // sequence per 30s epoch
    let stageDurations: [Int:Int] // stage -> seconds
    let efficiency: Double
}

final class SleepStagePipeline {
    static let shared = SleepStagePipeline()
    private init() {}

    // Build epochs from downsampled signals (already derived from HealthKit): HR, respiratory, motion magnitude
    // For demo, we synthesize epochs from daily aggregates if raw streams aren't available.
    func buildEpochsForLastNight(records: [DailyRecord]) -> [[[Double]]]? {
        guard let last = records.last else { return nil }
        // Create 6h of epochs (720 epochs), simple synthetic waveforms around HR/resp baselines
        let epochs = 6*60*2
        let T = 300 // 30s @10Hz
        let inC = 3
        var out: [[[Double]]] = []
        for e in 0..<epochs {
            var epoch = Array(repeating: Array(repeating: 0.0, count: T), count: inC)
            for t in 0..<T {
                let tt = Double(e*T + t)
                epoch[0][t] = 0.5 * sin(tt/45.0) + Double.random(in: -0.05...0.05) // ppg-like
                epoch[1][t] = 0.3 * sin(tt/120.0) + Double.random(in: -0.03...0.03) // rr-like
                epoch[2][t] = Double.random(in: 0...0.1) // motion magnitude
            }
            out.append(epoch)
        }
        return out
    }

    func summarize(stages: [Int], date: Date) -> SleepStageSummary {
        var dur: [Int:Int] = [:]
        for s in stages { dur[s, default:0] += 30 }
        let asleep = dur[1, default:0] + dur[2, default:0] + dur[3, default:0] + dur[4, default:0]
        let total = stages.count * 30
        let eff = total == 0 ? 0.0 : Double(asleep) / Double(total)
        return SleepStageSummary(date: date, stages: stages, stageDurations: dur, efficiency: eff)
    }
}
