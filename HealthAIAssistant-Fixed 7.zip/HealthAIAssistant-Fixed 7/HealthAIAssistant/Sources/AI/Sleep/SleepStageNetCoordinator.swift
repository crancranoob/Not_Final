import Foundation
import CoreML

final class SleepStageNetCoordinator {
    static let shared = SleepStageNetCoordinator()
    private init() { load() }

    private var modelMain: MLModel? = nil
    private var modelCandidate: MLModel? = nil

    private func load() {
        // Load bundle main model if present
        if let url = Bundle.main.url(forResource: "SleepStageNet", withExtension: "mlmodelc") {
            modelMain = try? MLModel(contentsOf: url)
        }
        // Load candidate from Documents/Models if present
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let candURL = docs.appendingPathComponent("Models").appendingPathComponent("SleepStageNet_candidate.mlmodelc")
        if FileManager.default.fileExists(atPath: candURL.path) {
            modelCandidate = try? MLModel(contentsOf: candURL)
        }
        // Register active variant
        registerActive()
    }

    private func registerActive() {
        let v = ActiveModelStore.shared.sleepVariant
        if v == .coreml {
            let sig = ModelSignature(name: "SleepStageNet", version: "1.0.0-coreml", task: "sleep_staging",
                                     input: "[epochs,3,300] float32", output: "[epochs] int (5 classes)")
            ModelRegistry.shared.register(model: "sleep_staging", version: sig.version, signature: sig)
        } else if v == .coreml_candidate {
            let sig = ModelSignature(name: "SleepStageNetCand", version: "1.0.0-coreml-cand", task: "sleep_staging",
                                     input: "[epochs,3,300] float32", output: "[epochs] int (5 classes)")
            ModelRegistry.shared.register(model: "sleep_staging", version: sig.version, signature: sig)
        } else {
            let sig = ModelSignature(name: "SleepStageNetCore", version: "0.1.0-swift", task: "sleep_staging",
                                     input: "[epochs,3,300] float32", output: "[epochs] int (5 classes)")
            ModelRegistry.shared.register(model: "sleep_staging", version: sig.version, signature: sig)
        }
    }

    func variantsAvailable() -> [SleepModelVariant] {
        var out: [SleepModelVariant] = [.swift]
        if modelMain != nil { out.append(.coreml) }
        if modelCandidate != nil { out.append(.coreml_candidate) }
        return out
    }

    // Convenience: predict a whole night of epochs with the active variant
    func predictStages(epochs: [[[Double]]]) -> [Int]? {
        return predictStages(using: ActiveModelStore.shared.sleepVariant, epochs: epochs)
    }

    func predictStages(using variant: SleepModelVariant, epochs: [[[Double]]]) -> [Int]? {
        switch variant {
        case .coreml:
            // TODO: map epochs to MLMultiArray and use modelMain
            // For now, use Swift fallback so the app runs even without a compiled Core ML.
            return SleepStageNetCore().predict(epochs: epochs)
        case .coreml_candidate:
            // TODO: map epochs to MLMultiArray and use modelCandidate
            return SleepStageNetCore().predict(epochs: epochs)
        case .swift:
            return SleepStageNetCore().predict(epochs: epochs)
        }
    }
}
