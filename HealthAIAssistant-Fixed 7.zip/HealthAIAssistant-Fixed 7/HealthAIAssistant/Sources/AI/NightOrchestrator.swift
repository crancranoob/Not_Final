import Foundation

final class NightOrchestrator {
    static let shared = NightOrchestrator()

    func runAll(records: [DailyRecord], coordinator: AIModelCoordinator) {
        trainExperts(records: records, coordinator: coordinator)
        trainMeta(records: records, coordinator: coordinator)
        fitCalibrators(records: records, coordinator: coordinator)
        _ = TeacherAnalyzer.shared.analyze(records: records, coordinator: coordinator)
        BaselineCalibrator.shared.update(with: records)
        let _ = SensitivityEngine.shared.analyze(records: records)
        // If a candidate model is available, A/B test and gate promotion
        let _ = /* AB test moved to UpgradeOrchestrator */
        NotificationManager.shared.notify(title: "夜間協作完成", body: "專家、組合器、校準器、敏感度分析已更新。")
    }

    private func teacherPred(seq: [[Double]], coord: AIModelCoordinator) -> Double {
        let attn = coord.loadAttentive(dIn: 9)
        let reg = coord.loadOnlineModel(featureCount: 9 + attn.dModel)
        let last = seq.last ?? []
        let emb = attn.forward(seq)
        return reg.predict(last + emb)
    }

    private func trainExperts(records: [DailyRecord], coordinator: AIModelCoordinator, epochs: Int = 3, lr: Double = 1e-3) {
        let tr = Trainer.shared
        let seqs = tr.sequences(from: records)
        guard !seqs.isEmpty else { return }
        let ex = ExpertsCoordinator.shared
        for _ in 0..<epochs {
            for (seq, _) in seqs.shuffled() {
                let last = seq.last ?? []
                let hd = coordinator.dataFromVector(last)
                let target = teacherPred(seq: seq, coord: coordinator)
                var r = ex.recovery; r.update(x: ex.features(for: .recovery, from: hd), yTrue: target, lr: lr); ex.recovery = r
                var a = ex.activity; a.update(x: ex.features(for: .activity, from: hd), yTrue: target, lr: lr); ex.activity = a
                var p = ex.respiratory; p.update(x: ex.features(for: .respiratory, from: hd), yTrue: target, lr: lr); ex.respiratory = p
            }
        }
        ex.save(.recovery); ex.save(.activity); ex.save(.respiratory)
    }

    private func trainMeta(records: [DailyRecord], coordinator: AIModelCoordinator, epochs: Int = 5, lr: Double = 1e-3, alpha: Double = 0.7) {
        let tr = Trainer.shared
        let seqs = tr.sequences(from: records)
        guard !seqs.isEmpty else { return }
        var meta = MetaCombinerCoordinator.shared.model
        for _ in 0..<epochs {
            for (seq, y) in seqs.shuffled() {
                let last = seq.last ?? []
                let hd = coordinator.dataFromVector(last)
                let teacher = teacherPred(seq: seq, coord: coordinator)
                let target = alpha * teacher + (1-alpha) * y
                let ex = ExpertsCoordinator.shared.predictAll(from: hd)
                let sleepQ = SleepModelCoordinator.shared.sleepQualityScore()/20.0
                let sleepPart = max(1.0, min(5.0, sleepQ))
                meta.update(x: [ex.rec, ex.act, ex.resp, sleepPart], y: target, lr: lr)
            }
        }
        MetaCombinerCoordinator.shared.model = meta
        MetaCombinerCoordinator.shared.save()
    }

    private func fitCalibrators(records: [DailyRecord], coordinator: AIModelCoordinator) {
        let tr = Trainer.shared
        let seqs = tr.sequences(from: records)
        guard seqs.count >= 10 else { return }
        let holdout = Array(seqs.suffix(max(1, seqs.count/5)))
        var teacherPairs: [(Double, Double)] = []
        var studentPairs: [(Double, Double)] = []
        var sleepPairs: [(Double, Double)] = []
        var metaPairs: [(Double, Double)] = []
        for (seq, y) in holdout {
            teacherPairs.append((teacherPred(seq: seq, coord: coordinator), y))
            let x = seq.last ?? []
            let (m, _) = StudentModelCoordinator.shared.predict(x: x)
            studentPairs.append((m, y))
            let f = SleepFeatureExtractor.shared.lastNightFeatures().asVector()
            let sq = SleepModelCoordinator.shared.model.forward(f)/20.0
            sleepPairs.append((sq, y))
            let hd = coordinator.dataFromVector(x)
            let ex = ExpertsCoordinator.shared.predictAll(from: hd)
            let sleepQ = SleepModelCoordinator.shared.sleepQualityScore()/20.0
            let sleepPart = max(1.0, min(5.0, sleepQ))
            let raw = MetaCombinerCoordinator.shared.model.forward([ex.rec, ex.act, ex.resp, sleepPart])
            metaPairs.append((raw, y))
        }
        let tCal = CalibratorTrainer.shared.fit(pairs: teacherPairs.map{ (raw: $0.0, y: $0.1) })
        CalibrationStore.shared.set(.teacher, tCal)
        let sCal = CalibratorTrainer.shared.fit(pairs: studentPairs.map{ (raw: $0.0, y: $0.1) })
        CalibrationStore.shared.set(.student, sCal)
        let slCal = CalibratorTrainer.shared.fit(pairs: sleepPairs.map{ (raw: $0.0, y: $0.1) })
        CalibrationStore.shared.set(.sleep, slCal)
        let mCal = CalibratorTrainer.shared.fit(pairs: metaPairs.map{ (raw: $0.0, y: $0.1) })
        CalibrationStore.shared.set(.meta, mCal)
    }
}
