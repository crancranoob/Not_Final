import CoreML
import Foundation

/// 提供同步特徵擷取與同步/非同步預測介面
final class PredictionEngine {
    private let model: MLModel?
    private let featureExtractor = AdvancedFeatureExtractor()

    init(model: MLModel? = nil) {
        self.model = model
    }

    // 同步預測（若 model 缺失，使用簡單規則回退）
    func predictSync(_ data: HealthData) throws -> PredictionResult {
        guard let model = model else {
            let score = min(1.0, max(0.0, data.heartRate / 100.0))
            return PredictionResult(riskScore: score, timestamp: Date())
        }
        let features = featureExtractor.extract(from: data)
        let output = try model.prediction(from: features)
        let risk = output.featureValue(for: "risk_score")?.doubleValue ?? 0.0
        return PredictionResult(riskScore: risk, timestamp: Date())
    }

    // async wrapper
    func predict(_ data: HealthData) async throws -> PredictionResult {
        return try predictSync(data)
    }
}

// 同步特徵擷取（保證在 iOS 推論路徑可用）
class AdvancedFeatureExtractor {
    func extract(from data: HealthData) -> MLFeatureProvider {
        return try! MLDictionaryFeatureProvider(dictionary: [
            "heart_rate": data.heartRate,
            "steps": Double(data.steps),
            "oxygen_saturation": data.oxygenSaturation,
            "body_temperature": data.bodyTemperature
        ])
    }
}
