import Foundation
import PDFKit
import UIKit
import SwiftUI

final class DoctorModeExporter {
    static let shared = DoctorModeExporter()
    private init() {}

    func exportWeekly(report: EvalReport?, insights: [String], to url: URL) {
        let pdf = PDFDocument()
        if let img = renderCover() { pdf.insert(PDFPage(image: img)!, at: 0) }
        if let img = renderMetrics(report) { pdf.insert(PDFPage(image: img)!, at: pdf.pageCount) }
        if let img = renderInsights(insights) { pdf.insert(PDFPage(image: img)!, at: pdf.pageCount) }
        pdf.write(to: url)
    }
    private func renderCover() -> UIImage? {
        let w: CGFloat = 1200, h: CGFloat = 800
        UIGraphicsBeginImageContextWithOptions(CGSize(width: w, height: h), true, 2)
        UIColor.white.setFill(); UIBezierPath(rect: CGRect(x:0,y:0,width:w,height:h)).fill()
        ("Health AI — 醫師模式摘要" as NSString).draw(at: CGPoint(x: 40, y: 40), withAttributes: [.font: UIFont.boldSystemFont(ofSize: 30)])
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img
    }
    private func renderMetrics(_ r: EvalReport?) -> UIImage? {
        guard let r else { return nil }
        let w: CGFloat = 1200, h: CGFloat = 1000
        UIGraphicsBeginImageContextWithOptions(CGSize(width: w, height: h), true, 2)
        UIColor.white.setFill(); UIBezierPath(rect: CGRect(x:0,y:0,width:w,height:h)).fill()
        var y: CGFloat = 40
        func line(_ s: String) { (s as NSString).draw(at: CGPoint(x: 40, y: y), withAttributes: [.font: UIFont.systemFont(ofSize: 18)]); y += 28 }
        line("模型: \(r.model_version)  資料集: \(r.dataset)  n=\(r.n)")
        if let s = r.sleep { line("睡眠分期 Acc=\(String(format:"%.2f", s.overall_accuracy))  κ=\(String(format:"%.2f", s.cohens_kappa))  REM F1=\(String(format:"%.2f", s.per_stage_f1["REM"] ?? 0))") }
        if let h = r.hr { line("心率 MAE=\(String(format:"%.2f", h.MAE_bpm)) bpm  r=\(String(format:"%.2f", h.pearson_r))") }
        if let v = r.hrv { line("HRV MAE=\(String(format:"%.1f", v.MAE_ms)) ms  r=\(String(format:"%.2f", v.pearson_r))") }
        if let s2 = r.spo2 { line("血氧 MAE=\(String(format:"%.2f", s2.MAE_pct))%  ±2% 覆蓋=\(String(format:"%.2f", s2.pct_within_2pct))") }
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img
    }
    private func renderInsights(_ items: [String]) -> UIImage? {
        let w: CGFloat = 1200, h: CGFloat = 1000
        UIGraphicsBeginImageContextWithOptions(CGSize(width: w, height: h), true, 2)
        UIColor.white.setFill(); UIBezierPath(rect: CGRect(x:0,y:0,width:w,height:h)).fill()
        var y: CGFloat = 40
        ("洞見與因果圖" as NSString).draw(at: CGPoint(x: 40, y: y), withAttributes: [.font: UIFont.boldSystemFont(ofSize: 24)]); y+=40
        for s in items {
            (("• "+s) as NSString).draw(at: CGPoint(x: 40, y: y), withAttributes: [.font: UIFont.systemFont(ofSize: 18)]); y += 28
        }
        let img = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return img
    }
}
