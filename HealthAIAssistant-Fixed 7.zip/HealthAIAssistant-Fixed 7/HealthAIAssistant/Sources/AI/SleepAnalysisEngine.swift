import Foundation
import HealthKit

enum SleepStage: Int {
    case inBed = 0
    case asleep = 1
    case awake = 2
    case rem = 3
    case deep = 4
    case light = 5
    case unknown = -1
}

struct SleepStageInterval {
    let start: Date
    let end: Date
    let stage: SleepStage
}

struct SleepAnalysisResult {
    let date: Date
    let totalHours: Double
    let sleepEfficiency: Double
    let sleepLatency: Double
    let wakeCount: Int
    let remRatio: Double
    let deepRatio: Double
    let lightRatio: Double
    let score: Double
    let stageTimeline: [SleepStageInterval]
}

final class SleepAnalysisEngine {
    private let healthStore = HKHealthStore()
    
    /// 取得並分析 Apple HealthKit 的睡眠資料，計算專業指標
    func analyzeSleep(for date: Date) async throws -> SleepAnalysisResult {
        let samples = try await fetchAppleSleepSamples(for: date)
        let intervals = samples.map { SleepStageInterval(start: $0.startDate, end: $0.endDate, stage: SleepStage(rawValue: $0.value) ?? .unknown) }
        
        // 計算總時長
        let totalDuration = intervals.reduce(0.0) { $0 + $1.end.timeIntervalSince($1.start) }
        let totalHours = totalDuration / 3600.0
        
        // 計算各階段時長
        let asleepIntervals = intervals.filter { $0.stage == .asleep || $0.stage == .rem || $0.stage == .deep || $0.stage == .light }
        let asleepDuration = asleepIntervals.reduce(0.0) { $0 + $1.end.timeIntervalSince($1.start) }
        let remDuration = intervals.filter { $0.stage == .rem }.reduce(0.0) { $0 + $1.end.timeIntervalSince($1.start) }
        let deepDuration = intervals.filter { $0.stage == .deep }.reduce(0.0) { $0 + $1.end.timeIntervalSince($1.start) }
        let lightDuration = intervals.filter { $0.stage == .light }.reduce(0.0) { $0 + $1.end.timeIntervalSince($1.start) }
        
        // 覺醒次數
        let wakeCount = intervals.filter { $0.stage == .awake }.count
        
        // 睡眠效率 = 睡眠時長 / 臥床時長
        let inBedDuration = intervals.filter { $0.stage == .inBed || $0.stage == .asleep || $0.stage == .rem || $0.stage == .deep || $0.stage == .light }.reduce(0.0) { $0 + $1.end.timeIntervalSince($1.start) }
        let sleepEfficiency = inBedDuration > 0 ? asleepDuration / inBedDuration * 100 : 0
        
        // 睡眠潛伏期（臥床到第一次入睡的時間）
        let firstInBed = intervals.first(where: { $0.stage == .inBed })?.start
        let firstAsleep = intervals.first(where: { $0.stage == .asleep || $0.stage == .rem || $0.stage == .deep || $0.stage == .light })?.start
        let sleepLatency = (firstInBed != nil && firstAsleep != nil) ? max(0, firstAsleep!.timeIntervalSince(firstInBed!)) / 60.0 : 0
        
        // 各階段比例
        let remRatio = asleepDuration > 0 ? remDuration / asleepDuration : 0
        let deepRatio = asleepDuration > 0 ? deepDuration / asleepDuration : 0
        let lightRatio = asleepDuration > 0 ? lightDuration / asleepDuration : 0
        
        // 綜合睡眠分數（專業指標加權，可根據文獻調整）
        let score = min(100,
            sleepEfficiency * 0.4 +
            (totalHours / 8.0) * 30 +
            (1 - min(1, Double(wakeCount) / 5.0)) * 10 +
            remRatio * 10 +
            deepRatio * 10 -
            sleepLatency * 0.5
        )
        
        return SleepAnalysisResult(
            date: date,
            totalHours: totalHours,
            sleepEfficiency: sleepEfficiency,
            sleepLatency: sleepLatency,
            wakeCount: wakeCount,
            remRatio: remRatio,
            deepRatio: deepRatio,
            lightRatio: lightRatio,
            score: score,
            stageTimeline: intervals
        )
    }
    
    /// 從 HealthKit 取得睡眠樣本
    private func fetchAppleSleepSamples(for date: Date) async throws -> [HKCategorySample] {
        let type = HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!
        let start = Calendar.current.startOfDay(for: date)
        let end = Calendar.current.date(byAdding: .day, value: 1, to: start)!
        let predicate = HKQuery.predicateForSamples(withStart: start, end: end)
        
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, results, error in
                if let error = error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume(returning: (results as? [HKCategorySample]) ?? [])
                }
            }
            healthStore.execute(query)
        }
    }
    
    /// 與外部應用結果比較並自我優化（可擴展為聯邦學習/增量學習）
    func compareAndLearn(from externalResult: SleepAnalysisResult, for date: Date) async throws -> String {
        let ourResult = try await analyzeSleep(for: date)
        let diff = abs(ourResult.score - externalResult.score)
        // 可根據差異自動調整模型參數或提示用戶
        if diff < 5 {
            return "與外部應用結果高度一致"
        } else if ourResult.score > externalResult.score {
            return "本系統評分較高，建議檢查外部應用設定"
        } else {
            return "外部應用評分較高，建議檢查本系統數據來源"
        }
    }
}

extension SleepAnalysisEngine {
    /// 聯邦學習聚合分析（自動同步外部應用）
    func federatedSleepAnalysis(for date: Date) async throws -> SleepAnalysisResult {
        let federatedManager = SleepFederatedLearningManager()
        return try await federatedManager.federatedSleepLearning(for: date)
    }
}

class SleepFeatureExtractor {
    func extract(from samples: [SleepSample]) -> MLFeatureProvider {
        // 專業特徵工程：總睡眠時長、各階段比例、入睡時間、醒來次數等
        let totalDuration = samples.reduce(0.0) { $0 + $1.endDate.timeIntervalSince($1.startDate) }
        let asleepDuration = samples.filter { $0.stage == .asleep || $0.stage == .rem || $0.stage == .deep || $0.stage == .light }
            .reduce(0.0) { $0 + $1.endDate.timeIntervalSince($1.startDate) }
        let awakeCount = samples.filter { $0.stage == .awake }.count
        let remDuration = samples.filter { $0.stage == .rem }.reduce(0.0) { $0 + $1.endDate.timeIntervalSince($1.startDate) }
        let deepDuration = samples.filter { $0.stage == .deep }.reduce(0.0) { $0 + $1.endDate.timeIntervalSince($1.startDate) }
        let lightDuration = samples.filter { $0.stage == .light }.reduce(0.0) { $0 + $1.endDate.timeIntervalSince($1.startDate) }
        
        return try! MLDictionaryFeatureProvider(dictionary: [
            "total_duration": totalDuration,
            "asleep_duration": asleepDuration,
            "awake_count": Double(awakeCount),
            "rem_duration": remDuration,
            "deep_duration": deepDuration,
            "light_duration": lightDuration
        ])
    }
}

class SleepComparisonEngine {
    func compare(_ ours: SleepAnalysisResult, _ external: SleepAnalysisResult) -> SleepComparisonResult {
        let scoreDiff = ours.score - external.score
        let stageDiff = zip(ours.stages, external.stages).filter { $0 != $1 }.count
        return SleepComparisonResult(scoreDifference: scoreDiff, stageDifference: stageDiff)
    }
}

struct SleepComparisonResult {
    let scoreDifference: Double
    let stageDifference: Int
}

// 輔助：將 MLMultiArray 轉為 SleepStage 陣列
extension MLMultiArray {
    func toSleepStages() -> [SleepStage] {
        return (0..<self.count).compactMap { idx in
            SleepStage(rawValue: self[idx].intValue)
        }
    }
}
