import Foundation

struct NightFeatures {
    let date: Date
    let duration: Double
    let efficiency: Double
    let remPct: Double
    let deepPct: Double
    let awakenings: Double
    let meanHR: Double
    let meanHRV: Double
    let meanRR: Double
    // Add more as needed
    func asVector() -> [Double] {
        [duration/36000.0, efficiency, remPct, deepPct, awakenings/10.0, meanHR/200.0, meanHRV/200.0, meanRR/30.0]
    }
}

final class SleepFeatureExtractor {
    static let shared = SleepFeatureExtractor()

    func lastNightFeatures() -> NightFeatures {
        var m = SleepStageMetrics()
        let group = DispatchGroup()
        group.enter()
        SleepStagesManager.shared.fetchLastNight { mm in
            m = mm
            group.leave()
        }
        group.wait()
        // crude stats from HealthData snapshot (last values)
        let d = HealthKitManager.shared.healthData
        return NightFeatures(date: Date(),
                             duration: m.total,
                             efficiency: m.efficiency,
                             remPct: m.remPct,
                             deepPct: m.deepPct,
                             awakenings: Double(m.awakenings),
                             meanHR: d.heartRate,
                             meanHRV: d.hrvSDNN,
                             meanRR: d.respiratoryRate)
    }
}
