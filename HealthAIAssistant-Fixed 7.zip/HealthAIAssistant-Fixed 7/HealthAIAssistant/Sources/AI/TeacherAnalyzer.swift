import Foundation

struct TeacherAnalytics: Codable {
    let date: Date
    let featureMeans: [String: Double]
    let featureStds: [String: Double]
    let correlations: [String: Double]  // feature->target Pearson (approx)
    let driftZ: [String: Double]
    let notes: String
}

final class TeacherAnalyzer {
    static let shared = TeacherAnalyzer()
    private init() {}

    func analyze(records: [DailyRecord], coordinator: AIModelCoordinator) -> TeacherAnalytics {
        // Build XY from sequences (use last vector as x, teacher pred as y)
        let tr = Trainer.shared
        let seqs = tr.sequences(from: records)
        var X: [[Double]] = []; var Y: [Double] = []
        for (seq, _) in seqs {
            let x = seq.last ?? []; if x.count >= 9 {
                let attn = coordinator.loadAttentive(dIn: 9)
                let reg = coordinator.loadOnlineModel(featureCount: 9 + attn.dModel)
                let y = reg.predict(x + attn.forward(seq))
                X.append(x); Y.append(y)
            }
        }
        let names = ["HR","Steps","ActiveEnergy","Sleep","SpO2","Temp","Stability","HRV","Resp"]
        var means: [String:Double] = [:]; var stds: [String:Double] = [:]; var cors: [String:Double] = [:]
        guard !X.isEmpty else { return TeacherAnalytics(date: Date(), featureMeans: [:], featureStds: [:], correlations: [:], driftZ: [:], notes: "No data") }

        // Means/stds
        let n = X.count
        for j in 0..<min(9, X[0].count) {
            let col = X.map{ $0[j] }
            let mean = col.reduce(0,+)/Double(n)
            let var_ = col.reduce(0){ $0 + ($1-mean)*($1-mean) }/Double(n)
            means[names[j]] = mean; stds[names[j]] = (var_>0 ? var_**0.5 : 0)
            // Pearson corr with Y
            let yMean = Y.reduce(0,+)/Double(n)
            let yVar = Y.reduce(0){ $0 + ($1-yMean)*($1-yMean) }/Double(n)
            let cov = zip(col, Y).reduce(0){ $0 + ($1.0-mean)*($1.1-yMean) }/Double(n)
            let cor = (yVar>0 && var_>0) ? cov/((yVar**0.5)*(var_**0.5)) : 0
            cors[names[j]] = cor
        }
        // Drift Z vs rolling mean (use CSV store last 30 days)
        let recs = CSVDataManager.shared.records
        let last30 = Array(recs.suffix(30))
        var drift: [String:Double] = [:]
        if !last30.isEmpty {
            let cur = recs.last
            let mapping: [(String, (DailyRecord)->Double)] = [
                ("HR", { $0.heartRate }),
                ("Steps", { Double($0.steps) }),
                ("ActiveEnergy", { $0.activeEnergy }),
                ("Sleep", { $0.sleepHours }),
                ("SpO2", { $0.oxygenSaturation ?? 0.96 }),
                ("Temp", { $0.bodyTemperature ?? 36.5 }),
                ("Stability", { $0.walkingStability ?? 0 }),
                ("HRV", { $0.hrvSDNN ?? 40 }),
                ("Resp", { $0.respiratoryRate ?? 14 })
            ]
            for (k, f) in mapping {
                let arr = last30.map(f)
                let mu = arr.reduce(0,+)/Double(arr.count)
                let var_ = arr.reduce(0){ $0 + pow($1-mu,2) }/Double(arr.count)
                if let c = cur {
                    let z = (f(c) - mu)/max(1e-9, var_**0.5)
                    drift[k] = z
                }
            }
        }
        return TeacherAnalytics(date: Date(), featureMeans: means, featureStds: stds, correlations: cors, driftZ: drift, notes: "OK")
    }
}
