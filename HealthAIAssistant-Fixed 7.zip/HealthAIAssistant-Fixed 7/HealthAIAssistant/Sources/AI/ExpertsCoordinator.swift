import Foundation

struct ExpertMLP: Codable {
    var W1: [Double]; var b1: [Double]; var W2: [Double]; var b2: Double
    let dIn: Int; let dHid: Int
    init(dIn: Int, dHid: Int = 24) {
        self.dIn = dIn; self.dHid = dHid
        self.W1 = (0..<(dIn*dHid)).map { _ in Double.random(in: -0.02...0.02) }
        self.b1 = (0..<dHid).map { _ in 0.0 }
        self.W2 = (0..<dHid).map { _ in Double.random(in: -0.02...0.02) }
        self.b2 = 0.0
    }
    func forward(_ x: [Double]) -> Double {
        var h = [Double](repeating: 0, count: dHid)
        for i in 0..<dHid {
            var s = b1[i]
            for j in 0..<min(dIn, x.count) { s += W1[i*dIn + j] * x[j] }
            h[i] = max(0, s)
        }
        var y = b2
        for i in 0..<dHid { y += W2[i] * h[i] }
        let z = 1.0 / (1.0 + exp(-y))
        return 1.0 + 4.0 * z
    }
    mutating func update(x: [Double], yTrue: Double, lr: Double = 1e-3) {
        var h = [Double](repeating: 0, count: dHid)
        var pre = [Double](repeating: 0, count: dHid)
        for i in 0..<dHid {
            var s = b1[i]
            for j in 0..<min(dIn, x.count) { s += W1[i*dIn + j] * x[j] }
            pre[i] = s
            h[i] = max(0, s)
        }
        var y = b2; for i in 0..<dHid { y += W2[i] * h[i] }
        let yPred = 1.0 + 4.0 * (1.0 / (1.0 + exp(-y)))
        let gradOut = (yPred - yTrue)
        for i in 0..<dHid { W2[i] -= lr * gradOut * h[i] }
        b2 -= lr * gradOut
        var gradH = [Double](repeating: 0, count: dHid)
        for i in 0..<dHid { gradH[i] = gradOut * W2[i] * (pre[i] > 0 ? 1 : 0) }
        for i in 0..<dHid {
            b1[i] -= lr * gradH[i]
            for j in 0..<dIn { W1[i*dIn + j] -= lr * gradH[i] * (j < x.count ? x[j] : 0) }
        }
    }
}

enum ExpertType: String, Codable { case recovery, activity, respiratory }

final class ExpertsCoordinator: ObservableObject {
    static let shared = ExpertsCoordinator()
    private let baseURL: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("experts")
    }()
    // Recovery now uses hydration + caffeineLate -> dIn = 6
    @Published var recovery = ExpertMLP(dIn: 6)
    @Published var activity = ExpertMLP(dIn: 2)
    @Published var respiratory = ExpertMLP(dIn: 2)

    init() { loadAll() }
    private func path(_ t: ExpertType) -> URL { baseURL.appendingPathComponent("\(t.rawValue).json") }
    func loadAll() { load(.recovery); load(.activity); load(.respiratory) }
    func load(_ t: ExpertType) {
        let u = path(t); guard let d = try? Data(contentsOf: u) else { return }
        if t == .recovery, let m = try? JSONDecoder().decode(ExpertMLP.self, from: d) { recovery = m }
        if t == .activity, let m = try? JSONDecoder().decode(ExpertMLP.self, from: d) { activity = m }
        if t == .respiratory, let m = try? JSONDecoder().decode(ExpertMLP.self, from: d) { respiratory = m }
    }
    func save(_ t: ExpertType) {
        try? FileManager.default.createDirectory(at: baseURL, withIntermediateDirectories: true)
        let u = path(t)
        let d: Data? = (t == .recovery ? try? JSONEncoder().encode(recovery) :
                         t == .activity ? try? JSONEncoder().encode(activity) :
                         try? JSONEncoder().encode(respiratory))
        if let d = d { try? d.write(to: u) }
    }
    func features(for t: ExpertType, from d: HealthData) -> [Double] {
        let ctx = ContextStore.shared.get(Date())
        switch t {
        case .recovery:
            return [
                d.heartRate/200.0,
                d.hrvSDNN/200.0,
                d.sleepHours/12.0,
                d.bodyTemperature/45.0,
                (ctx?.hydrationLiters ?? 0)/3.0,
                (ctx?.caffeineMgLate ?? 0)/400.0
            ]
        case .activity:
            return [Double(d.steps)/20000.0, d.activeEnergy/2000.0]
        case .respiratory:
            return [d.respiratoryRate/30.0, d.oxygenSaturation]
        }
    }
    func predictAll(from d: HealthData) -> (rec: Double, act: Double, resp: Double) {
        let r = recovery.forward(features(for: .recovery, from: d))
        let a = activity.forward(features(for: .activity, from: d))
        let p = respiratory.forward(features(for: .respiratory, from: d))
        return (r, a, p)
    }
}
