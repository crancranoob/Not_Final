import Foundation

struct RiskAlert { let title: String; let body: String }

final class RiskEngine {
    static let shared = RiskEngine()

    // Tunables
    var ewmaAlpha: Double { SettingsStore.shared.ewmaAlpha }
    var hrHighZ: Double { SettingsStore.shared.hrHighZ }
    var hrvLowZ: Double { SettingsStore.shared.hrvLowZ }
    var tempHighZ: Double { SettingsStore.shared.tempHighZ }
    var spo2Low: Double { SettingsStore.shared.spo2Low }
    var respHighZ: Double { SettingsStore.shared.respHighZ }

    // Simple EWMA baselines stored in memory (persist if needed)
    private var baselines: [String: (mean: Double, var_: Double)] = [:]  // key->(mean,var)

    private func updateBaseline(key: String, value: Double) -> (z: Double, mean: Double, sd: Double) {
        guard value.isFinite else { return (0, 0, 1) }
        let epsilon = 1e-6
        let dow = Calendar.current.component(.weekday, from: Date())
        let key = key + "_d\(dow)"
        var (m, v) = baselines[key] ?? (value, 1.0)
        // EWMA update
        let a = ewmaAlpha
        let newM = a*value + (1-a)*m
        let newV = (1-a)*(v + a*pow(value - m, 2))
        baselines[key] = (newM, max(newV, epsilon))
        let sd = max(sqrt(newV), epsilon)
        let z = (value - newM) / sd
        return (z, newM, sd)
    }

    func evaluateAll(from d: HealthData) -> (summary: String, alerts: [RiskAlert]) {
        var alerts: [RiskAlert] = []
        var lines: [String] = []

        // Resting HR (approx: use daily hr); HRV SDNN; Temperature; SpO2; Resp
        let hr = d.heartRate
        let hrv = d.hrvSDNN
        let temp = d.bodyTemperature
        let spo2 = d.oxygenSaturation
        let rr = d.respiratoryRate

        let zHR = updateBaseline(key: "hr", value: hr).z
        let zHRV = updateBaseline(key: "hrv", value: hrv).z
        let zTemp = updateBaseline(key: "temp", value: temp).z
        let zRR = updateBaseline(key: "rr", value: rr).z

        // Illness/respiratory risk heuristic
        var illnessScore = 0.0
        if zTemp > tempHighZ { illnessScore += 1 }
        if zHR > hrHighZ { illnessScore += 1 }
        if zHRV < hrvLowZ { illnessScore += 1 }
        if spo2 > 0 && spo2 < spo2Low { illnessScore += 1 }
        if zRR > respHighZ { illnessScore += 1 }

        if illnessScore >= 3 {
            alerts.append(RiskAlert(title: "可能的生理負擔/感染風險", body: "體溫/心率/HRV/SpO₂/呼吸率出現不利組合（得分 \(illnessScore)）。請評估休息或尋求專業意見。"))
        }

        // Overtraining / recovery risk
        var recoveryScore = 0.0
        if zHRV < -1.5 { recoveryScore += 1 }
        if zHR > 1.5 { recoveryScore += 1 }
        if d.sleepHours < 6 { recoveryScore += 1 }
        if d.activeEnergy > 1500 { recoveryScore += 1 }
        if recoveryScore >= 3 {
            alerts.append(RiskAlert(title: "過度訓練/恢復風險", body: "HRV 降低、HR 升高、睡眠不足或過多負荷同時出現（得分 \(recoveryScore)）。建議降低訓練強度並早睡。"))
        }

        // Fall risk proxy
        if d.walkingStability > 0 && d.walkingStability < 0.2 {
            alerts.append(RiskAlert(title: "步態穩定度偏低", body: "步態穩定度低於 0.2，請留意跌倒風險。"))
        }

        lines.append(String(format: "z(HR)=%.2f, z(HRV)=%.2f, z(Temp)=%.2f, z(RR)=%.2f, SpO₂=%.2f", zHR, zHRV, zTemp, zRR, spo2))
        return (lines.joined(separator: " | "), alerts)
    }
}


extension RiskEngine {
    func evaluateSleep(metrics m: SleepStageMetrics) -> [RiskAlert] {
        var alerts: [RiskAlert] = []
        if m.deepPct < 0.10 { alerts.append(RiskAlert(title: "深眠比例偏低", body: "深眠 < 10%，可能恢復不足。")) }
        if m.remPct < 0.15 { alerts.append(RiskAlert(title: "REM 比例偏低", body: "REM < 15%，影響情緒與記憶整合。")) }
        if m.efficiency < 0.80 { alerts.append(RiskAlert(title: "睡眠效率偏低", body: "效率 < 80%，覺醒中斷較多。")) }
        if m.awakenings >= 5 { alerts.append(RiskAlert(title: "覺醒次數較多", body: "夜間覺醒 ≥ 5 次。")) }
        return alerts
    }
}
