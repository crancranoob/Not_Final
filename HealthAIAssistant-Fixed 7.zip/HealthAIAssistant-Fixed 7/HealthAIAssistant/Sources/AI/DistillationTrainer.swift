import Foundation

final class DistillationTrainer {
    static let shared = DistillationTrainer()

    /// At night: use teacher (attention+reg) to generate soft targets on training set; train student to mimic teacher while also fitting userScore when present.
    func distillAtNight(records: [DailyRecord], coordinator: AIModelCoordinator, alpha: Double = 0.7, epochs: Int = 5) {
        // Prepare sequences and features
        let trainer = Trainer.shared
        let seqs = trainer.sequences(from: records)
        guard !seqs.isEmpty else { return }
        let attn = coordinator.loadAttentive(dIn: 9)
        let reg = coordinator.loadOnlineModel(featureCount: 9 + attn.dModel)

        var student = StudentModelCoordinator.shared.ensemble
        for _ in 0..<epochs {
            for (seq, yTrue) in seqs.shuffled() {
                let last = seq.last ?? []
                let embed = attn.forward(seq)
                let teacherPred = reg.predict(last + embed) // 1..5 range
                let target = alpha * teacherPred + (1.0 - alpha) * yTrue
                // Update ensemble
                var sm = StudentModelCoordinator.shared.ensemble
                sm.update(x: last, y: target)
                StudentModelCoordinator.shared.ensemble = sm
            }
        }
        StudentModelCoordinator.shared.save()
        ModelRegistry.shared.record(slot: .student, semver: "1.0.\(Int(Date().timeIntervalSince1970))", notes: "Nightly distillation")
        NotificationManager.shared.notify(title: "學生模型蒸餾完成", body: "已以老師模型的軟標籤更新白天模型。")
    }
}
