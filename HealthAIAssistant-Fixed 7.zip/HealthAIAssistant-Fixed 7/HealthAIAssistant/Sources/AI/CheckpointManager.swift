import Foundation

struct TrainingCheckpoint: Codable {
    let date: Date
    let epoch: Int
    let batchIndex: Int
    let attn: AttentiveAggregator
    let reg: OnlineRegressor
}

final class CheckpointManager {
    static let shared = CheckpointManager()
    private init() {}

    private var url: URL {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("checkpoint.json")
    }

    func save(epoch: Int, batchIndex: Int, attn: AttentiveAggregator, reg: OnlineRegressor) {
        let ck = TrainingCheckpoint(date: Date(), epoch: epoch, batchIndex: batchIndex, attn: attn, reg: reg)
        if let data = try? JSONEncoder().encode(ck) {
            try? data.write(to: url)
        }
    }
    func load() -> TrainingCheckpoint? {
        guard let data = try? Data(contentsOf: url) else { return nil }
        return try? JSONDecoder().decode(TrainingCheckpoint.self, from: data)
    }
    func clear() {
        try? FileManager.default.removeItem(at: url)
    }
}
