import Foundation
import Accelerate

/// 簡化版「Transformer 式」加權彙總：
/// 使用可學習的 Wq, Wk, Wv（小尺寸矩陣），對最近 N 天特徵做 self-attention，產生 contextual embedding。
final class AttentiveAggregator: Codable {
    var dIn: Int
    var dModel: Int
    var Wq: [Double] // dIn x dModel
    var Wk: [Double] // dIn x dModel
    var Wv: [Double] // dIn x dModel

    var lr: Double

    init(dIn: Int, dModel: Int = 16, lr: Double = 0.001) {
        self.dIn = dIn
        self.dModel = dModel
        self.lr = lr
        self.Wq = (0..<(dIn*dModel)).map { _ in Double.random(in: -0.01...0.01) }
        self.Wk = (0..<(dIn*dModel)).map { _ in Double.random(in: -0.01...0.01) }
        self.Wv = (0..<(dIn*dModel)).map { _ in Double.random(in: -0.01...0.01) }
    }

    // x: [T][dIn] -> embedding: [dModel]
    func forward(_ x: [[Double]]) -> [Double] {
        let T = x.count
        guard T > 0 else { return Array(repeating: 0, count: dModel) }
        // Compute queries/keys/values for each time step
        var Q = [[Double]](), K = [[Double]](), V = [[Double]]()
        Q.reserveCapacity(T); K.reserveCapacity(T); V.reserveCapacity(T)
        for t in 0..<T {
            Q.append(matVec(Wq, dIn: dIn, dOut: dModel, x: x[t]))
            K.append(matVec(Wk, dIn: dIn, dOut: dModel, x: x[t]))
            V.append(matVec(Wv, dIn: dIn, dOut: dModel, x: x[t]))
        }
        // Attention weights: softmax(q_t · k_j / sqrt(dModel))
        let scale = 1.0 / sqrt(Double(dModel))
        var weighted = [Double](repeating: 0, count: dModel)
        for t in 0..<T {
            var scores = [Double](repeating: 0, count: T)
            for j in 0..<T {
                scores[j] = dot(Q[t], K[j]) * scale
            }
            let attn = softmax(scores)
            // context_t = Σ_j attn_j * V_j
            var context = [Double](repeating: 0, count: dModel)
            for j in 0..<T {
                vDSP.add(context, vDSP.multiply(attn[j], V[j]), result: &context)
            }
            // aggregate all t (mean)
            vDSP.add(weighted, context, result: &weighted)
        }
        var out = [Double](repeating: 0, count: dModel)
        vDSP.divide(weighted, Double(T), result: &out)
        return out
    }

    // 簡化的單步更新：以上層損失對 out 的梯度來近似更新（示意）
    func update(x: [[Double]], gradOut: [Double]) {
        // 這裡為示意：實作完整反傳過程非常冗長，採用小步近似（將 grad 分散回 Wv）。
        let T = x.count
        guard T > 0 else { return }
        for t in 0..<T {
            // 只更新 Wv：Wv += -lr * x[t] ⊗ gradOut
            outerUpdate(&Wv, dIn: dIn, dOut: dModel, x: x[t], g: gradOut, lr: lr / Double(T))
        }
    }

    private func matVec(_ W: [Double], dIn: Int, dOut: Int, x: [Double]) -> [Double] {
        precondition(W.count == dIn * dOut && x.count == dIn)
        var y = [Double](repeating: 0, count: dOut)
        // y = W^T x
        for o in 0..<dOut {
            var sum = 0.0
            for i in 0..<dIn {
                sum += W[o*dIn + i] * x[i]
            }
            y[o] = sum
        }
        return y
    }
    private func dot(_ a: [Double], _ b: [Double]) -> Double {
        var r = 0.0
        vDSP_dotD(a, 1, b, 1, &r, vDSP_Length(a.count))
        return r
    }
    private func softmax(_ x: [Double]) -> [Double] {
        let m = x.max() ?? 0
        var e = x.map { exp($0 - m) }
        var sum = 0.0
        vDSP_sveD(&e, 1, &sum, vDSP_Length(e.count))
        return e.map { $0 / max(sum, 1e-8) }
    }
    private func outerUpdate(_ W: inout [Double], dIn: Int, dOut: Int, x: [Double], g: [Double], lr: Double) {
        for o in 0..<dOut {
            for i in 0..<dIn {
                W[o*dIn + i] -= lr * x[i] * g[o]
            }
        }
    }
}
