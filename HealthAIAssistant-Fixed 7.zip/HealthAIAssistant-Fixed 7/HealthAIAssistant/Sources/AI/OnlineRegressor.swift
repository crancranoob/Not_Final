import Foundation
import Accelerate

/// 簡易線性回歸的線上學習器（SGD），輸入特徵 x，目標 y（例如每日自評 1~5）
final class OnlineRegressor: Codable {
    var weights: [Double]
    var bias: Double
    var learningRate: Double

    init(featureCount: Int, learningRate: Double = 0.01) {
        self.weights = Array(repeating: 0, count: featureCount)
        self.bias = 0
        self.learningRate = learningRate
    }

    func predict(_ x: [Double]) -> Double {
        var y = bias
        vDSP_dotD(x, 1, weights, 1, &y, vDSP_Length(x.count))
        return y
    }

    func update(x: [Double], yTrue: Double) {
        let yPred = predict(x)
        let error = yPred - yTrue
        // w := w - lr * error * x
        var lrErr = learningRate * error
        var w = weights
        var xneg = x.map { lrErr * $0 }
        vDSP.subtract(w, xneg, result: &w)
        weights = w
        bias -= learningRate * error
    }
}
