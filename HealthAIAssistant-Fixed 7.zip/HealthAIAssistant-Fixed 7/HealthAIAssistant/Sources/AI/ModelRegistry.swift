import Foundation

struct ModelSignature: Codable, Equatable { let name: String; let version: String; let task: String; let input: String; let output: String }
final class ModelRegistry {
    static let shared = ModelRegistry()
    private init() {}
    private var models: [String: ModelSignature] = [:] // task -> sig
    func register(model: String, version: String, signature: ModelSignature) {
        models[model] = signature
        persist()
    }
    func signature(for key: String) -> ModelSignature? { models[key] }
    func currentVersionSummary() -> String {
        models.values.map { "\($0.name)@\($0.version)" }.sorted().joined(separator: ", ")
    }
    private func persist() {
        let url = Self.fileURL
        if let data = try? JSONEncoder().encode(models) { try? data.write(to: url) }
    }
    static var fileURL: URL {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("model_registry.json")
    }
}

// Grey rollout with A/B compare; upgrade only if ΔMAE<=0 and no major regressions.
final class DynamicModelManager {
    static let shared = DynamicModelManager()
    private init() {}

    enum Decision { case keepOld, upgrade }

    func decideUpgrade(old: EvalReport, new: EvalReport, gates: Gates = Gates()) -> Decision {
        var ok = true
        if let o = old.sleep, let n = new.sleep, (n.cohens_kappa + 1e-6) < (o.cohens_kappa - gates.allowedKappaDrop) { ok = false }
        if let o = old.hr, let n = new.hr, (n.MAE_bpm - o.MAE_bpm) > gates.allowedMAEIncrease { ok = false }
        if let o = old.hrv, let n = new.hrv, (n.MAE_ms - o.MAE_ms) > gates.allowedMAEIncreaseHRV { ok = false }
        if let o = old.spo2, let n = new.spo2, (n.MAE_pct - o.MAE_pct) > gates.allowedMAEIncreaseSpO2 { ok = false }
        return ok ? .upgrade : .keepOld
    }

    struct Gates {
        var allowedKappaDrop: Double = 0.0
        var allowedMAEIncrease: Double = 0.0
        var allowedMAEIncreaseHRV: Double = 0.0
        var allowedMAEIncreaseSpO2: Double = 0.0
    }
}
