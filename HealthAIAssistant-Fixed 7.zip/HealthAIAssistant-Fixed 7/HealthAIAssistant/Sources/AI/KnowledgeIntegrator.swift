import Foundation
import CoreML

class KnowledgeIntegrator {
    private let knowledgeGraph = MedicalKnowledgeGraph()
    private let conflictResolver = ConflictResolver()
    private let evidenceEvaluator = EvidenceEvaluator()
    
    func integrateKnowledge(_ newKnowledge: [ValidatedKnowledge]) async throws -> IntegratedKnowledge {
        // 1. 知識圖譜整合
        let graphNodes = await mapToKnowledgeGraph(newKnowledge)
        
        // 2. 衝突檢測與解決
        let resolvedKnowledge = await resolveConflicts(graphNodes)
        
        // 3. 證據強度評估
        let evaluatedKnowledge = await evaluateEvidence(resolvedKnowledge)
        
        // 4. 知識合成
        return await synthesizeKnowledge(evaluatedKnowledge)
    }
    
    private func resolveConflicts(_ nodes: [KnowledgeNode]) async -> [ResolvedKnowledge] {
        let conflictGroups = await detectConflicts(nodes)
        return await conflictGroups.asyncMap { group in
            await conflictResolver.resolve(group)
        }
    }
}
