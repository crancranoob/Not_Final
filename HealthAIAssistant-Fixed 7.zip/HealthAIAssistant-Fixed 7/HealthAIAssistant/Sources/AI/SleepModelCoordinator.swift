import Foundation

/// Separate sleep model (bigger head). Predicts sleep quality 0–100 and flags anomalies.
struct SleepModel: Codable {
    var W1: [Double] // d_in x d_hid (flattened)
    var b1: [Double] // d_hid
    var W2: [Double] // d_hid x 1
    var b2: Double
    let dIn: Int
    let dHid: Int

    init(dIn: Int = 8, dHid: Int = 48) {
        self.dIn = dIn; self.dHid = dHid
        self.W1 = (0..<(dIn*dHid)).map { _ in Double.random(in: -0.01...0.01) }
        self.b1 = (0..<dHid).map { _ in 0.0 }
        self.W2 = (0..<dHid).map { _ in Double.random(in: -0.01...0.01) }
        self.b2 = 0.0
    }
    func forward(_ x: [Double]) -> Double {
        // ReLU(W1*x + b1) -> y
        var h = [Double](repeating: 0, count: dHid)
        for i in 0..<dHid {
            var s = b1[i]
            for j in 0..<dIn { s += W1[i*dIn + j] * x[j] }
            h[i] = max(0, s)
        }
        var y = b2
        for i in 0..<dHid { y += W2[i] * h[i] }
        return max(0, min(100, y*20 + 50)) // scaled to 0..100
    }
    mutating func update(x: [Double], yTrue: Double, lr: Double = 1e-3) {
        // Backprop tiny MLP
        var h = [Double](repeating: 0, count: dHid)
        var pre = [Double](repeating: 0, count: dHid)
        for i in 0..<dHid {
            var s = b1[i]
            for j in 0..<dIn { s += W1[i*dIn + j] * x[j] }
            pre[i] = s
            h[i] = max(0, s)
        }
        var y = b2
        for i in 0..<dHid { y += W2[i] * h[i] }
        // scale same as forward
        let yScaled = max(0, min(100, y*20 + 50))
        let gradOut = (yScaled - yTrue) / 20.0
        // dW2, db2
        for i in 0..<dHid { W2[i] -= lr * gradOut * h[i] }
        b2 -= lr * gradOut
        // back to h
        var gradH = [Double](repeating: 0, count: dHid)
        for i in 0..<dHid { gradH[i] = gradOut * W2[i] * (pre[i] > 0 ? 1 : 0) }
        // dW1, db1
        for i in 0..<dHid {
            b1[i] -= lr * gradH[i]
            for j in 0..<dIn { W1[i*dIn + j] -= lr * gradH[i] * x[j] }
        }
    }
}

final class SleepModelCoordinator: ObservableObject {
    static let shared = SleepModelCoordinator()
    private let url: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("sleep_model.json")
    }()
    @Published var model: SleepModel = SleepModel()

    init() { load() }
    func load() {
        if let data = try? Data(contentsOf: url), let m = try? JSONDecoder().decode(SleepModel.self, from: data) { model = m }
    }
    func save() {
        if let data = try? JSONEncoder().encode(model) { try? data.write(to: url) }
    }

    func sleepQualityScore() -> Double {
        let feat = SleepFeatureExtractor.shared.lastNightFeatures().asVector()
        return model.forward(feat)
    }
}
