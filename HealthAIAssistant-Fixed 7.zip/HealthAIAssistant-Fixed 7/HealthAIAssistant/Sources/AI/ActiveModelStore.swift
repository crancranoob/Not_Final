import Foundation

enum SleepModelVariant: String, Codable { case coreml, coreml_candidate, swift }

final class ActiveModelStore {
    static let shared = ActiveModelStore()
    private init() { load() }
    private var url: URL {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("model_active.json")
    }
    private(set) var sleepVariant: SleepModelVariant = .swift

    func setSleepVariant(_ v: SleepModelVariant) {
        sleepVariant = v
        save()
    }
    private func save() {
        let obj = ["sleep": sleepVariant.rawValue]
        if let d = try? JSONSerialization.data(withJSONObject: obj) { try? d.write(to: url) }
    }
    private func load() {
        guard let d = try? Data(contentsOf: url),
              let obj = try? JSONSerialization.jsonObject(with: d) as? [String: String],
              let raw = obj["sleep"],
              let v = SleepModelVariant(rawValue: raw) else { return }
        sleepVariant = v
    }
}
