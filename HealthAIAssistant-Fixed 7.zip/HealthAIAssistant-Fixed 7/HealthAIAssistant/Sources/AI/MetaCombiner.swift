import Foundation

struct MetaCombiner: Codable {
    var W: [Double]; var b: Double; let dIn: Int
    init(dIn: Int = 6) { self.dIn = dIn; self.W = (0..<dIn).map { _ in Double.random(in: -0.05...0.05) }; self.b = 0.0 }
    func forward(_ x: [Double]) -> Double {
        var s = b; for i in 0..<min(dIn, x.count) { s += W[i]*x[i] }
        let z = 1.0 / (1.0 + exp(-s)); return 1.0 + 4.0 * z
    }
    mutating func update(x: [Double], y: Double, lr: Double = 1e-3) {
        var s = b; for i in 0..<min(dIn, x.count) { s += W[i]*x[i] }
        let z = 1.0 / (1.0 + exp(-s)); let yhat = 1.0 + 4.0*z
        let grad = (yhat - y) * 4.0 * z * (1 - z)
        b -= lr * grad; for i in 0..<min(dIn, x.count) { W[i] -= lr * grad * x[i] }
    }
}

final class MetaCombinerCoordinator: ObservableObject {
    static let shared = MetaCombinerCoordinator()
    private let url: URL = {
        let doc = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return doc.appendingPathComponent("meta_combiner.json")
    }()
    @Published var model: MetaCombiner = MetaCombiner(dIn: 6)
    init() { load() }
    func load() { if let data = try? Data(contentsOf: url), let m = try? JSONDecoder().decode(MetaCombiner.self, from: data) { model = m } }
    func save() { if let data = try? JSONEncoder().encode(model) { try? data.write(to: url) } }
    func predict(data: HealthData) -> Double {
        let ex = ExpertsCoordinator.shared.predictAll(from: data)
        let sleepQ = SleepModelCoordinator.shared.sleepQualityScore()/20.0
        let sleepPart = max(1.0, min(5.0, sleepQ))
        let hyd = (ContextStore.shared.get(Date())?.hydrationLiters ?? 0)/3.0
        let caf = (ContextStore.shared.get(Date())?.caffeineMgLate ?? 0)/400.0
        let raw = model.forward([ex.rec, ex.act, ex.resp, sleepPart, hyd, caf])
        let cal = CalibrationStore.shared.calibrator(for: .meta).apply(raw)
        let post = BayesianLayer.shared.infer(scoreRaw: cal)
        // Adjust minor false positives by baseline
        let adj = BaselineCalibrator.shared.adjustFalsePositives(score: post.mean, hr: data.heartRate, hrv: data.hrvSDNN)
        return adj
    }
}
