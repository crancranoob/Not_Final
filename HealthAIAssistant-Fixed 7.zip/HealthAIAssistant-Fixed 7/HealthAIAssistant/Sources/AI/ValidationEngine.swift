import Foundation
import PDFKit
import UIKit

struct SleepMetrics: Codable {
    var overall_accuracy: Double
    var cohens_kappa: Double
    var per_stage_f1: [String: Double]
}
struct HRMetrics: Codable { var MAE_bpm: Double; var RMSE_bpm: Double; var pearson_r: Double }
struct HRVMetrics: Codable { var MAE_ms: Double; var pearson_r: Double }
struct SpO2Metrics: Codable { var MAE_pct: Double; var pct_within_2pct: Double }
struct RRMetrics: Codable { var MAE_brpm: Double }
struct TempMetrics: Codable { var MAE_C: Double }

struct EvalReport: Codable {
    var model_version: String
    var dataset: String
    var n: Int
    var hr: HRMetrics?
    var hrv: HRVMetrics?
    var sleep: SleepMetrics?
    var spo2: SpO2Metrics?
    var rr: RRMetrics?
    var temp: TempMetrics?
}

final class ValidationEngine {
    static let shared = ValidationEngine()
    private init() { ModelBootstrap.shared.ensureRegistered() }

    // MARK: - Public

    func runBenchmark(dataset: BenchmarkDataset) -> EvalReport {
        var report = EvalReport(model_version: ModelRegistry.shared.currentVersionSummary(),
                                dataset: dataset.name, n: dataset.count,
                                hr: nil, hrv: nil, sleep: nil, spo2: nil, rr: nil, temp: nil)
        if let hr = dataset.hr { report.hr = evalHR(hr) }
        if let hrv = dataset.hrv { report.hrv = evalHRV(hrv) }
        if let slp = dataset.sleep { report.sleep = evalSleep(slp) }
        if let sp = dataset.spo2 { report.spo2 = evalSpO2(sp) }
        if let rr = dataset.rr { report.rr = evalRR(rr) }
        if let tp = dataset.temp { report.temp = evalTemp(tp) }
        saveJSON(report: report)
        PDFGenerator.shared.makePDF(from: report, to: Self.reportURL())
        return report
    }

    func compareAgainstBaselines(_ datasets: [BenchmarkDataset]) -> [String: EvalReport] {
        var out: [String: EvalReport] = [:]
        for d in datasets {
            out[d.name] = runBenchmark(dataset: d)
        }
        return out
    }

    // MARK: - Metrics

    private func evalHR(_ pairs: [(Double, Double)]) -> HRMetrics {
        let y = pairs.map{$0.0}, yhat = pairs.map{$0.1}
        let mae = mean(absDiff(y, yhat))
        let rmse = sqrt(mean(y.enumerated().map { pow($1 - yhat[$0], 2) }))
        let r = pearson(y, yhat)
        return HRMetrics(MAE_bpm: mae, RMSE_bpm: rmse, pearson_r: r)
    }
    private func evalHRV(_ pairs: [(Double, Double)]) -> HRVMetrics {
        let y = pairs.map{$0.0}, yhat = pairs.map{$0.1}
        let mae = mean(absDiff(y, yhat))
        let r = pearson(y, yhat)
        return HRVMetrics(MAE_ms: mae, pearson_r: r)
    }
    private func evalSleep(_ pairs: [(Int, Int)]) -> SleepMetrics {
        let y = pairs.map{$0.0}, yhat = pairs.map{$0.1}
        let acc = Double(zip(y, yhat).filter{$0==$1}.count) / Double(max(1, y.count))
        let f1 = f1PerClass(y: y, yhat: yhat, labels: [0,1,2,3,4], keys: ["W","N1","N2","N3","REM"])
        let k = cohensKappa(y: y, yhat: yhat, labels: [0,1,2,3,4])
        return SleepMetrics(overall_accuracy: acc, cohens_kappa: k, per_stage_f1: f1)
    }
    private func evalSpO2(_ pairs: [(Double, Double)]) -> SpO2Metrics {
        let y = pairs.map{$0.0}, yhat = pairs.map{$0.1}
        let mae = mean(absDiff(y, yhat))
        let within = Double(zip(y, yhat).filter{ abs($0-$1) <= 2.0 }.count) / Double(max(1, y.count))
        return SpO2Metrics(MAE_pct: mae, pct_within_2pct: within)
    }
    private func evalRR(_ pairs: [(Double, Double)]) -> RRMetrics {
        let y = pairs.map{$0.0}, yhat = pairs.map{$0.1}
        return RRMetrics(MAE_brpm: mean(absDiff(y, yhat)))
    }
    private func evalTemp(_ pairs: [(Double, Double)]) -> TempMetrics {
        let y = pairs.map{$0.0}, yhat = pairs.map{$0.1}
        return TempMetrics(MAE_C: mean(absDiff(y, yhat)))
    }

    // MARK: - Math
    private func mean(_ x: [Double]) -> Double { x.reduce(0,+)/Double(max(1,x.count)) }
    private func absDiff(_ a: [Double], _ b: [Double]) -> [Double] { a.enumerated().map { abs($1 - b[$0]) } }
    private func pearson(_ a: [Double], _ b: [Double]) -> Double {
        let n = Double(min(a.count, b.count))
        guard n > 1 else { return 0 }
        let ma = mean(a), mb = mean(b)
        let cov = zip(a,b).map { ($0 - ma)*($1 - mb) }.reduce(0,+) / (n-1.0)
        let va = zip(a,a).map { ($0 - ma)*($1 - ma) }.reduce(0,+) / (n-1.0)
        let vb = zip(b,b).map { ($0 - mb)*($1 - mb) }.reduce(0,+) / (n-1.0)
        let denom = sqrt(max(1e-9, va*vb))
        return cov/denom
    }
    private func f1PerClass(y: [Int], yhat: [Int], labels: [Int], keys: [String]) -> [String: Double] {
        var out: [String: Double] = [:]
        for (i,lab) in labels.enumerated() {
            let tp = zip(y,yhat).filter { $0==lab && $1==lab }.count
            let fp = zip(y,yhat).filter { $0!=lab && $1==lab }.count
            let fn = zip(y,yhat).filter { $0==lab && $1!=lab }.count
            let prec = tp == 0 ? 0.0 : Double(tp) / Double(tp+fp)
            let rec = tp == 0 ? 0.0 : Double(tp) / Double(tp+fn)
            let f1 = (prec+rec) == 0 ? 0.0 : 2*prec*rec/(prec+rec)
            out[keys[i]] = f1
        }
        return out
    }
    private func cohensKappa(y: [Int], yhat: [Int], labels: [Int]) -> Double {
        let n = Double(y.count)
        guard n > 0 else { return 0 }
        var cm = Array(repeating: Array(repeating: 0.0, count: labels.count), count: labels.count)
        for (t,p) in zip(y,yhat) {
            if let ti = labels.firstIndex(of: t), let pi = labels.firstIndex(of: p) { cm[ti][pi] += 1.0 }
        }
        let po = (0..<labels.count).map { cm[$0][$0] }.reduce(0,+) / n
        var pe = 0.0
        for i in 0..<labels.count {
            let row = (0..<labels.count).map { cm[i][$0] }.reduce(0,+)/n
            let col = (0..<labels.count).map { cm[$0][i] }.reduce(0,+)/n
            pe += row*col
        }
        if pe >= 1.0 { return 0 }
        return (po - pe) / (1 - pe)
    }

    // MARK: - I/O
    static func reportsDirectory() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return docs.appendingPathComponent("Eval").appendingPathComponent("reports")
    }
    private func saveJSON(report: EvalReport) {
        let urlDir = Self.reportsDirectory()
        try? FileManager.default.createDirectory(at: urlDir, withIntermediateDirectories: true)
        let url = urlDir.appendingPathComponent("metrics.json")
        if let d = try? JSONEncoder().encode(report) { try? d.write(to: url) }
    }
}

final class PDFGenerator {
    static let shared = PDFGenerator()
    private init() { ModelBootstrap.shared.ensureRegistered() }
    func makePDF(from report: EvalReport, to dir: URL) {
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        let url = dir.appendingPathComponent("report.pdf")
        let pdf = PDFDocument()
        let page = PDFPage(image: renderSummary(report))!
        pdf.insert(page, at: 0)
        pdf.write(to: url)
    }
    private func renderSummary(_ r: EvalReport) -> UIImage {
        let w: CGFloat = 1200, h: CGFloat = 900
        UIGraphicsBeginImageContextWithOptions(CGSize(width: w, height: h), true, 2)
        UIColor.white.setFill(); UIBezierPath(rect: CGRect(x:0,y:0,width:w,height:h)).fill()
        let title = "Model \(r.model_version) — Dataset \(r.dataset) — n=\(r.n)"
        (title as NSString).draw(at: CGPoint(x: 40, y: 40), withAttributes: [.font: UIFont.boldSystemFont(ofSize: 28)])
        var y: CGFloat = 100
        func line(_ s: String) { (s as NSString).draw(at: CGPoint(x: 40, y: y), withAttributes: [.font: UIFont.systemFont(ofSize: 18)]); y += 28 }
        if let hr = r.hr { line("HR   MAE=\(String(format:"%.2f", hr.MAE_bpm)) bpm, RMSE=\(String(format:"%.2f", hr.RMSE_bpm)) bpm, r=\(String(format:"%.2f", hr.pearson_r))") }
        if let hrv = r.hrv { line("HRV  MAE=\(String(format:"%.1f", hrv.MAE_ms)) ms, r=\(String(format:"%.2f", hrv.pearson_r))") }
        if let sl = r.sleep {
            line("Sleep Acc=\(String(format:"%.2f", sl.overall_accuracy))  κ=\(String(format:"%.2f", sl.cohens_kappa))  F1 REM=\(String(format:"%.2f", sl.per_stage_f1["REM"] ?? 0)) N3=\(String(format:"%.2f", sl.per_stage_f1["N3"] ?? 0))")
        }
        if let sp = r.spo2 { line("SpO2 MAE=\(String(format:"%.2f", sp.MAE_pct))%  within±2%=\(String(format:"%.2f", sp.pct_within_2pct))") }
        if let rr = r.rr { line("RR   MAE=\(String(format:"%.2f", rr.MAE_brpm)) brpm") }
        if let tp = r.temp { line("Temp MAE=\(String(format:"%.2f", tp.MAE_C)) °C") }
        let img = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        return img
    }
}

// Lightweight dataset holder for offline benchmark (groundTruth, prediction)
struct BenchmarkDataset {
    let name: String
    let count: Int
    let hr: [(Double, Double)]?      // bpm pairs (true, pred)
    let hrv: [(Double, Double)]?     // ms pairs
    let sleep: [(Int, Int)]?         // stage id pairs
    let spo2: [(Double, Double)]?    // % pairs
    let rr: [(Double, Double)]?      // breaths/min pairs
    let temp: [(Double, Double)]?    // Celsius pairs
}
