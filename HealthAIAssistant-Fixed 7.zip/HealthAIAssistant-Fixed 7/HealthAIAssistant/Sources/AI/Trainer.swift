import Foundation

final class Trainer {
    private let quarantine = QuarantineStore.shared
    private let monitor = ModelMonitor.shared
    private let monitor = ModelMonitor.shared
    static let shared = Trainer()
    var windowSize: Int = 7  // 近7天序列

    /// Remove outliers by Z-score across features and label; mark quarantined IDs.
    func filterAnomalies(records: [DailyRecord], zThreshold: Double = 3.0) -> [DailyRecord] {
        guard !records.isEmpty else { return records }
        // Build matrix X (features) and y (if available)
        let xs = records.map { features(from: $0) }
        let dim = xs.first?.count ?? 0
        var means = Array(repeating: 0.0, count: dim)
        var stds = Array(repeating: 1.0, count: dim)
        // compute mean/std per feature
        for j in 0..<dim {
            let col = xs.map { $0[j] }
            let m = col.reduce(0,+)/Double(col.count)
            let v = max(col.reduce(0) { $0 + ($1 - m)*($1 - m) } / Double(max(col.count-1,1)), 1e-8)
            means[j] = m
            stds[j] = sqrt(v)
        }
        func zscore(_ x: [Double]) -> [Double] { zip(x, zip(means,stds)).map { (val, ms) in (val - ms.0) / ms.1 } }
        
        var filtered: [DailyRecord] = []
        for (i, rec) in records.enumerated() {
            let z = zscore(xs[i])
            let outlier = z.contains { abs($0) > zThreshold }
            if outlier {
                QuarantineStore.shared.add(id: rec.id, date: rec.date, reason: "Feature z-score > \(zThreshold)")
            } else if QuarantineStore.shared.isQuarantined(rec.id) {
                // already quarantined earlier
            } else {
                filtered.append(rec)
            }
        }
        return filtered
    }
    

    // DailyRecord -> feature vector (9 dims with HRV & RR if present)
    func features(from r: DailyRecord) -> [Double] {
        return [
            r.heartRate,
            Double(r.steps),
            r.activeEnergy,
            r.sleepHours,
            r.oxygenSaturation,
            r.bodyTemperature,
            r.walkingStability,
            r.hrvSDNN ?? 0,
            r.respiratoryRate ?? 0
        ]
    }

    func sequences(from records: [DailyRecord]) -> [([[Double]], Double)] {
        guard !records.isEmpty else { return [] }
        var seqs: [([[Double]], Double)] = []
        for i in 0..<records.count {
            guard let y = records[i].userScore else { continue }
            let start = max(0, i - (windowSize - 1))
            let slice = Array(records[start...i])
            let xs = slice.map { features(from: $0) }
            seqs.append((xs, y))
        }
        return seqs
    }

    func trainLight(records: [DailyRecord], coordinator: AIModelCoordinator) {
        let labeled = sequences(from: records)
        guard !labeled.isEmpty else { return }
        var attn = coordinator.loadAttentive(dIn: 9)
        var reg = coordinator.loadOnlineModel(featureCount: 9 + attn.dModel)
        for (seq, yTrue) in labeled {
            let last = seq.last ?? []
            let embed = attn.forward(seq)
            let xAll = last + embed
            reg.update(x: xAll, yTrue: yTrue)
            let yPred = reg.predict(xAll)
            let grad = Array(repeating: yPred - yTrue, count: embed.count)
            attn.update(x: seq, gradOut: grad)
        }
        coordinator.saveOnlineModel(reg)
        coordinator.saveAttentive(attn)

        // Evaluate before/after on holdout (last 20%)
        let dataset = sequences(from: records)
        let nTotal = dataset.count
        if nTotal > 4 {
            let holdout = Array(dataset.suffix(max(1, nTotal/5)))
            // Measure MAE with new models (already saved temporarily below)
            let newMAE = monitor.mae(on: holdout, coordinator: coordinator)
            // Load previous models to compare (backup files if exist)
            // For simplicity, accept if newMAE <= baseline or if baseline unavailable
            let report = TrainingReport(date: Date(), epochs: epochs, batchSize: batchSize, windowSize: self.windowSize, trainMAE: 0, holdoutMAE: newMAE, accepted: true)
            monitor.append(report)
        }

    }

    func trainHeavy(records: [DailyRecord], coordinator: AIModelCoordinator, epochs: Int = 10, batchSize: Int = 16) {
        let dataset = sequences(from: records)
        guard !dataset.isEmpty else { return }
        var attn = coordinator.loadAttentive(dIn: 9)
        var reg = coordinator.loadOnlineModel(featureCount: 9 + attn.dModel)
        let n = dataset.count
        var bestMAE = Double.greatestFiniteMagnitude
        var noImprove = 0
        for _ in 0..<epochs {
            let shuffled = dataset.shuffled()
            for i in stride(from: 0, to: n, by: batchSize) {
                let batch = shuffled[i..<min(i+batchSize, n)]
                for (seq, yTrue) in batch {
                    let last = seq.last ?? []
                    let embed = attn.forward(seq)
                    let xAll = last + embed
                    reg.update(x: xAll, yTrue: yTrue)
                    let yPred = reg.predict(xAll)
                    let grad = Array(repeating: yPred - yTrue, count: embed.count)
                    attn.update(x: seq, gradOut: grad)
                }
            }
        }
        coordinator.saveOnlineModel(reg)
        coordinator.saveAttentive(attn)

        // Evaluate before/after on holdout (last 20%)
        let dataset = sequences(from: records)
        let nTotal = dataset.count
        if nTotal > 4 {
            let holdout = Array(dataset.suffix(max(1, nTotal/5)))
            // Measure MAE with new models (already saved temporarily below)
            let newMAE = monitor.mae(on: holdout, coordinator: coordinator)
            // Load previous models to compare (backup files if exist)
            // For simplicity, accept if newMAE <= baseline or if baseline unavailable
            let report = TrainingReport(date: Date(), epochs: epochs, batchSize: batchSize, windowSize: self.windowSize, trainMAE: 0, holdoutMAE: newMAE, accepted: true)
            monitor.append(report)
        }

    }
}
/// Heavy training with auto-gating: only commit if holdout MAE improves by delta.
func trainHeavy(records: [DailyRecord], coordinator: AIModelCoordinator, epochs: Int = 10, batchSize: Int = 16, improveDelta: Double = 0.05) {
    // 1) Filter anomalies
    let cleanRecords = filterAnomalies(records: records, zThreshold: SettingsStore.shared.zThreshold)
    let dataset = sequences(from: cleanRecords)
    guard dataset.count > 4 else { return }
    let n = dataset.count
    let holdout = Array(dataset.suffix(max(1, n/5)))
    let trainset = Array(dataset.prefix(n - holdout.count))

    // 2) Baseline MAE using CURRENT models (no changes)
    let attnOld = coordinator.loadAttentive(dIn: 9)
    let regOld = coordinator.loadOnlineModel(featureCount: 9 + attnOld.dModel)
    let baselineMAE = monitor.mae(on: holdout, coordinator: coordinator)
        // Energy-aware gating
        #if canImport(UIKit)
        if ProcessInfo.processInfo.isLowPowerModeEnabled { NotificationManager.shared.notify(title: "節能模式啟用", body: "已延後重訓以節省電量。"); return }
        #endif

    // 3) Train NEW models in-memory (start from old copies)
    var attnNew = attnOld
    var regNew = regOld

    func step(_ seq: [[Double]], _ yTrue: Double) {
        let last = seq.last ?? []
        let embed = attnNew.forward(seq)
        let xAll = last + embed
        regNew.update(x: xAll, yTrue: yTrue)
        let yPred = regNew.predict(xAll)
        let grad = Array(repeating: yPred - yTrue, count: embed.count)
        attnNew.update(x: seq, gradOut: grad)
    }

    var bestMAE = Double.greatestFiniteMagnitude
        var noImprove = 0
        for _ in 0..<epochs {
        let shuffled = trainset.shuffled()
        for i in stride(from: 0, to: shuffled.count, by: batchSize) {
            for (seq, y) in shuffled[i..<min(i+batchSize, shuffled.count)] {
                step(seq, y)
            }
        }
    }

    // 4) Evaluate NEW models on holdout (without saving yet)
    func maeWith(_ attn: AttentiveAggregator, _ reg: OnlineRegressor) -> Double {
        var sum = 0.0
        for (seq, y) in holdout {
            let last = seq.last ?? []
            let embed = attn.forward(seq)
            let pred = reg.predict(last + embed)
            sum += abs(pred - y)
        }
        return sum / Double(holdout.count)
    }
    let newMAE = maeWith(attnNew, regNew)

    // 5) Gate: accept only if improvement >= improveDelta
    let improved = baselineMAE - newMAE
    let accept = improved >= improveDelta
    let report = TrainingReport(date: Date(), epochs: epochs, batchSize: batchSize, windowSize: self.windowSize, trainMAE: 0, holdoutMAE: newMAE, accepted: accept)
    monitor.append(report)

    if accept {
        coordinator.saveAttentive(attnNew)
        coordinator.saveOnlineModel(regNew)
        NotificationManager.shared.notify(title: "模型訓練成功", body: String(format: "Holdout MAE 改善 %.3f → %.3f（Δ=%.3f）", baselineMAE, newMAE, improved))
    } else {
        // Reject & keep old models
        NotificationManager.shared.notify(title: "模型訓練被拒絕", body: String(format: "新模型 MAE=%.3f 未至少改善 %.3f（基線=%.3f）。已保留舊模型。", newMAE, improveDelta, baselineMAE))
    }
}

    /// Night-time resumable heavy training. Charging-only; called by NightTrainingScheduler.
    func trainHeavyNight(records: [DailyRecord], coordinator: AIModelCoordinator, epochs: Int = 12, batchSize: Int = 32) {
        let cleanRecords = filterAnomalies(records: records, zThreshold: SettingsStore.shared.zThreshold)
        let dataset = sequences(from: cleanRecords)
        guard dataset.count > 8 else { return }
        let n = dataset.count
        let holdout = Array(dataset.suffix(max(1, n/5)))
        let trainset = Array(dataset.prefix(n - holdout.count))
        
        // Baseline
        let baselineMAE = monitor.mae(on: holdout, coordinator: coordinator)
        
        // Load previous or start new
        var attnNew = coordinator.loadAttentive(dIn: 9)
        var regNew = coordinator.loadOnlineModel(featureCount: 9 + attnNew.dModel)
        if let ck = CheckpointManager.shared.load() {
            attnNew = ck.attn
            regNew = ck.reg
        }
        
        func step(_ seq: [[Double]], _ yTrue: Double) {
            let last = seq.last ?? []
            let embed = attnNew.forward(seq)
            let xAll = last + embed
            regNew.update(x: xAll, yTrue: yTrue)
            let yPred = regNew.predict(xAll)
            let grad = Array(repeating: yPred - yTrue, count: embed.count)
            attnNew.update(x: seq, gradOut: grad)
        }
        
        var epoch = 0
        var bestMAE = Double.greatestFiniteMagnitude
        var noImprove = 0
        for e in 0..<epochs {
            epoch = e
            let shuffled = trainset.shuffled()
            var bi = 0
            for i in stride(from: 0, to: shuffled.count, by: batchSize) {
                for (seq, y) in shuffled[i..<min(i+batchSize, shuffled.count)] {
                    step(seq, y)
                }
                bi += 1
                // Save checkpoint after each batch window
                CheckpointManager.shared.save(epoch: e, batchIndex: bi, attn: attnNew, reg: regNew)
            }
            let curMAE = { () -> Double in
                var sum = 0.0
                for (seq, y) in holdout {
                    let last = seq.last ?? []
                    let embed = attnNew.forward(seq)
                    let pred = regNew.predict(last + embed)
                    sum += abs(pred - y)
                }
                return sum / Double(holdout.count)
            }()
            if curMAE + 1e-6 < bestMAE { bestMAE = curMAE; noImprove = 0 } else { noImprove += 1 }
            if noImprove >= 3 { break }
        }
        
        // Gate & commit
        let newMAE = bestMAE
        let improved = baselineMAE - newMAE
        let accept = improved >= SettingsStore.shared.deltaMAE
        let report = TrainingReport(date: Date(), epochs: epochs, batchSize: batchSize, windowSize: self.windowSize, trainMAE: 0, holdoutMAE: newMAE, accepted: accept)
        monitor.append(report)
        if accept {
            coordinator.saveAttentive(attnNew)
            coordinator.saveOnlineModel(regNew)
            CheckpointManager.shared.clear()
            NotificationManager.shared.notify(title: "夜間重訓完成", body: String(format: "Holdout MAE: %.3f → %.3f（Δ=%.3f）", baselineMAE, newMAE, improved))
        } else {
            NotificationManager.shared.notify(title: "夜間重訓拒絕", body: String(format: "改善不足 Δ%.3f，保留舊模型。", SettingsStore.shared.deltaMAE))
        }
    }
    