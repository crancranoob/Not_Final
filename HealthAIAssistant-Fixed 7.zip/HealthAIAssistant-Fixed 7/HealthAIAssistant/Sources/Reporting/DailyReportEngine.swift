import Foundation
import UserNotifications

final class DailyReportEngine {
    static let shared = DailyReportEngine()

    func generateReport(from data: HealthData) -> String {
        var parts: [String] = []
        parts.append("Heart rate: \(Int(data.heartRate)) bpm")
        parts.append("Steps: \(data.steps)")
        if data.sleepHours > 0 { parts.append(String(format: "Sleep: %.1f h", data.sleepHours)) }
        if data.oxygenSaturation > 0 { parts.append(String(format: "SpO₂: %.0f%%", data.oxygenSaturation * 100)) }
        if data.bodyTemperature > 0 { parts.append(String(format: "Temp: %.1f ℃", data.bodyTemperature)) }
        let summary = parts.joined(separator: " · ")
        return summary
    }
}
