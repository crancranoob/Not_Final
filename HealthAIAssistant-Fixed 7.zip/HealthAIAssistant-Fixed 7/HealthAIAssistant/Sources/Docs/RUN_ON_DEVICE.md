在 iPhone / iPad 真機上執行（快速步驟）：

1. 在 macOS 開啟 Xcode，打開本專案的 Xcode workspace / project（或用 `swift package generate-xcodeproj` 產生 Xcode 專案）。
2. 選擇目標裝置為你的 iPhone / iPad，確保 iOS Deployment Target ≥ 16.0。
3. 開啟 Project 的 Signing & Capabilities：
   - 加入 HealthKit capability（必需）。
   - 如需 iCloud / App Group，加入對應 capability（若要測試跨 App 匯入）。
4. 在 Info.plist（Project 設定）加入必要的隱私說明（在 Xcode：Info -> Custom iOS Target Properties）：
   - NSHealthShareUsageDescription (HealthKit 共用)
   - NSHealthUpdateUsageDescription (HealthKit 更新)
   - NSBluetoothAlwaysUsageDescription（如需藍牙同步）
   - NSCameraUsageDescription / NSPhotoLibraryUsageDescription（如需匯入照片或掃描）
5. 如果需要測試 ML 模型推論：
   - 將 .mlmodel 或 .mlmodelc 加入 App target（拖進 Xcode 並勾選 target）。
   - 或把範例模型放到 App bundle 的 Resources 資料夾。
6. 連接真機，按 Run（⌘R）。首次執行會提示 HealthKit 權限，允許後即可收集並分析資料。
7. 日誌與錯誤：使用 Xcode Console 檢視運行情況。

注意：
- CreateML 訓練只在 macOS，可在 macOS 產出 .mlmodel 再放到 App 中以在真機測試。
- 本專案現為研究/個人測試用途，非醫療級產品。請勿用於臨床診斷。

注意（iOS 16.1 beta）：
- 若您使用 iOS 16.1 beta，請確保 Xcode 與裝置的相容性（建議使用配套的 Xcode beta 版本）。
- 在 Xcode 開啟時，選擇對應的 beta 裝置執行，部分 API 在 beta 版可能有差異或行為改變。
- HealthKit 權限在 beta 版無特別差異，但首次測試時請完整授權以避免資料讀取失敗。
- 若遇到 MLModel 的編譯或運行相容性問題，請檢查 .mlmodel 是否已編譯成 .mlmodelc 並加入 App bundle。

注意（iOS 26.1 beta）：
- 您使用 iOS 26.1 beta 時，請搭配相容的 Xcode beta 版本進行測試。
- 某些系統 API 或 Core ML 行為在 beta 版本可能尚未穩定，若遇到模型編譯或推論問題，請先確認 .mlmodel 是否已編譯為 .mlmodelc 並加入 App bundle。
- HealthKit 權限流程通常相同，但在 beta 環境測試時請完整授權並檢查授權日誌以排查問題。
- 若發現系統行為異常，請將裝置與 Xcode 的系統日誌回報供除錯。
