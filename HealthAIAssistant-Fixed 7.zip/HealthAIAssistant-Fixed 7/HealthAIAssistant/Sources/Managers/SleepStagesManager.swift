import Foundation
import HealthKit

struct SleepStageMetrics: Codable {
    var total: TimeInterval = 0
    var core: TimeInterval = 0
    var deep: TimeInterval = 0
    var rem: TimeInterval = 0
    var awake: TimeInterval = 0
    var efficiency: Double { total > 0 ? (total - awake)/total : 0 }
    var remPct: Double { total > 0 ? rem/total : 0 }
    var deepPct: Double { total > 0 ? deep/total : 0 }
    var corePct: Double { total > 0 ? core/total : 0 }
    var awakenings: Int = 0
}

final class SleepStagesManager {
    static let shared = SleepStagesManager()
    private let store = HKHealthStore()

    func fetchLastNight(completion: @escaping (SleepStageMetrics) -> Void) {
        guard let type = HKObjectType.categoryType(forIdentifier: .sleepAnalysis) else {
            completion(SleepStageMetrics()); return
        }
        let start = Calendar.current.startOfDay(for: Date()).addingTimeInterval(-24*3600)
        let pred = HKQuery.predicateForSamples(withStart: start, end: Date(), options: [])
        let sort = [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: true)]
        let q = HKSampleQuery(sampleType: type, predicate: pred, limit: HKObjectQueryNoLimit, sortDescriptors: sort) { _, samples, _ in
            var m = SleepStageMetrics()
            var lastEnd: Date?
            for s in samples ?? [] {
                guard let cat = s as? HKCategorySample else { continue }
                let dur = cat.endDate.timeIntervalSince(cat.startDate)
                if cat.value == HKCategoryValueSleepAnalysis.asleepCore.rawValue {
                    m.core += dur
                } else if cat.value == HKCategoryValueSleepAnalysis.asleepDeep.rawValue {
                    m.deep += dur
                } else if cat.value == HKCategoryValueSleepAnalysis.asleepREM.rawValue {
                    m.rem += dur
                } else if cat.value == HKCategoryValueSleepAnalysis.awake.rawValue {
                    m.awake += dur
                    if let le = lastEnd, cat.startDate.timeIntervalSince(le) < 15*60 { m.awakenings += 1 }
                }
                if cat.value != HKCategoryValueSleepAnalysis.inBed.rawValue {
                    m.total += dur
                }
                lastEnd = cat.endDate
            }
            completion(m)
        }
        store.execute(q)
    }
}
