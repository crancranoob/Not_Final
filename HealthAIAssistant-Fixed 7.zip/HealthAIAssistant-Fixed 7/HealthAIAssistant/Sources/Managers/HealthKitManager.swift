import HealthKit
import Combine

class HealthKitManager: ObservableObject {
    let healthStore = HKHealthStore()
    
    @Published var isAuthorized = false
    @Published var healthData: HealthData = HealthData()
    
    private let allTypes = Set([
        HKObjectType.quantityType(forIdentifier: .heartRate)!,
        HKObjectType.quantityType(forIdentifier: .stepCount)!,
        HKObjectType.quantityType(forIdentifier: .activeEnergyBurned)!,
        HKObjectType.categoryType(forIdentifier: .sleepAnalysis)!,
        HKObjectType.quantityType(forIdentifier: .oxygenSaturation)!,
        HKObjectType.quantityType(forIdentifier: .bodyTemperature)!,
        HKObjectType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!,
        HKObjectType.quantityType(forIdentifier: .respiratoryRate)!
    ])
    
    init() {
        requestAuthorization()
    }
    
    func requestAuthorization() {
        healthStore.requestAuthorization(toShare: nil, read: allTypes) { success, error in
            DispatchQueue.main.async {
                self.isAuthorized = success
                if success {
                    self.startDataCollection()
                }
            }
        }
    }
    
    func startDataCollection() {
        fetchLatestHeartRate()
        fetchLatestSteps()
        fetchLatestOxygenSaturation()
        fetchLatestBodyTemperature()
        fetchLatestSleep()
    }
    
    private func fetchLatestHeartRate() {
        let type = HKQuantityType.quantityType(forIdentifier: .heartRate)!
        let sort = [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]
        let query = HKSampleQuery(sampleType: type, predicate: nil, limit: 1, sortDescriptors: sort) { _, results, _ in
            if let sample = results?.first as? HKQuantitySample {
                DispatchQueue.main.async {
                    self.healthData.heartRate = sample.quantity.doubleValue(for: .init(from: "count/min"))
                }
            }
        }
        healthStore.execute(query)
    }
    
    private func fetchLatestSteps() {
        let type = HKQuantityType.quantityType(forIdentifier: .stepCount)!
        let now = Date()
        let startOfDay = Calendar.current.startOfDay(for: now)
        let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: now)
        let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, stats, _ in
            DispatchQueue.main.async {
                self.healthData.steps = Int(stats?.sumQuantity()?.doubleValue(for: .count()) ?? 0)
            }
        }
        healthStore.execute(query)
    }
    
    private func fetchLatestOxygenSaturation() {
        let type = HKQuantityType.quantityType(forIdentifier: .oxygenSaturation)!
        let sort = [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]
        let query = HKSampleQuery(sampleType: type, predicate: nil, limit: 1, sortDescriptors: sort) { _, results, _ in
            if let sample = results?.first as? HKQuantitySample {
                DispatchQueue.main.async {
                    self.healthData.oxygenSaturation = sample.quantity.doubleValue(for: .percent()) * 100
                }
            }
        }
        healthStore.execute(query)
    }
    
    private func fetchLatestBodyTemperature() {
        let type = HKQuantityType.quantityType(forIdentifier: .bodyTemperature)!
        let sort = [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]
        let query = HKSampleQuery(sampleType: type, predicate: nil, limit: 1, sortDescriptors: sort) { _, results, _ in
            if let sample = results?.first as? HKQuantitySample {
                DispatchQueue.main.async {
                    self.healthData.bodyTemperature = sample.quantity.doubleValue(for: .degreeCelsius())
                }
            }
        }
        healthStore.execute(query)
    }
    
    private func fetchLatestSleep() {
        let type = HKCategoryType.categoryType(forIdentifier: .sleepAnalysis)!
        let now = Date()
        let startOfDay = Calendar.current.startOfDay(for: now)
        let predicate = HKQuery.predicateForSamples(withStart: startOfDay, end: now)
        let query = HKSampleQuery(sampleType: type, predicate: predicate, limit: HKObjectQueryNoLimit, sortDescriptors: nil) { _, results, _ in
            let sleepSamples = results as? [HKCategorySample] ?? []
            let totalSleep = sleepSamples
                .filter { $0.value == HKCategoryValueSleepAnalysis.asleep.rawValue }
                .reduce(0.0) { $0 + $1.endDate.timeIntervalSince($1.startDate) }
            DispatchQueue.main.async {
                self.healthData.sleepHours = totalSleep / 3600.0
            }
        }
        healthStore.execute(query)
    }
}


    private func fetchHRV() {
        let type = HKQuantityType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!
        let sort = [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]
        let query = HKSampleQuery(sampleType: type, predicate: nil, limit: 1, sortDescriptors: sort) { _, results, _ in
            if let sample = results?.first as? HKQuantitySample {
                DispatchQueue.main.async {
                    self.healthData.hrvSDNN = sample.quantity.doubleValue(for: HKUnit.secondUnit(with: .milli)) // ms
                }
            }
        }
        healthStore.execute(query)
    }
    
    private func fetchRespiratoryRate() {
        let type = HKQuantityType.quantityType(forIdentifier: .respiratoryRate)!
        let sort = [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]
        let query = HKSampleQuery(sampleType: type, predicate: nil, limit: 1, sortDescriptors: sort) { _, results, _ in
            if let sample = results?.first as? HKQuantitySample {
                DispatchQueue.main.async {
                    self.healthData.respiratoryRate = sample.quantity.doubleValue(for: HKUnit.count().unitDivided(by: HKUnit.minute()))
                }
            }
        }
        healthStore.execute(query)
    }
